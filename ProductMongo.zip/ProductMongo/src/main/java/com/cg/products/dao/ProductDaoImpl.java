package com.cg.products.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.products.dto.Products;
@Repository
public class ProductDaoImpl implements ProductDao {
	private static final String COLLECTION = "Products";
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public List<Products> showAllProducts() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Products.class);
	}

	@Override
	public Products addProducts(Products pro) {
		return mongoTemplate.insert(pro);
	}

	@Override
	public Products searchProductById(int proid) {
		Query query=Query.query(Criteria.where("proId").is(proid));
		Products p=mongoTemplate.findOne(query,Products.class);
		return p;
	}

	@Override
	public Products updateProduct(Products pro) {
		mongoTemplate.save(pro);
		return pro;
	}

	@Override
	public void deleteProduct(int pro) {
		System.out.println("dao"+pro);
		Products p=mongoTemplate.findById(pro,  Products.class);
		if(p!=null) {
			mongoTemplate.remove(p);
		}
		
	}

}
