package com.cg.products.service;

import java.util.List;

import com.cg.products.dto.Products;

public interface ProductService {
	public List<Products> showAllProducts();
	 public Products addProducts(Products pro);
	 public Products searchProductById(int proId);
	 public Products updateProduct(Products pro);
	 public void deleteProduct(int pro);
}
