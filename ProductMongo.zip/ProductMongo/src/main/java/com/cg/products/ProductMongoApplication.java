package com.cg.products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.products")
public class ProductMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductMongoApplication.class, args);
		System.out.println("Hai Products");
	}

}
