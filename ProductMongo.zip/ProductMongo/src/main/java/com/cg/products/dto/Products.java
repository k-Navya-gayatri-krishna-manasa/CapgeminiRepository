package com.cg.products.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection = "product_mongo")
public class Products {
	@Id
	private Integer proId;
	private String proName;
	private Double proPrice;
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private Date dateOfPurchase;
	public Integer getProId() {
		return proId;
	}
	public void setProId(Integer proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public Double getProPrice() {
		return proPrice;
	}
	public void setProPrice(Double proPrice) {
		this.proPrice = proPrice;
	}
	public Date getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(Date dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}
	public Products(Integer proId, String proName, Double proPrice, Date dateOfPurchase) {
		super();
		this.proId = proId;
		this.proName = proName;
		this.proPrice = proPrice;
		this.dateOfPurchase = dateOfPurchase;
	}
	public Products() {
		super();
	}
	@Override
	public String toString() {
		return "Products [proId=" + proId + ", proName=" + proName + ", proPrice=" + proPrice + ", dateOfPurchase="
				+ dateOfPurchase + "]";
	}
	
	
}
