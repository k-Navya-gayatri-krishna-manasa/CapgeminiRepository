package com.cg.products.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.products.dao.ProductDao;
import com.cg.products.dto.Products;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDao productdao;
	@Override
	public List<Products> showAllProducts() {
		// TODO Auto-generated method stub
		return productdao.showAllProducts();
	}

	@Override
	public Products addProducts(Products pro) {
		// TODO Auto-generated method stub
		return productdao.addProducts(pro);
	}

	@Override
	public Products searchProductById(int proId) {
		// TODO Auto-generated method stub
		return productdao.searchProductById(proId);
	}

	@Override
	public Products updateProduct(Products pro) {
		// TODO Auto-generated method stub
		return productdao.updateProduct(pro);
	}

	@Override
	public void deleteProduct(int pro) {
		productdao.deleteProduct(pro);
		
	}

}
