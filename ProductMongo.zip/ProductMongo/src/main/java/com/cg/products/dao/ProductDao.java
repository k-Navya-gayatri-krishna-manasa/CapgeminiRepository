package com.cg.products.dao;

import java.util.List;

import com.cg.products.dto.Products;

public interface ProductDao {
	public List<Products> showAllProducts();
	 public Products addProducts(Products pro);
	 public Products searchProductById(int proId);
	 public Products updateProduct(Products pro);
	 public void deleteProduct(int pro);
}
