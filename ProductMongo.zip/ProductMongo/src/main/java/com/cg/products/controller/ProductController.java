package com.cg.products.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.products.dto.Products;
import com.cg.products.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Products>> getAllProducts(){
		List<Products> pro=productService.showAllProducts();
		if(pro.isEmpty()) {
			return new ResponseEntity("No employee Found",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<Products>>(pro,HttpStatus.OK);
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity addProduct(@RequestBody Products pro) {
		Products product= productService.addProducts(pro);
		if(product==null) {
			return new ResponseEntity("Data not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Products>(product,HttpStatus.OK);
	}
	
	@DeleteMapping("/delProduct")
	public void deleteProduct(@RequestParam("pid") Integer id) {
		productService.deleteProduct(id);
	}
	
	
	@PutMapping("/updateProduct")
	public Products updateProduct(@RequestBody Products product) {
		return productService.updateProduct(product);
	}
	
	@GetMapping("/getbyId")
	public ResponseEntity searchId(@RequestParam("pid") Integer id){
		System.out.println(id);
		Products product=productService.searchProductById(id);
		if(product==null) {
			return new ResponseEntity("No product Found with given Id", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Products>(product,HttpStatus.OK);
	}
}
