package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int empId=Integer.parseInt(request.getParameter("empId"));
		String name=request.getParameter("name");
		String gender=request.getParameter("gender");
		int age=Integer.parseInt(request.getParameter("age"));
		double salary=Integer.parseInt(request.getParameter("salary"));
		Employee emp=new Employee();
		emp.setId(empId);
		emp.setName(name);
		emp.setGender(gender);
		emp.setAge(age);
		emp.setSalary(salary);
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			
			/* Inserting data from here to oraqcle db */
			PreparedStatement stat=con.prepareStatement("insert into employee (empid,name,gender,age,salary) values(?,?,?,?,?)");
			stat.setInt(1,emp.getId());
			stat.setString(2, emp.getName());
			stat.setString(3,emp.getGender());
			stat.setInt(4, emp.getAge());
			stat.setDouble(5,emp.getSalary());
			int result=stat.executeUpdate();
			response.sendRedirect("success.jsp");
		} catch (ClassNotFoundException |SQLException e) {
			
			e.printStackTrace();
		}

	}

	

	
}
