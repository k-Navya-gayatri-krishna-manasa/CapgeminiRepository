package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.dao.IProductDao;
import com.cg.model.Products;

@Repository("productDbService")
public class ProductDbService implements IProductService{
	
	@Autowired
	private IProductDao productDbDao;

	@Override
	public List<Products> getAllProducts() {
		
		return productDbDao.getAllProducts();
	}
}
