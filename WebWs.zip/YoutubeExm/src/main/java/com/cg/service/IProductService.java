package com.cg.service;

import java.util.List;

import com.cg.model.Products;

public interface IProductService {
	public List<Products> getAllProducts();
}
