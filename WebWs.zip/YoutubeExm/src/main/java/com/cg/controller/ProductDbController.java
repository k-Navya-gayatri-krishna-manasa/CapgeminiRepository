package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Products;
import com.cg.service.IProductService;

@RestController
@RequestMapping("/api/productDbController")
public class ProductDbController {
	
	@Autowired
	private IProductService productDbService;
	
	@GetMapping("/products")
	public ResponseEntity<List<Products>> getAllProducts(){
		List<Products> products=productDbService.getAllProducts();
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry! Products not available",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Products>>(products,HttpStatus.OK);
	}

}
