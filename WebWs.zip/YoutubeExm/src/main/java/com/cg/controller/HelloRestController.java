package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class HelloRestController {
	@RequestMapping("helloSpring")
	public String helloSpring() {
		return "Welcome to Spring FrameWork!";
	}
}
