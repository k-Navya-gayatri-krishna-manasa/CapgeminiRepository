package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Products;
@Repository("productDbDao")
@Transactional
public class ProductDbDaoImpl implements IProductDao{
	@Autowired
	private IProductDao productDao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Products> getAllProducts() {
		List<Products> products=entityManager.createQuery("from Products").getResultList();
		return products;
	}

}
