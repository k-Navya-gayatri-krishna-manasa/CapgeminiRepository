package com.cg.dao;

import java.util.List;

import com.cg.model.Products;

public interface IProductDao {
	public List<Products> getAllProducts();
}
