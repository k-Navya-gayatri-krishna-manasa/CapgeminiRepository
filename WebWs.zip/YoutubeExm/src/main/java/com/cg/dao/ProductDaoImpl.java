package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.cg.model.Products;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao{
	private static AtomicInteger productId=new AtomicInteger(1000);
	private static List<Products> products=dummyProductDb();
			
			
		private static List<Products> dummyProductDb(){
		List<Products> products=new ArrayList<Products>();
		products.add(new Products(productId.incrementAndGet(),"OppoF11Pro",43000));
		products.add(new Products(productId.incrementAndGet(),"VivoV15Pro",48000));
		return products;
	}
	@Override
	public List<Products> getAllProducts() {
		return products;
	}

}
