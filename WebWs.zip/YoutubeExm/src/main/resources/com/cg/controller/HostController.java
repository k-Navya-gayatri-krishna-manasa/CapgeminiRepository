package com.cg.controller;

public class HostController {

}
