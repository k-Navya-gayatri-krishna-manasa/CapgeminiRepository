package com.cg.withAnnotations;

public interface IVehicle {
	public void details();
}
