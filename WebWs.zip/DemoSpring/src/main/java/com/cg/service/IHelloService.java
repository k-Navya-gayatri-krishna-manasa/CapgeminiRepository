package com.cg.service;

public interface IHelloService {
	public void sayHello(String name);
}
