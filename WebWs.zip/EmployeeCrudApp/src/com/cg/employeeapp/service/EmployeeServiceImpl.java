package com.cg.employeeapp.service;

import java.util.List;

import com.cg.employeeapp.dao.EmployeeDao;
import com.cg.employeeapp.dao.EmployeeDaoImpl;
import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao employeeDao;
	public EmployeeServiceImpl() {
		employeeDao=new EmployeeDaoImpl();
	}
	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		return employeeDao.getEmployees();
	}
	
}
