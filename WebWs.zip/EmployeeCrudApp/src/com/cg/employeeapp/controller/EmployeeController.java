package com.cg.employeeapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;
import com.cg.employeeapp.service.EmployeeService;
import com.cg.employeeapp.service.EmployeeServiceImpl;


@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
EmployeeService employeeService=new EmployeeServiceImpl();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String action=request.getParameter("action");
			HttpSession httpSession=request.getSession();
			if(action==null) {
				try {
					List<Employee> employees=employeeService.getEmployees();
					httpSession.setAttribute("employees",employees);
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("employee.jsp");
					requestDispatcher.forward(request, response);
				} catch (EmployeeException e) {
					
				}
			}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
