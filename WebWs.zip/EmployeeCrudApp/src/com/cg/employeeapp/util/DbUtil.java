package com.cg.employeeapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.employeeapp.exception.EmployeeException;

/*to establish the connection with jdbc */

public class DbUtil {
	public static Connection getConnection() throws EmployeeException {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			return con;
		} catch (ClassNotFoundException e) {
			throw new EmployeeException(e.getMessage());
		}catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		
	}
}
