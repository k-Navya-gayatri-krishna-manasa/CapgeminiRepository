package com.cg.employeeapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;
import com.cg.employeeapp.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		List<Employee> employees=new ArrayList<Employee>();
		Connection con=DbUtil.getConnection();
		try {
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery("select * from employee_details");
			while(rs.next()) {
				Employee e=new Employee();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setGender(rs.getString(3));
				e.setAge(rs.getInt(4));
				e.setSalary(rs.getInt(5));
			}
			return employees;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	

}
