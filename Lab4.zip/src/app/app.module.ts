import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { ProductFormComponent } from './forms/product-form.component';
import { BookListComponent } from './book-list/book-list.component';
import { BooklistService } from './book-list/booklist.service';
//import { BookListTitlePipe } from './book-list/book-list-title.pipe';
import { SortListComponent } from './sort-list/sort-list.component';


import { AppRoutingModule } from './app.routing.module';
import { PageNotFoundComponent } from './movies-app/page-not-found.component';
import { MoviesAppComponent } from './movies-app/movies-app.component';
import { SearchmovieComponent } from './movies-app/searchmovie.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeComponent } from './practiceQues1/employe.component';
import { AddemployeComponent } from './practiceQues1/addemploye.component';
import { ProListComponent } from './practiceQues2/pro-list.component';
import { SearchListComponent } from './practiceQues2/search-list.component';
import { FilterPipe } from './practiceQues2/filter.pipe';
import { NoPageComponent } from './practiceQues2/no-page.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductFormComponent,
    BookListComponent,
    SortListComponent,
    EmployeeComponent,
    EmployeComponent,
    AddemployeComponent,
    PageNotFoundComponent,
    MoviesAppComponent,
    SearchmovieComponent,
    ProListComponent,
    SearchListComponent,
    FilterPipe,
    NoPageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
    
  ],
  providers: [BooklistService],
  bootstrap: [AppComponent]
})
export class AppModule { }
