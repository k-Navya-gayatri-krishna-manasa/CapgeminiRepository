import { Component, OnInit } from '@angular/core';
import { SortListService } from './sort-list.service';
import { IDetails } from './sort-list.interface';

@Component({
  selector: 'app-sort-list',
  templateUrl: './sort-list.component.html',
  styleUrls: ['./sort-list.component.css']
})
export class SortListComponent implements OnInit {

  details:IDetails[];
 

  constructor(private sortListService:SortListService) { }

  ngOnInit() {
    this.details=this.sortListService.getDetails();
  }
  sortBy(value){
    console.log("Sorting on basis of Id");
   
    this.details.sort((a,b)=>a.id>b.id?1:a.id<b.id?-1:0);
  }
  sortBy1(value){
    console.log("Sorting on basis of Name");
    this.details.sort((a,b)=>a.name>b.name?1:a.name<b.name?-1:0);
  }
  sortBy2(value){
    console.log("Sorting on basis of salary");
    this.details.sort((a,b)=>a.salary>b.salary?1:a.salary<b.salary?-1:0);
  }
  sortBy3(value){
    console.log("Sorting on basis of Department");
    this.details.sort((a,b)=>a.department>b.department?1:a.department<b.department?-1:0);
  }
}
