import { StyleCompiler } from '@angular/compiler';
export interface IDetails{
    id:number;
    name:string;
    salary:number;
    department:string;
}