import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MoviesAppComponent } from './movies-app/movies-app.component';
import { SearchmovieComponent } from './movies-app/searchmovie.component';
import { PageNotFoundComponent } from './movies-app/page-not-found.component';
import { AddemployeComponent } from './practiceQues1/addemploye.component';
import { EmployeComponent } from './practiceQues1/employe.component';
import { ProListComponent } from './practiceQues2/pro-list.component';
import { SearchListComponent } from './practiceQues2/search-list.component';
import { NoPageComponent } from './practiceQues2/no-page.component';

const routes: Routes = [
   /*  {path:"add",component:MoviesAppComponent},
    {path:"search",component:SearchmovieComponent},
    {path:"",redirectTo:"/path",pathMatch:"full"},
    {path:"**",component:PageNotFoundComponent} */
/* practice ques 1 */
   /*  {path:"list",component:EmployeComponent},
    {path:"add",component:AddemployeComponent},
    {path:"",redirectTo:"/list",pathMatch:"full"}, */
  /*   {path:"**",component:PageNotFoundComponent} */


  {path:"list",component:ProListComponent},
  {path:"search",component: SearchListComponent},
  {path:"",redirectTo:"/list",pathMatch:"full"},
  {path:"**",component:NoPageComponent}
  ];
  
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }