import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movies-app',
  templateUrl: './movies-app.component.html',
  styleUrls: ['./movies-app.component.css']
})
export class MoviesAppComponent implements OnInit {

  constructor() {
      
   }

  ngOnInit() {
  }
  onSubmit(value){
    console.log(value);
  }

}
