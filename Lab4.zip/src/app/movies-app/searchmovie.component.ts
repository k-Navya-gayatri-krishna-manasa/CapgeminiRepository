import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onSubmit(value){
    console.log(value);
  }
}
