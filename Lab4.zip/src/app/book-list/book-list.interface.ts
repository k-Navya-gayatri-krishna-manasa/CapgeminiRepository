export interface IBookList{
    bookId:number;
    bookTitle:string;
    bookAuthor:string;
    yearOfPublish:number;
}