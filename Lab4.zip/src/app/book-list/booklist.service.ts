import { Injectable } from '@angular/core';
import { IBookList } from './book-list.interface';
import {HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})


export class BooklistService {
  getBookList():Observable<IBookList[]>{
   // return this.http.get<IBookList[]>("http://localhost:3000/booklist");
    return this.http.get<IBookList[]>("../../assets/booklist.json"); 
  }
  constructor(private http:HttpClient) { }
}
