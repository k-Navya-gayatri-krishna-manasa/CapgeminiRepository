/* import { Pipe, PipeTransform } from '@angular/core';
import { IBookList } from './book-list.interface';

@Pipe({
  name: 'bookListTitle'
})
export class BookListTitlePipe implements PipeTransform {

  transform(list:IBookList[],searchTerm:string) {
    if(!list && !searchTerm){
    return list;
  }
  return list.filter(e=>e.bookTitle.toLowerCase().startsWith(searchTerm.toLowerCase()));
  }

}
 */