import { Component, OnInit } from '@angular/core';
import {BooklistService } from './booklist.service';
import { IBookList } from './book-list.interface';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  value1:number;
  name:string="Id";
  name1:string="Title";
  name2:string="Author";
  name3:string="year";
  list:IBookList[];
  list1:IBookList[];
 // searchTerm:string="";
  constructor(private bookListService:BooklistService) { 

  }

  ngOnInit() {
    this.bookListService.getBookList().subscribe((data)=>{this.list=data;this.list1=data});
    console.log(this.list);
  }

  onBookIdChange(value){
    this.list=this.list1;
    this.list=this.list.filter(b=>b.bookId===parseInt(value));
  }
  onBookTitleChange(value){
    this.list=this.list.filter(b=>b.bookTitle.toLowerCase().indexOf(value.toLowerCase())!=-1);
  }
  onBookAuthorChange(value){
    this.list=this.list.filter(b=>b.bookAuthor.toLowerCase().indexOf(value.toLowerCase())!=-1);
  }
  onBookYearChange(value){
    this.list=this.list1;
    this.list=this.list.filter(b=>b.yearOfPublish===parseInt(value));
  }

}
