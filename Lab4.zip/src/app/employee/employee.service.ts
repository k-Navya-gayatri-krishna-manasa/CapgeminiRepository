import { Injectable, Output, Input } from '@angular/core';
import { IEmployee } from './employee.interface';
//import { EmployeeFormComponent } from './employee-form.component';
//import { employee-form } from './employee-form.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService  {
 
  getEmployee():IEmployee[]{

     return[
       {
        empId:1001,empName:'Rahul',empSal:9000,empDept:'Java'
      },
      {
        empId:1002,empName:'Sachin',empSal:19000,empDept:'OraApps'
      },
      {
        empId:1003,empName:'Vikash',empSal:29000,empDept:'Bi'
      } 
    ]
  }
  constructor() {}
    
   }

