import { StyleCompiler } from '@angular/compiler';
export interface IEmployee{
    empId:number;
    empName:string;
    empSal:number;
    empDept:string;
}