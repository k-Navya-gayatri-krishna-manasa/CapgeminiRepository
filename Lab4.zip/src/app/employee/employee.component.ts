import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee.interface';
import { EmployeeService } from './employee.service';
//import { EmployeeFormComponent } from './employee-form.component';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit{
  employees:IEmployee[];
  employees1:IEmployee;
  emparr:IEmployee;
  employee:IEmployee;
  id:number;
  id1:number;
  name1:string;
  name:string;
  salary1:number;
  salary:number;
  dept:string;
  dept1:string;
  constructor(private employeeService:EmployeeService) { 
   // super();
  }
  
  
  ngOnInit() {
    this.employees=this.employeeService.getEmployee();
  }
  onSubmit(value:IEmployee){
    console.log(value);
    this.employees.push({empId:this.id,empName:this.name,empSal:this.salary,empDept:this.dept});
  }
  /* AddEmployee(value:IEmployee){
    this.employees.push(value);
  }
 */
onClick(value){
  //this code:for when I click on update button in table the data in that row comes to update form to modify
  this.employee=value;
  this.id1=this.employee.empId;
  this.name1=this.employee.empName;
  this.salary1=this.employee.empSal;
  this.dept1=this.employee.empDept;
  //this.employee.splice(this.id1,1);

}
onDelete(value){
  this.employees.splice(value,1);
}
onUpdate(value){


  /* this.employees.splice(value,1);
  this.employees.push({empId:this.id1,empName:this.name1,empSal:this.salary1,empDept:this.dept1}); */
  this.employees.forEach(e=>{
    if(e.empId==value){
      e.empName=this.name1;
      e.empSal=this.salary1;
      e.empDept=this.dept1;

    }
  })
  
}

}
