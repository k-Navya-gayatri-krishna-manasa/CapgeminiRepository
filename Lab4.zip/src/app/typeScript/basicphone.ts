/* import { Mobile } from './mobile';

export class BasicPhone extends Mobile{
    
    mobileType:string;
    constructor(){
        super();
    }
    m:Mobile=new Mobile();
    m.printMobileDetails
}
 */

