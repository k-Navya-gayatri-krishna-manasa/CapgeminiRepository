export class Mobile{
mobileId:number;
mobileName:string;
mobileCost:number;
printMobileDetails(){
    console.log(this.mobileId);
    console.log(this.mobileName);
    console.log(this.mobileCost);
}
constructor(){}

}