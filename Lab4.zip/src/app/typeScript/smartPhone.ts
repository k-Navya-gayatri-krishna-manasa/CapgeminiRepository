import { Mobile } from './mobile';

export class SmartPhone extends Mobile{
mobileType:string;
constructor(){
    super();
}
}
