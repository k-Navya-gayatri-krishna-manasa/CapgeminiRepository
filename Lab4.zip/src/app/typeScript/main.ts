import { Mobile } from './mobile';
export class Main{
   details:[number,string,number,string]=[10,"Xiaomi",8000,'Android'];
}
