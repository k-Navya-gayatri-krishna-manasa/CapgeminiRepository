export interface IPro{
    ProductId:number,
    ProductName:String,
    ProductCategory:String
}