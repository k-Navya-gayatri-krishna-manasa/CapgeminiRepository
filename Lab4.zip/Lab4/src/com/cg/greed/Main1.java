package com.cg.greed;

import java.util.Scanner;

public class Main1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age of the person:");
		Person p=new Person("Smith", sc.nextInt());
		AccClass a=new AccClass(123456,2000,p);
		SavingsAccount sa=new SavingsAccount();
		sa.deposit(2000);
		sa.withdraw(1500);
		CurrentAccount ca=new CurrentAccount();
		System.out.println("Enter amount to withdrawl");
		ca.withdraw(sc.nextInt());

	}

}
