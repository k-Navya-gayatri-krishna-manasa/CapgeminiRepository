package com.cg.greed;

import java.util.Scanner;

public class Person extends AccountClass {
	static Scanner sc=new Scanner(System.in);

	
	private static final Exception Exception = null;
	protected String name;
	protected int age;
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		
	}
	

	
//for sake of question 6.2 Here I declared user defined exception 
	public Person(String name, int age) {
		int a=age;
		if(a>15)
			this.age = age;
		else {
			try {
				throw new MyException("Entered age is out of range.It should be greater than 15");
			}
			catch(MyException e) {
				//e.printStackTrace();
				System.out.println(e);
				//a=sc.nextInt();
			}
			}
		
		this.name = name;
		
	}

//THIS CODE IS NOT REQUIRED FOR 6.3,4.2 ONLY NEEDED FOR 4.1
	/*public static void main(String[] args) {
		
		Person p=new Person("Smith", 23);
		Person p1=new Person("Karthy", 28);
		AccountClass ac1=new AccountClass(123456,2000,p);
		AccountClass ac2=new AccountClass(123978,3000,p1);
		ac1.deposit(2000);
		ac2.withdraw(2000);
		System.out.println("Smith balance is:"+ac1.getBalance());
		System.out.println("Karthy balance is:"+ac2.getBalance());
	}*/

}
class MyException extends Exception{
	  String str1;
	 MyException(String str2) {
			str1=str2; 
	 }
	public String toString(){ 
			return ("MyException Occurred: "+str1) ;
	}
}



