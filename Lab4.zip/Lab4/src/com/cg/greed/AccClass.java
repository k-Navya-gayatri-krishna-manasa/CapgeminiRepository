package com.cg.greed;

public class AccClass {
	
	
	 public long accountnum;
		public double balance=0.0;
		Person accHolder;
		public long getAccountnum() {
			return accountnum;
		}
		public void setAccountnum(long accountnum) {
			this.accountnum = accountnum;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public Person getAccHolder() {
			return accHolder;
		}
		public void setAccHolder(Person accHolder) {
			this.accHolder = accHolder;
		}
		
		public void deposit(double d) {
			balance=balance+d;
			//System.out.println("Your present balance:" +balance);
			
					
		}
		
		public AccClass() {
			super();
		}
		public AccClass(long accountnum, double balance, Person accHolder) {
			super();
			this.accountnum = accountnum;
			this.balance = balance;
			this.accHolder = accHolder;
		}
		public void withdraw(double d) {
			}
		
			
		}
		


