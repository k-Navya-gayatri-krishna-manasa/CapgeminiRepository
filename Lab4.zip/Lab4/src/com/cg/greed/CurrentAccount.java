package com.cg.greed;

import java.util.Scanner;

public class CurrentAccount extends AccClass {
	

	Scanner sc=new Scanner(System.in);
	
	private double overdraftlimit=10000,balance=5000;
	int amount;

	@Override
	public void withdraw(double required) {
		
		if(balance+overdraftlimit<required) {
			//return true;
			System.out.println("true:The amount u required is more than bal+overdraft");
		}
		else
			System.out.println("False:The amount u required is less than bal+overdraft");
		
	
		
	}


	public CurrentAccount() {
		super();
	}
	
	
	
}	
	
