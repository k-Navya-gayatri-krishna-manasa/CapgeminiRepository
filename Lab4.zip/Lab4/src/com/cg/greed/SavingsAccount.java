package com.cg.greed;

public class SavingsAccount extends AccClass {
	public final int minbalance=500;
	

	
	

	@Override
	public void withdraw(double withdrawlamount) {
		if((balance-withdrawlamount) >=minbalance) {
			balance=balance-withdrawlamount;
			System.out.println("Amount withdrawn");
		}
		else
		System.out.println("Your account dont have sufficient amount to withdraw");
	}


	public SavingsAccount() {
		super();
	}
	

	

}
