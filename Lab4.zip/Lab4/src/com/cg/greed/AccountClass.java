package com.cg.greed;

public class AccountClass extends Account {
	//here I have extebnded account class for sake of question 5.3
	
		 private long accountnum;
		private double balance;
		Person accHolder;
		public long getAccountnum() {
			return accountnum;
		}
		public void setAccountnum(long accountnum) {
			this.accountnum = accountnum;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public Person getAccHolder() {
			return accHolder;
		}
		public void setAccHolder(Person accHolder) {
			this.accHolder = accHolder;
		}
		
		public void deposit(double d) {
			balance=balance+d;
			//System.out.println("Your present balance:" +balance);
			
					
		}
		public AccountClass(long accountnum, double balance, Person accHolder) {
			super();
			this.accountnum = accountnum;
			this.balance = balance;
			this.accHolder = accHolder;
		}
		
		public AccountClass() {
			super();
		}
		public void withdraw(double d) {
			if(balance>500) {
				balance=balance-d;
				//System.out.println("Your present balance:" +balance);
			}
			
		}
		
	}



