package com.cg.greed;

public abstract class Account {
	public void withdraw(double d) {
	
	}

}
