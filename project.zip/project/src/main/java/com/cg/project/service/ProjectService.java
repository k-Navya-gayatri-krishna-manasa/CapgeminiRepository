package com.cg.project.service;

import java.util.List;

import com.cg.project.dto.Item;
import com.cg.project.dto.PurchaseDetails;
import com.cg.project.dto.Transaction;

public interface ProjectService {
	
	public Transaction create(Transaction transaction);
	public List<Transaction> getAll();
	public Transaction update(Transaction j);
	public List<Item> getByOrderId(Integer orderId);
	public List<Item> getByName(String itemName) ;
	public String getDeliveryDetail(Integer orderId);
	public Integer getByNameId(String itemName);

}
