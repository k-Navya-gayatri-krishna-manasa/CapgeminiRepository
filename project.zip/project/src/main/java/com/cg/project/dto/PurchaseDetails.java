package com.cg.project.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "purchasedetails")
@XmlRootElement(name = "purchasedetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class PurchaseDetails {
	@XmlAttribute(name="OrderId")
	
	private Integer orderId;
	@XmlElement
	private List<Item> items;
	@XmlElement
	private Double totalAmount;
	public Double getTotalAmount() {
		return totalAmount;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	public PurchaseDetails() {
		super();
	}
	@Override
	public String toString() {
		return "PurchaseDetails [orderId=" + orderId + ", items=" + items + ", totalAmount=" + totalAmount + "]";
	}
	
	public PurchaseDetails(Integer orderId, List<Item> items, Double totalAmount) {
		super();
		this.orderId = orderId;
		this.items = items;
		this.totalAmount = totalAmount;
	}
	
	
	

}
