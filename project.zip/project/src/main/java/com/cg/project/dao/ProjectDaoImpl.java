package com.cg.project.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.project.dto.Delivery;
import com.cg.project.dto.Item;
import com.cg.project.dto.PurchaseDetails;
import com.cg.project.dto.Transaction;
import com.cg.project.dto.TransactionDetails;

@Repository
public class ProjectDaoImpl implements ProjectDao{

	@Autowired
	MongoTemplate mongotemplate;
	
	
	@Override
	public Transaction create(Transaction transaction) {
		// TODO Auto-generated method stub
		return mongotemplate.save(transaction);
	}

	@Override
	public List<Transaction> getAll() {
		System.out.println("dao");
		return mongotemplate.findAll(Transaction.class);
	}
	
	@Override
	public Transaction update(Transaction j) {
		// TODO Auto-generated method stub
		return mongotemplate.save(j);
	}

	@Override
	public List<Item> getByOrderId(Integer orderid) {
		
		List<Item> items=null;
		List<Transaction> transactions=mongotemplate.findAll(Transaction.class);
		for(Transaction transaction1:transactions) {
			List<TransactionDetails> transactionDetails=transaction1.getTransactionDetails();
			for(TransactionDetails details:transactionDetails) {
				PurchaseDetails purchaseDetails=details.getPurchaseDetails();
				if(purchaseDetails.getOrderId().equals(orderid)) {
					items=purchaseDetails.getItems();
					
				}
			}
		}
		return items;
	}

	@Override
	public List<Item> getByName(String itemName) {
		List<Item> items=new ArrayList<Item>();
		List<Transaction> transactions=mongotemplate.findAll(Transaction.class);
		for(Transaction transaction1:transactions) {
			List<TransactionDetails> transactionDetails=transaction1.getTransactionDetails();
			for(TransactionDetails details:transactionDetails) {
				PurchaseDetails purchaseDetails=details.getPurchaseDetails();
				List<Item> i=purchaseDetails.getItems();
				for(Item item:i) {
					if(item.getItemName().equalsIgnoreCase(itemName)) {
					items.add(item);
				}
				}
			}
		}
		return items;
	}
	
	@Override
	public Integer getByNameId(String itemName) {
		List<Item> items=new ArrayList<Item>();
		int id = 0;
		List<Transaction> transactions=mongotemplate.findAll(Transaction.class);
		for(Transaction transaction1:transactions) {
			List<TransactionDetails> transactionDetails=transaction1.getTransactionDetails();
			for(TransactionDetails details:transactionDetails) {
				PurchaseDetails purchaseDetails=details.getPurchaseDetails();
				List<Item> i=purchaseDetails.getItems();
				System.out.println("i"+i);
				for(Item item:i) {
					if(item.getItemName().equalsIgnoreCase(itemName)) {
					id=purchaseDetails.getOrderId();
				}
				}
			}
		}
		return id;
	}
	
	
	@Override
	public String getDeliveryDetail(Integer orderId) {
		String result = null;
		System.out.println(orderId);
		List<Transaction> transactions=mongotemplate.findAll(Transaction.class);
		for(Transaction transaction1:transactions) {
			List<TransactionDetails> transactionDetails=transaction1.getTransactionDetails();
			for(TransactionDetails details:transactionDetails) {
				PurchaseDetails purchaseDetails=details.getPurchaseDetails();
				Delivery d=details.getDelivery();
				if(purchaseDetails.getOrderId()==orderId) {
					result=d.getDeliveryStatus(); 
				}
				
			}
			
		}
		return result;
	}
	
	


	
}
