package com.cg.project.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transactions")
@XmlRootElement
public class Transaction {
	
	private Integer retailStoreID;
	  private List<TransactionDetails> transactionDetails;

	public Transaction() {
		
	}

	public Integer getRetailStoreID() {
		return retailStoreID;
	}

	public void setRetailStoreID(Integer retailStoreID) {
		this.retailStoreID = retailStoreID;
	}

	public List<TransactionDetails> getTransactionDetails() {
		return transactionDetails;
	}

	public void setTransactionDetails(List<TransactionDetails> transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	public Transaction(Integer retailStoreID, List<TransactionDetails> transactionDetails) {
		super();
		this.retailStoreID = retailStoreID;
		this.transactionDetails = transactionDetails;
	}

	@Override
	public String toString() {
		return "Transaction [retailStoreID=" + retailStoreID + ", transactionDetails=" + transactionDetails + "]";
	}

	
	
	
	

}
