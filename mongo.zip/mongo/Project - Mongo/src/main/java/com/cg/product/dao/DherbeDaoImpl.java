package com.cg.product.dao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.cg.product.dto.DherbeBeauty;
import com.cg.product.dto.DherbeSanitation;

@Repository
public class DherbeDaoImpl implements DherbeDao{

	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public List<DherbeBeauty> showAllProducts() {
		return mongoTemplate.findAll(DherbeBeauty.class);
	}

	
	@Override
	public DherbeBeauty searchByProductId(int proId) {
		
		return null;
	}


	@Override
	public DherbeBeauty saveProduct(DherbeBeauty dherbebeauty) {
		
		return mongoTemplate.insert(dherbebeauty);
	}

	@Override
	public void deleteProduct(String proId) {
		// TODO Auto-generated method stub
		DherbeBeauty dherbe=mongoTemplate.findById(proId, DherbeBeauty.class);
		mongoTemplate.remove(dherbe);
		
		
	}
	
	public DherbeBeauty updateProduct(String proid,String price,String stock) {
		
		DherbeBeauty dherbe=mongoTemplate.findById(proid, DherbeBeauty.class);
		dherbe.setProdPrice(price);
		dherbe.setStock(stock);
		mongoTemplate.save(dherbe);
		return dherbe;
	}

	

	
	

}
