package com.cg.product.service;

import java.util.List;

import com.cg.product.dto.DherbeBeauty;
import com.cg.product.dto.DherbeSanitation;

public interface DherbeSanitationSer {
	public List<DherbeSanitation> showAllProducts();
	
	public DherbeSanitation searchByProductId(int proId);
	public DherbeSanitation saveProduct(DherbeSanitation dherbeSanitation);
	public List<DherbeSanitation> getProductByName(String prodName);
	public void deleteProduct(String proId); 
	public DherbeSanitation updateProduct(String proid,String price,String stock);
	
	
}
