package com.cg.product.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.DherbeSanitation;

@Repository
public class DherbeSanitationDaoImpl implements DherbeSanitationDao{
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public List<DherbeSanitation> showAllProducts() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(DherbeSanitation.class);
	}

	@Override
	public DherbeSanitation find(int proId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public DherbeSanitation saveProduct(DherbeSanitation dherbeSanitation) {
		return mongoTemplate.insert(dherbeSanitation);
	}
	
	@Override
	public List<DherbeSanitation> getProductByName(String prodName) {
		// TODO Auto-generated method stub
		 List<DherbeSanitation> list=mongoTemplate.findAll(DherbeSanitation.class);
		 List<DherbeSanitation> list1=new ArrayList<>();
		 for(DherbeSanitation sanitation:list) {
		  if(sanitation.getProdName().equals(prodName)) {
		   list1.add(sanitation); 
		  }
		 }
		 return list1;
		}
	
	@Override
	public void deleteProduct(String proId) {
		// TODO Auto-generated method stub
		DherbeSanitation emp=mongoTemplate.findById(proId, DherbeSanitation.class);
		mongoTemplate.remove(emp);
		
		
	}
	
	public DherbeSanitation updateProduct(String proid,String price,String stock) {
		
		DherbeSanitation dherbe=mongoTemplate.findById(proid, DherbeSanitation.class);
		dherbe.setProdPrice(price);
		dherbe.setStock(stock);
		mongoTemplate.save(dherbe);
		return dherbe;
	}

}
