package com.cg.mobileapp.service;

import java.util.List;

import com.cg.mobileapp.dao.IMobileDao;
import com.cg.mobileapp.dao.MobileDao;
import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;

public class MobileService implements IMobileService {
	
	private IMobileDao mobileDao;
	
		
		public MobileService() {
			 mobileDao=new MobileDao();
		}
		@Override
		public List<Mobile> getAllMobiles() throws MobileException {
			return mobileDao.getAllMobiles();
		}
		public boolean validate(PurchaseDetails purchaseDetails,String mobileId) throws MobileException {
			
			boolean flag=true;
			StringBuilder sb=new StringBuilder();//to write the error msg
			if(!validatename(purchaseDetails.getCustomerName())) {
				sb.append("Invalid Name, Name should start with a capital letter followed by <=20 alphabets");
				sb.append("\n");
				flag=false;
			}
			if(!validateemail(purchaseDetails.getMailId())){
				sb.append("Invalid Mail Id");
				sb.append("\n");
				flag=false;
			}
			if(!validatePhone(purchaseDetails.getPhoneNo())){
				sb.append("Invalid Mobile Number");
				sb.append("\n");
				flag=false;
			}
			if(!validateMobileId(mobileId)){
				sb.append("Invalid Mobile Id");
				sb.append("\n");
				flag=false;
			}
			
			if(flag) {
				return flag;
			}
			else {
				throw new MobileException(sb.toString());
			}
		}
		private boolean validatename(String name) {
			return name.matches("[A-Z][A-Za-z\\s]{2,19}");
		}
		private boolean validateemail(String email) {
			return email.matches("[a-z][a-z0-9_\\.]+@[a-z]+\\.(com|net|in)");
		}
		private boolean validatePhone(String mobile) {
			return mobile.matches("\\d{10}");
		}
		private boolean validateMobileId(String phone) {
			return phone.matches("\\d{4}");
		}
		@Override
		public int insertpurchaseDetails(PurchaseDetails purchaseDetails, String mobileId) throws MobileException {
			
			return mobileDao.insertpurchaseDetails(purchaseDetails, mobileId);
		}
		@Override
		public void deleteMobile(int mobileId) throws MobileException {
			 mobileDao.deleteMobile(mobileId);
			
		}
		@Override
		public List<Mobile> getAllMobilesWithRange(double range1, double range2) throws MobileException {
			// TODO Auto-generated method stub
			return mobileDao.getAllMobilesWithRange(range1, range2);
		}

}
