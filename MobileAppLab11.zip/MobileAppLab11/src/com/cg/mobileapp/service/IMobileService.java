package com.cg.mobileapp.service;

import java.util.List;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;

public interface IMobileService {
	List<Mobile> getAllMobiles()throws MobileException;
	public boolean validate(PurchaseDetails purchaseDetails,String mobileId) throws MobileException;
	int insertpurchaseDetails(PurchaseDetails purchaseDetails,String mobileId) throws MobileException;
	public void deleteMobile(int mobileId) throws MobileException;
	List<Mobile> getAllMobilesWithRange(double range1,double range2)throws MobileException;


}
