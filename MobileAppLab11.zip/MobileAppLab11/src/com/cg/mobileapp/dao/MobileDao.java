package com.cg.mobileapp.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.cg.mobileapp.db.MobileDb;
import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;
/***
 * Author:K.Navya Gayatri Krishna Manasa
 *Date of Creation: 18-06-2019
 *Purpose:This Class is used for accessing and performing different data access operations
 * * * 
 */
public class MobileDao implements IMobileDao {
	private static int id=1;  
	
	private Map<Integer,Mobile> mobileDb;
	private Map<Integer,PurchaseDetails> salesDb;
	
	
	
	public MobileDao() {
		mobileDb=MobileDb.getMobileDetails();
		salesDb=MobileDb.getPurchaseInfo();
	}

/***
 *  Author:K.Navya Gayatri Krishna Manasa
 *  Date of Creation: 18-06-2019
 * Method Name:getAllMobiles
 * Parameters:None
 * return Value:List<Mobile>
 * purpose:Retrieves all the data from the mobileDb
 */

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		List<Mobile> mobiles=new ArrayList<>();
		for(Integer key:mobileDb.keySet()) {
			Mobile mobile=mobileDb.get(key);
			mobiles.add(mobile);
			
		}
		return mobiles;
	}

@Override
public int insertpurchaseDetails(PurchaseDetails purchaseDetails, String mobileId) throws MobileException {
	
	int seqId=MobileDao.id;
	if(mobileDb.containsKey(Integer.parseInt(mobileId))) {
		Mobile mobile=mobileDb.get(Integer.parseInt(mobileId));
		if(mobile.getQuantity()>0) {
			purchaseDetails.setDate(new Date());
			salesDb.put(MobileDao.id++,purchaseDetails );
			mobile.setQuantity(mobile.getQuantity()-1);
			mobileDb.put(Integer.parseInt(mobileId), mobile);
		}
	
	else {
		throw new MobileException("Out of stock");
	}
	}
	else {
		throw new MobileException("No mobile with that Id is available");
	}
	
	return seqId;
}

@Override
public void deleteMobile(int mobileId) throws MobileException {
	if(mobileDb.containsKey(mobileId)) {
		mobileDb.remove(mobileId);
	}else {
		throw new MobileException("No Mobile with that Id");
	}
}

@Override
public List<Mobile> getAllMobilesWithRange(double range1,double range2) throws MobileException {
	List<Mobile> mobiles=new ArrayList<>();
	for(Mobile m:mobileDb.values()) {
		if(m.getPrice()>range1 && m.getPrice()<range2) {
			mobiles.add(m);
		}
	}
	return mobiles;
}

//@Override
/*public List<Mobile> getMobileByPrice(double price) throws MobileException {
	
	List<Mobile> mobile=getAllMobiles().stream().filter(e->e.getInsScheme().equals(scheme)).collect(Collectors.toList());
	if(mobile.size()==0) {
		throw new MobileException("No mobile found");
	}
	else {
		return mobile;
	}
}


}
class MobileComparator implements Comparator<Mobile>{
public int compare(Mobile m1,Mobile m2) {
	if(m1.getPrice()>m2.getPrice())
		return -1;
	else if(m1.getPrice()<m2.getPrice())
		return 1;
	else
		return 0;

}
	
	
*/


}
