package com.cg.mobileapp.dao;

import java.util.List;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;

public interface IMobileDao {
	List<Mobile> getAllMobiles()throws MobileException;
	int insertpurchaseDetails(PurchaseDetails purchaseDetails,String mobileId) throws MobileException;
	void deleteMobile(int mobileId) throws MobileException;
	//List<Mobile> getMobileByPrice(double price) throws MobileException;
	List<Mobile> getAllMobilesWithRange(double range1,double range2)throws MobileException;
}
