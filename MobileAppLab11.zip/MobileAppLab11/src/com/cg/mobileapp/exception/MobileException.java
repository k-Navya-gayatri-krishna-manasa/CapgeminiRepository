package com.cg.mobileapp.exception;

public class MobileException extends Exception{
	
		public  MobileException(){
			super();
		}
		public  MobileException(String message) {
			super(message);
		}
	
}
