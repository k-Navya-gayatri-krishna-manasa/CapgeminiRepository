package com.cg.mobileapp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;
import com.cg.mobileapp.service.IMobileService;
import com.cg.mobileapp.service.MobileService;

public class Client {
	static Scanner scanner=new Scanner(System.in);
	static IMobileService mobileService=new MobileService();
		
	public static void main(String[] args) {
		 int reply;
		while(true) {
			System.out.println("1.Display Mobiles");
			System.out.println("2.Purchase Mobile");
			System.out.println("3.Delete Mobile");
			System.out.println("4.View Mobile based on price range");
			System.out.println("Enter choice");
			reply=scanner.nextInt();
			scanner.nextLine();
			switch(reply) {
			case 1:
				displayMobiles();
				break;
			case 2:
				purchaseMobile();
				break;
			case 3:
				deleteMobileWithId();
				break;
			case 4:
				viewBasedonRange();
				break;
			case 5:
				System.exit(0);
			default:
				System.out.println("Invalid option");
			}
		}
	}
	private static void displayMobiles() {
		try {
			List<Mobile> mobiles=mobileService.getAllMobiles();
			System.out.println("Mobile Id\tMobile Name \t\t Price \t\t Quantity");
			for(Mobile mobile:mobiles) {
				System.out.println(mobile.getMobileId()+"\t\t"+mobile.getName()+"\t\t"+mobile.getPrice()+"\t\t"+mobile.getQuantity());
			}
		}catch(MobileException e) {
			System.err.println(e.getMessage());
		}
	}
	private static void purchaseMobile() {
		PurchaseDetails purchaseDetails=new PurchaseDetails();
		System.out.println("Enter customer name");
		purchaseDetails.setCustomerName(scanner.nextLine());
		System.out.println("Enter Mail id:");
		purchaseDetails.setMailId(scanner.nextLine());
		System.out.println("Phone Number");
		purchaseDetails.setPhoneNo(scanner.nextLine());
		System.out.println("Mobile Id:");
		String mobileId=scanner.nextLine();
		try {
			boolean result=mobileService.validate(purchaseDetails, mobileId);
			int id=mobileService.insertpurchaseDetails(purchaseDetails, mobileId);
			System.out.println("Your order placed.Purchase Id is:"+id);
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
	}
	private static void deleteMobileWithId() {
		System.out.println("Mobile Id:");
		try {
		int mobileId=scanner.nextInt();
		
			mobileService.deleteMobile(mobileId);
			System.out.println("Mobile with the id"+mobileId+"deleted");
		}catch(MobileException e) {
			System.err.println(e.getMessage());
		}

	}
	private static void viewBasedonRange() {
		double range1,range2;
		System.out.println("Enter lower range and upper range");
		range1=scanner.nextDouble();
		range2=scanner.nextDouble();
		List<Mobile> mobiles;
		try {
			mobiles = mobileService.getAllMobilesWithRange(range1, range2);
			System.out.println("Mobile Id\tMobile Name \t\t Price \t\t Quantity");
			for(Mobile mobile:mobiles) {
				System.out.println(mobile.getMobileId()+"\t\t"+mobile.getName()+"\t\t"+mobile.getPrice()+"\t\t"+mobile.getQuantity());
			}
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
		
	}
}
