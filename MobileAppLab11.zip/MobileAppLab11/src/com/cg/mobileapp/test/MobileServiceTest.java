package com.cg.mobileapp.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.cg.mobileapp.dao.IMobileDao;
import com.cg.mobileapp.dao.MobileDao;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;
import com.cg.mobileapp.service.IMobileService;
import com.cg.mobileapp.service.MobileService;

public class MobileServiceTest {

	@Test
	public void testInsertpurchaseDetails() throws MobileException {
		IMobileService service=new MobileService();
		PurchaseDetails purchaseDetails=new PurchaseDetails();
		purchaseDetails.setCustomerName("Anil");
		purchaseDetails.setMailId("reni@gmail.com");
		purchaseDetails.setPhoneNo("9987654678");
		String mobileId="1001";
		int result=service.insertpurchaseDetails(purchaseDetails, mobileId);
		assertEquals(2,result);
	}
	@Test(expected=MobileException.class)
	public void testException() throws MobileException {
		IMobileService service=new MobileService();
		PurchaseDetails purchaseDetails=new PurchaseDetails();
		purchaseDetails.setCustomerName("Anil");
		purchaseDetails.setMailId("reni@gmail.com");
		purchaseDetails.setPhoneNo("9987654678");
		String mobileId="1001";
		int result=service.insertpurchaseDetails(purchaseDetails, mobileId);
		
	}
	@Test
	public void testGetMobiles() throws MobileException {
		IMobileDao dao=new MobileDao();
		assertEquals(3,dao.getAllMobiles().size());//1st parameter represents the size of list mobiles
		//2nd parameter returns the size of list dynamically..if both are equal testcase is true
		assertNotNull(dao.getAllMobiles());
	}

}
