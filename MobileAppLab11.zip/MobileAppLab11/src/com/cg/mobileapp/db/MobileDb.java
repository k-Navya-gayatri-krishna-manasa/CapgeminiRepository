package com.cg.mobileapp.db;

import java.util.HashMap;
import java.util.Map;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;

public class MobileDb {
	
	private static Map<Integer,Mobile> mobileDetails=
			new HashMap<>();
	private static Map<Integer,PurchaseDetails> purchaseInfo=
			new HashMap<>();
	static {
		mobileDetails.put(1001,new Mobile(1001,"Nokia Lumia 520",8000,20));
		mobileDetails.put(1002,new Mobile(1002,"Samsung Galaxy IV",38000,40));
		mobileDetails.put(1003,new Mobile(1003,"Sony Xperia C",15000,30));	
	}
	public static Map<Integer, Mobile> getMobileDetails() {
		return mobileDetails;
	}
	public static Map<Integer, PurchaseDetails> getPurchaseInfo() {
		return purchaseInfo;
	}
	
	
}
