package com.cg.mobileapp.dto;

import java.util.Date;

public class PurchaseDetails {
	private int purchaseId;
	private String customerName;
	private String mailId;
	private String phoneNo;
	private Date date;
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public PurchaseDetails(int purchaseId, String customerName, String mailId, String phoneNo, Date date) {
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.date = date;
	}
	public PurchaseDetails() {
	}
	
	
}
