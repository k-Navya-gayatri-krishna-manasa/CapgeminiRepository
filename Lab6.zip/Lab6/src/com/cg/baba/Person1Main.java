package com.cg.baba;

import java.util.Scanner;

public class Person1Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Person1 p1=new Person1();
		System.out.println("Enter firstname:");
		p1.setFirstname(sc.nextLine());
		System.out.println("Enter lastname");
		p1.setLastname(sc.nextLine());
		System.out.println("Enter gender:");
		p1.setGender(sc.nextLine());
		p1.findfullname(p1.getFirstname(),p1.getLastname());

	}

}
