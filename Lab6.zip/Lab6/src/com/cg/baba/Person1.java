package com.cg.baba;

public class Person1 {
	private static final Exception Exception = null;
	private String firstname,lastname;
	private String gender;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Person1() {
		super();
	}
	public static void findfullname(String firstname, String lastname) {
		if(firstname!=null && !firstname.isEmpty()) {
			if(lastname!=null && !lastname.isEmpty()) {
				String fullname=firstname+" "+lastname;
				System.out.println("Full nameis:"+fullname);
			}
			
		}else {
			try {
				throw Exception;
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
