import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ShowComponent } from './app.showcomponent';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';

const routes: Routes = [
  {path:"empshow",component:ShowComponent},
  {path:"addemp",component:AddemployeeComponent},
  {path:"updateemp",component:UpdateemployeeComponent},
  {path:"",redirectTo:"/empshow",pathMatch:"full"}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
