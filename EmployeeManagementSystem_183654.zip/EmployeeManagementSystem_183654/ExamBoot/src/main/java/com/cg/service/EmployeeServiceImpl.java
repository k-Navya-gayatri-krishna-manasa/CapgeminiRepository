package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeRepository;
import com.cg.exception.EmployeeException;
import com.cg.exception.ExceptionMessage;


@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeRepository repository;
	
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name:createEmployee
	 * Parameters:1 parameter of type Employee
	 * return Value:adds details to Employee table
	 * purpose:To save the employee details into Employee table
	 */
	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		try {
			repository.save(employee);
		}catch (Exception exception) {
			throw new EmployeeException(ExceptionMessage.MESSAGE1);
		}
		return repository.findAll();
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name:updateEmployee
	 * Parameters:1 parameter of type Employee
	 * return Value:updates details of employee
	 * purpose: saves the updated employee details into Employee table
	 */
	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException {
		Optional<Employee> employees = repository.findById(employee.getEmpId());
		Employee employees1=employees.get();
		try {
			employees1.setName(employee.getName());
			employees1.setDesignation(employee.getDesignation());
			employees1.setSalary(employee.getSalary());
			employees1.setDeptName(employee.getDeptName());
				repository.save(employees1);
		}
		catch (Exception exception) {
			throw new EmployeeException(ExceptionMessage.MESSAGE2);
		}
		return employees1;
		
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name:deleteEmployee
	 * Parameters:1empId parameter of type Integer
	 * purpose:deletes the employee detail mentioned from Employee table
	 */
	@Override
	public void deleteEmployee(Integer empId) throws EmployeeException {
		 Optional<Employee> employee = repository.findById(empId);
		 try {
			 repository.deleteById(empId);
		 }
		 catch (Exception exception) {
				throw new EmployeeException(ExceptionMessage.MESSAGE3);
		}
		
		
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name: viewEmployeeList
	 * Parameters:No parameters
	 * return Value:returns all the employees list
	 * purpose: to get all the details from the employee database
	 */
	@Override
	public List<Employee> viewEmployeeList() throws EmployeeException {
		try {
			return repository.findAll();
		}
		catch (Exception exception) {
			throw new EmployeeException(ExceptionMessage.MESSAGE4);
		}
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name: findEmployee
	 * Parameters:parameter of type Integer 
	 * return Value:returns the employee list of given Id
	 * purpose: to get the employee details from the employee database
	 */
	@Override
	public Employee findEmployee(Integer empId) {
				return repository.findById(empId).get();
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 23-07-2019
	 * Method Name: getEmployeeBydepartmentName
	 * Parameters: 1 parameter of type String 
	 * return Value:returns the employee list of given department name
	 * purpose: to get the employee details from the employee database for the given department name
	 */
	@Override
	public List<Employee> getEmployeeBydepartmentName(String deptName) throws EmployeeException {
		List<Employee> employee=repository.findAll();
		List<Employee> employees=new ArrayList<>();
		try {
		for(Employee empList:employee) {
			if(empList.getDeptName().equals(deptName)) {
				employees.add(empList);	
			}
		}
		}catch (Exception exception) {
			throw new EmployeeException(ExceptionMessage.MESSAGE6);
		}
		return employees;
	}

}
