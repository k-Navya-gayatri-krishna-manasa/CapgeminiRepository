package com.cg.bbb;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Mains {

	public static void main(String[] args) throws IOException {
		Properties pro=new Properties();
		pro.setProperty("db.driver","oracle.jdbc.driver.OracleDriver");
		pro.setProperty("url", "jdbc:oracle:thin:@localhost:1521:ORCL");
		pro.setProperty("user", "Manu");
		pro.setProperty("password", "pwd");
		FileOutputStream out=new FileOutputStream("db.properties");
		pro.store(out, "this is database specific file");
		out.close();
		System.out.println("Done");
		

	}

}
