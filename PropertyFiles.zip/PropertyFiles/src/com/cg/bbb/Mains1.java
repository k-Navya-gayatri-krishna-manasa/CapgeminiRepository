package com.cg.bbb;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Mains1 {

	public static void main(String[] args) throws IOException{
		Properties p=new Properties();
		p.load(new FileInputStream("data.properties"));
		System.out.println(p.getProperty("fruits"));
		

	}

}
