package com.cg.bbb;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Set;

public class Main {

	public static void main(String[] args) throws IOException{
		FileInputStream fis=new FileInputStream("data.properties");
		Properties props=new Properties();
		props.load(fis);
		System.out.println(props.getProperty("name"));
		System.out.println(props.getProperty("city"));
		System.out.println(props.getProperty("company"));
		System.out.println(props.getProperty("mobile"));
		System.out.println(props.getProperty("mobile","abcd"));
		System.out.println();
		System.out.println(props.contains("Capgem"));
		System.out.println(props.containsKey("name"));
		PrintStream p=new PrintStream("datacopy.txt");
		props.list(p);
		p.close();
		//PrintWriter p=new PrintWriter("myfile.txt");
		//props.list(p);
		//p.close();
		System.out.println("---------------------------------");
		Enumeration e=props.elements();
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement());
		}
		System.out.println("---------------------------------");
		Enumeration ep=props.propertyNames();
		while(ep.hasMoreElements()) {
			//System.out.println(e.nextElement());
			String key=(String)ep.nextElement();
			System.out.println(key+"-"+props.getProperty(key));
			}
		System.out.println("---------------------------------");
		Set<String>names=props.stringPropertyNames();
		for(String string:names) {
			System.out.println(string+"-"+props.getProperty(string));
		}
	}

}
