package cg.coll.com;

public class MyUtil<T> {
	
	public boolean areEqual(T i,T j) {
		return i.equals(j);
	}

}
