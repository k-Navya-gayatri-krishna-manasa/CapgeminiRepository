package cg.coll.com;

import java.util.HashMap;
import java.util.Map;

public class MapsExm {

	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(101,"sunil");
		map.put(102,"Anil");
		map.put(103,"shiva");
		
		//to access the value of particular key
		//System.out.println(map.get(102));
		
		//to get keyvalue pairs
		for(Integer i:map.keySet())
		{
			System.out.println(i+":"+map.get(i));
		}
		
		//to get the values 
		for(String name:map.values())
		{
			System.out.println(name);
		}
		
		//another way to iterate into the map and print the values
		for(Map.Entry<Integer,String> entry:map.entrySet()) {
			System.out.println(entry.getKey()+":"+entry.getValue());
		}

	}

}
