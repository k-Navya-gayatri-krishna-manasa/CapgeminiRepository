package cg.coll.com;

public class Exm {

	public static void main(String[] args) {
		Object obj=new Integer(10);
		Object[] objarr=new Integer[5];

	}


}
