package cg.coll.com;

import java.util.SortedSet;
import java.util.TreeSet;

public class TreesetExm {

	public static void main(String[] args) {
		SortedSet<Integer> set=new TreeSet<Integer>();
		set.add(10);
		set.add(20);
		set.add(30);set.add(40);
		SortedSet<Integer> copy=set.subSet(10, 30);
		set.add(12);
		set.add(25);
		for(Integer integer:copy) {
			System.out.println(integer);
		}

	}

}
