package cg.coll.com;

import java.util.Set;
import java.util.TreeSet;

public class ExmOnSets {

	public static void main(String[] args) {
		/*Set set=new HashSet();
		set.add(10);
		set.add("abcd");
		set.add(23.5);
		set.add("abcd");
		for(Object obj:set) {
			System.out.println(obj);
		}
		*/
		Set set=new TreeSet();
		set.add(10);
		set.add(5);
		set.add(23);
		for(Object obj:set) {
			System.out.println(obj);
		}

	}

}
