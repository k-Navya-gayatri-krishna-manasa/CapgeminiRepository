package cg.coll.com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

public class Example1 {

	public static void main(String[] args) {
		List list=new ArrayList();
		list.add(10);
		list.add("Hello");
		list.add(23.56);
		for(Object obj:list) {
			System.out.println(obj);
		}
		System.out.println(list.size());
		Enumeration e=Collections.enumeration(list);
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement());
		}
		Iterator it=list.iterator();
		while(it.hasNext()) {
			//System.out.println(it.next());
			//to remove an element
			if(it.next().equals("Hello")) {
				it.remove();
			}
			}
		System.out.println();
		it=list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		}

	}


