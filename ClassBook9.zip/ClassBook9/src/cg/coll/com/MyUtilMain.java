package cg.coll.com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MyUtilMain {

	public static void main(String[] args) {
		
		/*MyUtil<String> util=new MyUtil<String>();
		boolean result=util.areEqual("abc","abcd");
		System.out.println(result);
		*/
		
		//Array list that stores strings
		
		List<String> list=new ArrayList<String>();
		list.add("sai");
		list.add("krishna");
		list.add("pavan");
		System.out.println(list);
		Collections.sort(list);
		System.out.println(list);
	}

}
