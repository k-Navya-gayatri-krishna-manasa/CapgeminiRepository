package cg.coll.com;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class Exm2 {

	public static void main(String[] args) {
		List list=new Vector();
		list.add(10);
		list.add("Hello");
		list.add(23.56);
		
		/*ListIterator it=list.listIterator();
		while(it.hasNext()) {
			Object i=it.next();
			System.out.println(i);
		}
		System.out.println();
		while(it.hasPrevious()) {
			System.out.println(it.previous());
		}
		*/
		
		//System.out.println(list.get(2));
		list.add(1, "CApgemini");
		//System.out.println(list);
		
		
		//list.remove(1);
		
		//or to prnt elements one by one
		//for(Object obj:list) {
			//System.out.println(obj);
		//}
		//System.out.println(list.contains(10));
		List list1=new ArrayList();
		list1.add(10);
		list1.add("Hello");
		list1.add(23.56);
		//System.out.println(list.containsAll(list1));
		System.out.println("-----------------------------------------------");
		/*list.addAll(list1);
		for(Object obj:list) {
			System.out.println(obj);
		}
		*/
		//to remove the elements in list thar are same in both list nd list1
		/*list.removeAll(list1);
		for(Object obj:list) {
			System.out.println(obj);
		}
		*/
		
		// retailAll
		
		
		/*list.retainAll(list1);
		for(Object obj:list) {
			System.out.println(obj);
		}*/
		//list.clear();
		//System.out.println(list);
		
		list.forEach(e->System.out.println(e));
		
		
		

	}

}
