/* const express=require("express");
const path=require("path");
const router=require("./server/routes/route");


const app=express();
//to access middleware dist
app.use(express.static(path.join(__dirname,"dist")));
app.use("/api/employees",router);

app.get("*",function(req,res){
    res.sendFile(path.join(__dirname,"dist/index.html"));
})

let PORT=process.env.PORT || 5000;

app.listen(PORT,function(){
    console.log(`server started @ poprt ${PORT}`);
}) */


//for add moviessss program
const express=require("express");
const path=require("path");
const router1=require("./server1/routes/route1");
const app=express();
//to access middleware dist
/* app.use(express.static(path.join(__dirname,"dist")));
const newLocal = "/api/movies";
app.use(newLocal,router1);

app.get("*",function(req,res){
    res.sendFile(path.join(__dirname,"dist/index.html"));
})
 */
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.post("/add", (req, res) => {
    var myData = new User(req.body);
    myData.save()
    .then(item => {
    res.send("item saved to database");
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
   });
let PORT=process.env.PORT || 5000;

app.listen(PORT,function(){
    console.log(`server started @ poprt ${PORT}`);
})

//for lab program employees lab

/* const express=require("express");
const path=require("path");
const router=require("./server/routes/routelab");


const app=express();
//to access middleware dist
app.use(express.static(path.join(__dirname,"dist")));
app.use("/api/employeees",router);

app.get("*",function(req,res){
    res.sendFile(path.join(__dirname,"dist/index.html"));
})

let PORT=process.env.PORT || 5000;

app.listen(PORT,function(){
    console.log(`server started @ port ${PORT}`);
})  */