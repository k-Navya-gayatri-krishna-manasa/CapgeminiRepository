/* const mongodb=require("mongodb");
const mongoose=require("mongoose");
const MongoClient=mongodb.MongoClient;


MongoClient.connect("mongodb://localhost:27017/newdb",{useNewUrlParser:true},function(error,client){
    if(error){
        return console.log("Error occured:"+error);
    }
    console.log("Connection to the server established");
    let db=client.db("dummy");
    let collection=db.collection("movies");
});
//connect is method
mongoose.connect("mongodb://localhost:27017/dummy",{useNewUrlParser:true})


//defining the schema
let movSchema=new mongoose.Schema({
    name:String,
    rating:Number,
})
//creating the model
let movie=mongoose.model("movies",empSchema);
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});
//creating an object

//inserting data using object//adding movie details
let mov=new movie({
   name:"Iron man",
   rating:5.5,
});
mov.save().then(function(){
    console.log("Movie name added");
    process.exit(0);
}).catch(function(error){
    console.log("Error"+error);
    process.exit(0);
})

module.exports=
 */



const express=require("express");
const path=require("path");
const fs=require("fs");

const router1=express.Router();

router1.get("/:Drama",(req,res)=>{
    /* fs.readFile(path.join(__dirname,"movie-app.component.html"),"utf8",(error,movies)=>{
        if(error){
            return console.log("Error"+error);
        }
        res.send(movies);
    }); */

    Movie.find({drama:abc}).then((data)=>{
        res.send(data);
    })


})

var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/dummy");

let movSchema=new mongoose.Schema({
    name:String,
    rating:Number,
    drama:String,
})
let Movie=mongoose.model("movies",movSchema);
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});

module.exports=router1;
