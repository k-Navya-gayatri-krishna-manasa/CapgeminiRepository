import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-app',
  templateUrl: './movie-app.component.html',
  styleUrls: ['./movie-app.component.css']
})
export class MovieAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onSubmit(value){
    console.log(value);
  }
}
