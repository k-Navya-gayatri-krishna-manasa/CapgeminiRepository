import { Component, OnInit } from '@angular/core';
import { MovieService } from './movie.service';

@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {

  constructor(private  movieService:MovieService ) { 

  }

  ngOnInit() {
  }
  onSubmit(value){
    console.log(value);
  }
  change(value){
    console.log(value);
    return this.movieService.getDrama(value);
    /* return this.http.post('/', {value}); */
  }
  }

