import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchmovieComponent } from './movie/searchmovie.component';
import { MovieAppComponent } from './movie/movie-app.component';

const routes: Routes = [
  {path:"add",component:MovieAppComponent},/* series is manditory while mentioning path */
  {path:"search",component:SearchmovieComponent},
  {path:"",redirectTo:"/search",pathMatch:"full"},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
