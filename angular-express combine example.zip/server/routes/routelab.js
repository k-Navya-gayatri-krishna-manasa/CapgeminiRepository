/* const express=require("express");
const path=require("path");
const fs=require("fs");

const routerlab=express.Router();

routerlab.get("/",(req,res)=>{
    fs.readFile(path.join(__dirname,"../../src/assets/emp.json"),"utf8",(error,emp)=>{
        if(error){
            return console.log("Error"+error);
        }
        res.send(emp);
    });
})
module.exports=routerlab; */