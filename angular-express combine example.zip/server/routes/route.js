const express=require("express");
const path=require("path");
const fs=require("fs");

const router=express.Router();

router.get("/",(req,res)=>{
    fs.readFile(path.join(__dirname,"../../src/assets/employees.json"),"utf8",(error,employees)=>{
        if(error){
            return console.log("Error"+error);
        }
        res.send(employees);
    });
})
module.exports=router;
