let employees=[
    {id:1001,name:"Manu",age:23,salary:45000},
    {id:1002,name:"Banu",age:25,salary:35050},
    {id:1003,name:"Mani",age:33,salary:45900},

]
module.exports=employees;