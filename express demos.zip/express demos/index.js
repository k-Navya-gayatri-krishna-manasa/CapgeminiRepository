const express=require("express");
const path=require("path");
//let employees=require("./Employee");
//this is linked with middleware folder profram routes folder routes.js file
const router=require("./routes/routes")

//logger:Application level middleware
let logger=function(req,res,next){
    console.log(`${req.protocol}://${req.get('host')}${req.originalUrl}`);
    next();
}
const app=express(); //to get express obj
app.use(logger);
//defining a static folder "public" for application and moing about.html,contact.html into it
//by this we dont want to provides routes in chrome if we give/about directly takes to that page
//.use is used to access middleware
app.use(logger);
app.use(express.static(path.join(__dirname,"public")));
app.use("/api/employees",router);

/* app.get("/",function(req,res){
res.send("<h1>Welcome to Express</h1>");

    //sending other file name instead
   res.sendFile(path.join(__dirname,"hai.html")); 
}) */

let PORT=process.env.PORT||5000; 

app.listen(PORT,function(){
    console.log(`Server started @ ${PORT}`);
})