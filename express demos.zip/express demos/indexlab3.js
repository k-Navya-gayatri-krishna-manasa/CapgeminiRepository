const express=require("express");
const path=require("path");
const router=require("./routes/lab3routes")

//logger:Application level middleware
let logger=function(req,res,next){
    console.log(`${req.protocol}://${req.get('host')}${req.originalUrl}`);
    next();
}
const app=express(); //to get express obj
app.use(logger);
app.use("/api/employees",router);

/* app.get("/",function(req,res){
   res.sendFile(path.join(__dirname,"employees.json")); 
}) */


let PORT=process.env.PORT||5000; 

app.listen(PORT,function(){
    console.log(`Server started @ ${PORT}`);
})