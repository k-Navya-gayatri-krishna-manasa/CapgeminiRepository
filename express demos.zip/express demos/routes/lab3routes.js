const express=require("express");
const router=express.Router();
let employees=require("../employees");
const bodyParser=require("body-parser");

router.get("/",function(req,res){
    res.json(employees);
})

/* router.get("/:empId",function(req,res){
    
    let found=employees.some(em=>em.empId==req.params.empId);
    if(found){
        let e=employees.filter(e=>e.empId==req.params.empId);
        res.json(e);
    }
}) */

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended:false}));

router.post("/",function(req,res){
    let emp={
        empId:req.body.empId,
        empName:req.body.empName,
        empSalary:req.body.empSalary,
        empAddress:{
        city:req.body.city,
        state:req.body.state
    }
    }
    employees.push(emp);
   
    res.status(200).json({msg:`Employee with id ${emp.empId} added`});
})


router.put("/:empId",(req,res)=>{
    let found=employees.some(emp=>emp.empId==req.params.id);
    if(found){
        employees.forEach(emp=>{
            if(emp.empId==req.params.empId){
                emp.empName=req.body.empName;
                emp.empSalary=req.body.empSalary;
                emp.empAddress.city=req.body.city,
                emp.empAddress.state=req.body.state
            }
        })
        res.status(200).json({"msg":`Employee with id ${req.params.empId} is updated `})
    }
    else{
        res.status(400).json({"msg":`Employee with id ${req.params.empId} does not exist `});

    }

})

module.exports=router;