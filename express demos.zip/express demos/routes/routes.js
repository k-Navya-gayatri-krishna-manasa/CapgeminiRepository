const express=require("express");
const router=express.Router();
let employees=require("../employee");
//for sake of router.post extrernal middle ware
const bodyParser=require("body-parser");

router.get("/",function(req,res){
    res.json(employees);
})

//these two statemenst for sake of 4thstatement to access external middle ware router.post i.e., body
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended:false}));

router.get("/:id",function(req,res){
    let found=employees.some(em=>em.id==req.params.id);
    if(found){
        let e=employees.filter(e=>e.id==req.params.id);
        res.json(e);
    }
})
//post request to add records
router.post("/",function(req,res){
    let emp={
        id:req.body.id,
        name:req.body.name,
        age:req.body.age,
        salary:req.body.salary
    }
    employees.push(emp);
    //to pass a msg or to display the msg in chrome or postman
    res.status(200).json({msg:`Employee with id ${emp.id} added`});
})
//to delete a record same as get in get we get the data from mentioning the id in delete we mention id to delete
router.delete("/:id",(req,res)=>{
    let found=employees.some(emp=>emp.id==req.params.id);
    //=== will also check t5he datatype so we dont use bcze if we data i url if takes as string but in employees it is number
    if(found){
    employees=employees.filter(emp=>emp.id!=req.params.id);
    res.status(200).json({"msg":`Employee with id ${req.params.id} deleted `});
}
    else{
        res.status(400).json({"msg":`Employee with id ${req.params.id} does not exist `});
    }
})

//put:to update already existing data
router.put("/:id",(req,res)=>{
    let found=employees.some(emp=>emp.id==req.params.id);
    if(found){
        employees.forEach(emp=>{
            if(emp.id==req.params.id){
                emp.name=req.body.name;
                emp.age=req.body.age;
                emp.salary=req.body.salary;
            }
        })
        res.status(200).json({"msg":`Employee with id ${req.params.id} is updated `})
    }
    else{
        res.status(400).json({"msg":`Employee with id ${req.params.id} does not exist `});

    }

})
module.exports=router;