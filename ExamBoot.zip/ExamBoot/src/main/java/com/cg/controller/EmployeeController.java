package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeException {
		return  employeeService.createEmployee(employee);
	}
	
	@RequestMapping(value = "/updateemployee", method = RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee) throws EmployeeException {
		return  employeeService.updateEmployee(employee);
	}
	
	@RequestMapping(value = "/deleteemployee/{eId}", method = RequestMethod.DELETE)
	public String delemployee(@PathVariable("eId") Integer empId) throws EmployeeException  {
		employeeService.deleteEmployee(empId);;
		return  empId+" is deleted";
	}
	
	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public List<Employee> viewEmployees() throws EmployeeException {
		return  employeeService.viewEmployeeList();
	}
	
	@RequestMapping(value = "/getById/{eid}", method = RequestMethod.GET)
	public Employee findEmployeeById(@RequestParam("eid") Integer empId)  {
			return  employeeService.findEmployee(empId);
	}
	
	@RequestMapping(value = "/employees/{departmentname}", method = RequestMethod.GET)
	public List<Employee> findEmployeeByName(@PathVariable("departmentname") String deptName) throws EmployeeException {
		return employeeService.getEmployeeBydepartmentName(deptName);
	}
}
