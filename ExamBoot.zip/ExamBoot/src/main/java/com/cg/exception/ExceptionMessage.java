package com.cg.exception;

public interface ExceptionMessage {
	String MESSAGE1="Internal Errors";
	String MESSAGE2="Data mismatch";
	String MESSAGE3="Employee with given Id is not there to delete";
	String MESSAGE4="Data not found";
	String MESSAGE5="Employee with given Id does not exists";
	String MESSAGE6="No employee found with that department Name";
}
