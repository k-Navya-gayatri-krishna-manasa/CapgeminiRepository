package com.cg.exception;

public class EmployeeException extends Exception{

	public EmployeeException() {
		
	}
	public EmployeeException(String message) {
		
	}
	
	

}
