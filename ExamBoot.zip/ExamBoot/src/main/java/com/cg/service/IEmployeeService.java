package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface IEmployeeService {
	
	List<Employee> createEmployee(Employee employee) throws EmployeeException;
	
	Employee updateEmployee(Employee employee) throws EmployeeException;
	
	void deleteEmployee(Integer empId) throws EmployeeException;
	
	List<Employee> viewEmployeeList() throws EmployeeException;
	
	Employee findEmployee(Integer empId);
	
	List<Employee> getEmployeeBydepartmentName(String deptName) throws EmployeeException;


}
