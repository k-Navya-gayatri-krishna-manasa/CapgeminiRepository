package com.store.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.store.bean.Album;
import com.store.dao.AlbumDao;
import com.store.dao.AlbumDaoImpl;
import com.store.exception.InvalidAlbumIdException;
import com.store.service.AlbumService;
import com.store.service.AlbumServiceImpl;

public class StoreTestClass {

	
	@Test(expected=InvalidAlbumIdException.class)
	public void testException() throws InvalidAlbumIdException{
		AlbumService albumService=new AlbumServiceImpl();
		Album album=new Album();
		album.setTitle("Lemonade");
		album.setArtist("Beyonce");
		album.setPrice(250);
		album.setRating(4.5);
		int albumId=14;
		album=albumService.findById(albumId);
		assertNotNull(albumService.saveAlbum(album));
	}
	
	@Test
	public void findTest() throws InvalidAlbumIdException{
		AlbumDao albumDao=new AlbumDaoImpl();
		Album album=new Album();
		int albumId=78;
		assertNotNull(albumDao.persist(album));
		assertNotNull(albumDao.find(albumId));
			
	}
	

}
