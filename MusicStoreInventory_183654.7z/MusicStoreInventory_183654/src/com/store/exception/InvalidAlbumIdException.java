package com.store.exception;

public class InvalidAlbumIdException extends Exception {
	public InvalidAlbumIdException() {
		super();
	}
	public InvalidAlbumIdException(String message) {
		super(message);
	}
}
