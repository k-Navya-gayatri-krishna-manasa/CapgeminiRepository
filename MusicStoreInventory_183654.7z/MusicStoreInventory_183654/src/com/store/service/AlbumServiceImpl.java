package com.store.service;

import com.store.bean.Album;
import com.store.dao.AlbumDao;
import com.store.dao.AlbumDaoImpl;
import com.store.exception.InvalidAlbumIdException;

public class AlbumServiceImpl implements AlbumService {
	
	private AlbumDao albumDao;
	
	public AlbumServiceImpl(){
		
		albumDao=new AlbumDaoImpl();
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 19-06-2019
	 * Method Name:saveAlbum
	 * Parameters:None
	 * return Value:albumId
	 */
	@Override
	public int saveAlbum(Album album)throws InvalidAlbumIdException {
		
		return albumDao.persist(album);
	
	}
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 19-06-2019
	 * Method Name:findById
	 * Parameters:1 parameter with int type
	 * return Value:album details if albumId present in Map
	 */

	@Override
	public Album findById(int id) throws InvalidAlbumIdException {
		
		return albumDao.find(id);
	
	}

}
