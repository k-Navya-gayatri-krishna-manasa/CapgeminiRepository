package com.store.ui;

import java.util.Scanner;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;
import com.store.service.AlbumService;
import com.store.service.AlbumServiceImpl;

public class Client {
	static Scanner scanner=new Scanner(System.in);
	static  AlbumService albumService=new AlbumServiceImpl();
	public static void main(String[] args) {
		int response;
		while(true) {
			System.out.println("1.Add Music Album");
			System.out.println("2.Find Album by Id");
			System.out.println("3. Exit");
			System.out.println("Enter Choice");
			response=scanner.nextInt();
			scanner.nextLine();
			switch(response) {
			case 1:
				addMusicAlbum();
				break;
			case 2:
				findAlbumById();
				break;
			case 3:
				System.exit(0);	
			default:
				System.out.println("Invalid option,please select between 1 to 3");
				break;
			}
		}
	}
	static Album album=new Album();
	private static void addMusicAlbum() {
		System.out.println("Enter Title:");
		album.setTitle(scanner.nextLine());
		System.out.println("Enter Artist:");
		album.setArtist(scanner.nextLine());
		System.out.println("Enter Price:");
		album.setPrice(scanner.nextDouble());
		System.out.println("Enter Rating:");
		album.setRating(scanner.nextDouble());
		try {
			System.out.println("Album stored with Id:"+albumService.saveAlbum(album));
		} catch (InvalidAlbumIdException e) {
			System.out.println("Album cant be saved");
		}	
	}
	private static void findAlbumById() {
		System.out.println("Enter Album Id:");
		int albumId=scanner.nextInt();
		try {
			albumService.findById(albumId);
			System.out.println("Title:"+album.getTitle()+"\n"+"Artist:"+album.getArtist()+"\n"+
			                       "Price:"+album.getPrice()+"\n"+"Rating:"+album.getRating());
		}catch(InvalidAlbumIdException e) {
			System.err.println("Oops!No album found with this Id");
		}
	}
}
