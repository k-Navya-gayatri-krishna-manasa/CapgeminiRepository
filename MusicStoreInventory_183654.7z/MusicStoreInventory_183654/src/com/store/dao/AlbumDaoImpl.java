package com.store.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;
public class AlbumDaoImpl implements AlbumDao {
	private Map<Integer, Album> albums=new HashMap<>();
	
	
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 19-06-2019
 * Method Name:persist
 * Parameters:1 parameter of type Album
 * return Value:albumId
 * purpose:To save the album details and get the albumId
 */
	@Override
	public int persist(Album album) throws InvalidAlbumIdException{
		int albumId=setAlbumId();
		albums.put(albumId, new Album(album.getTitle(),album.getArtist(),album.getPrice(),album.getRating()));
		return albumId;
		
	}
	
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 19-06-2019
 * Method Name:find
 * Parameters:1 parameter of type int
 * return Value:album
 * purpose:Retrieves the data from the albums based on given albumId
 */
	@Override
	public Album find(int id) throws InvalidAlbumIdException{
		if(albums.containsKey(id)) {
			return albums.get(id);
		}else {
			throw new InvalidAlbumIdException("Album doesnot exist");
		}
	}
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 19-06-2019
 * Method Name:setAlbumId
 * Parameters:None
 * return Value:albumId
 * purpose:get the albumId randomly
 */
	public int setAlbumId() {
		Random random=new Random();
		int albumId=Math.abs(random.nextInt());
		return albumId;
	}
	

}
