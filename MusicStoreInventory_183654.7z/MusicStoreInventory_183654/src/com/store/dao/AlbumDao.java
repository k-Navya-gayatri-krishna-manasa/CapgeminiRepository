package com.store.dao;

import com.store.bean.Album;
import com.store.exception.InvalidAlbumIdException;

public interface AlbumDao {
	int persist(Album album) throws InvalidAlbumIdException;
	Album find(int id) throws InvalidAlbumIdException;
}
