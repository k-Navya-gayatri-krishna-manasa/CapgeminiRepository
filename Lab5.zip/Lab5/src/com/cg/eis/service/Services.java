package com.cg.eis.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.cg.eis.bean.Employee;

public class Services implements EmpServiesInterface {

	public String CalculateInsuranceScheme(String designation, double salary) {
		String res = null;
		if(salary>5000 && salary < 20000 && designation.equals("SystemAssociate")) {
				res="Scheme C";
				//return res;
		}
		else if(salary>=20000 && salary < 40000 && designation.equals("Programmer")) {
			res="Scheme B";
			//return res;
		}
		else if(salary>=40000 && designation.equals("Manager")) {
			res="Scheme A";
			//return res;
		}
		else if(salary<5000 && designation.equals("Clerk") ){
			res="No Scheme";
			
		}
		
		return res;
		
	}

	@Override
	public void stream(Employee e) throws FileNotFoundException {
		FileOutputStream in=new FileOutputStream("employee.txt");
		
		
		
		
	}
	

}
