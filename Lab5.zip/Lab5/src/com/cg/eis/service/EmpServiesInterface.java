package com.cg.eis.service;

import java.io.FileNotFoundException;

import com.cg.eis.bean.Employee;

public interface EmpServiesInterface {
	String CalculateInsuranceScheme(String designation, double salary);
	public void stream(Employee e) throws FileNotFoundException;
	

}
