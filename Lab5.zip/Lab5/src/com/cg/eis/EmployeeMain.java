package com.cg.eis;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmpServiesInterface;
import com.cg.eis.service.Services;

public class EmployeeMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Employee emp=new Employee();
		System.out.println("Enter employee Id:");
		emp.setEid(sc.nextInt());
		 System.out.println("Enter Employee name:");
		emp.setName(sc.next());
		System.out.println("Enter designation:SystemAssociate/Programmer/Manager/Clerk");
		emp.setDesignation(sc.next());
		System.out.println("Enter Employee Salary");
		emp.setSalary(sc.nextDouble());  
		
		Services s=new Services();
		
		System.out.println("Employee Id:"+emp.getEid());
		System.out.println("Employee Name is:"+emp.getName());
		System.out.println("Employee designation is:"+emp.getDesignation());
		
		emp.setInsScheme(s.CalculateInsuranceScheme(emp.getDesignation(), emp.getSalary()));
		System.out.println("Scheme is:"+emp.getInsScheme());
		
		System.out.println("Employee salary is:"+emp.getSalary());

	}

}
