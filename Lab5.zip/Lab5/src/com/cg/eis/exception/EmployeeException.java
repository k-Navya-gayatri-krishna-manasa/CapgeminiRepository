package com.cg.eis.exception;

public class EmployeeException extends Exception {
	  String str1;
		 public EmployeeException(String str2) {
				str1=str2; 
		 }
		public String toString(){ 
				return ("MyException Occurred: "+str1) ;
		}

}
//this class is created for sake of 6.3