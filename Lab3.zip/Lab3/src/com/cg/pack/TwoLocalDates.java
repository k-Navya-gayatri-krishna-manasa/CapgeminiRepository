package com.cg.pack;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TwoLocalDates {

	public static void main(String[] args) {
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		Period p=null;;
		System.out.println("Enter date:");
		String d=sc.nextLine();
		LocalDate date=LocalDate.parse(d,f);
		System.out.println("Enter 2nd date:");
		String d1=sc.next();
		LocalDate date1=LocalDate.parse(d1,f);
		if(date1.isBefore(date)) {
			p=date1.until(date);
		}
		else if(date.isBefore(date1)) {
			p=date.until(date1);
		}
		System.out.println(p.getYears()+" "+p.getMonths()+"  "+p.getDays());


	}

}
