package com.cg.pack;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PersonWithdob {
	
		private String firstname,lastname;
		private char gender;
		
		
		public void calculateage() {
			DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner sc=new Scanner(System.in);
			Period p=null;
			System.out.println("Enter date:");
			String d=sc.nextLine();
			LocalDate date=LocalDate.parse(d,f);
			LocalDate today=LocalDate.now();
			if(date.isBefore(today)) {
				p=date.until(today);
			}
			else if(today.isBefore(date)) {
				p=today.until(date);
			}
			Fullname();
			System.out.println("Age is:"+p.getYears()+"years"+p.getMonths()+"Months"+p.getDays()+"Days");
			
		}
		public void Fullname() {
			System.out.println("Full name of the Person:"+getFirstname()+" "+getLastname());

		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public char getGender() {
			return gender;
		}

		public void setGender(char gender) {
			this.gender = gender;
		}


		public PersonWithdob(String firstname, String lastname, char gender) {
			super();
			this.firstname = firstname;
			this.lastname = lastname;
			this.gender = gender;
		}

		
		

	}

