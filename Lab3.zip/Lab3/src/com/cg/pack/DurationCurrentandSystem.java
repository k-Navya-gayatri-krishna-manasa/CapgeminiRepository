package com.cg.pack;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DurationCurrentandSystem {

	public static void main(String[] args) throws ParseException {
		
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		Period p=null;
		System.out.println("Enter date:");
		String d=sc.nextLine();
		LocalDate date=LocalDate.parse(d,f);
		System.out.println(date);
		LocalDate today=LocalDate.now();
		System.out.println(today);
		if(today.isBefore(date)) {
			p=today.until(date);
		}
		else if(date.isBefore(today)) {
			p=date.until(today);
		}
		System.out.println(p.getYears()+" "+p.getMonths()+"  "+p.getDays());

	}

}
