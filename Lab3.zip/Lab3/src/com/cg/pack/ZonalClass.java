package com.cg.pack;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZonalClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ZonedDateTime z=ZonedDateTime.now();
		System.out.println(z);
		//static
		ZonedDateTime ny=ZonedDateTime.now(ZoneId.of("America/New_York"));
		System.out.println(ny);
		ZonedDateTime lo=ZonedDateTime.now(ZoneId.of("Europe/London"));
		System.out.println(lo);
		ZonedDateTime to=ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
		System.out.println(to);
		ZonedDateTime pa=ZonedDateTime.now(ZoneId.of("US/Pacific"));
		System.out.println(pa);
		//dynamic
		System.out.println("Enter zone Id");
		String zone=sc.next();
		ZonedDateTime p=ZonedDateTime.now(ZoneId.of(zone));
		System.out.println(p);
		
	}

}
