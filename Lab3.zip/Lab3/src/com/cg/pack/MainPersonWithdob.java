package com.cg.pack;

public class MainPersonWithdob {

	public static void main(String[] args) {
		PersonWithdob pb=new PersonWithdob("kakumanu","Navya",'F');
		//System.out.println("First name:-"+pb.getFirstname()+"\n"+"LastName:-"+pb.getLastname()+"\n+"+"Gender:-"+pb.getGender());
		//pb.Fullname();
		pb.calculateage();
		
	}

}
