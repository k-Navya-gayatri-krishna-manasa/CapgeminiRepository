package com.cg.pack;
import java.util.Arrays;
import java.util.Scanner;

public class StringOperations {
	
	public void StringOpe(String str, int ch) {
	
		String str1;
		char[] charArr=str.toCharArray();
		int len=charArr.length;
		switch(ch)
		{
		case 1:System.out.println("Adding the same string");
				str1=str+str;
				System.out.println("The string is:"+str1);
				break;
		case 2:System.out.println("Replacing odd positions with #");
				
				for(int i=0;i<len;i++) {
					if((i+1)%2!=0)
						charArr[i]='#';
				}
				System.out.println(charArr);
				break;
		case 3:System.out.println("Changing odd characters to upper case");
				for(int i=0;i<len;i++) {
					if((i+1)%2!=0)
						charArr[i]=Character.toUpperCase(charArr[i]);
				}
				System.out.println(charArr);
				break;
		case 4:System.out.println("Removing the duplicate errors");
		for(int i=0;i<len;i++) {
			for(int j=i+1;j<len;j++) {
				if(charArr[i]==charArr[j]) {
					charArr[j]=charArr[len-1];
					len--;
					j--;
				}
			}
		}
		char[] charArr1=Arrays.copyOf(charArr, len);
		str1=new String(charArr1);
		System.out.println(str1);
		break;
		
				
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		StringOperations so=new StringOperations();
		System.out.println("Enter String");
		String str=sc.next();
		System.out.println("1.add 2.odd positions with # 3.odd positions to upper case 4.remove duplicates");
		int ch;
		do {
			ch=sc.nextInt();
			so.StringOpe(str,ch);
			}while(ch<4);

	}

}

