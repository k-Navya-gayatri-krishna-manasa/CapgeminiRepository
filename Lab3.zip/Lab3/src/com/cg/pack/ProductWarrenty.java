package com.cg.pack;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ProductWarrenty {

	public static void main(String[] args) {
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		Period p=null;;
		System.out.println("Enter date:");
		String d=sc.nextLine();
		LocalDate date=LocalDate.parse(d,f);
		LocalDate expiry=date.plusYears(2);
		expiry=expiry.plusMonths(5);
		System.out.println(expiry);

	}

}
