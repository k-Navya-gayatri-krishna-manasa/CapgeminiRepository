package com.cg.pack;

import java.util.Scanner;

public class StringPos {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String str=sc.next();
		char[] charArr=str.toCharArray();
		for(int i=0;i<charArr.length;i++) {
			for(int j=i+1;j<charArr.length;j++) {
				if(charArr[i]>charArr[j]) {
					System.out.println("String is Negative");
					return;
				}
			}
		}
		System.out.println("String is Positive");
	}

}
