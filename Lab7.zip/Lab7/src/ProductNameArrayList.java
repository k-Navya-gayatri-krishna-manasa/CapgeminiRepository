import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class ProductNameArrayList {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		List list = null;
		List productNames= new ArrayList(n);
		System.out.println("Read elements into an array:");
		for(int i=0;i<n;i++) {
			productNames.add(sc.next());
		}
		Collections.sort(productNames);
		System.out.println("Elements after sorting:");
		for(Object obj:productNames) {
			System.out.println(obj);
		}
		
		}

	}


