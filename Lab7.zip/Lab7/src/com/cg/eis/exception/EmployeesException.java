package com.cg.eis.exception;

public class EmployeesException extends Exception{

		  String str1;
			 public EmployeesException(String str2) {
					str1=str2; 
			 }
			public String toString(){ 
					return ("MyException Occurred: "+str1) ;
			}

	}
