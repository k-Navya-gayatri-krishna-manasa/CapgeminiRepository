package com.cg.eis.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.cg.eis.bean.Employees;
import com.cg.eis.exception.EmployeesException;

public class Servicess implements EmpsServicesInterface {
	Map<Integer,Employees> empDb;
	 
	public  Servicess() {
		empDb=new HashMap<Integer, Employees>();
	}

	Scanner sc=new Scanner(System.in);
	public String CalculateInsuranceScheme(String designation, double salary) {
		String res = null;
		if(salary>5000 && salary < 20000 && designation.equals("SystemAssociate")) {
				res="Scheme C";
				//return res;
		}
		else if(salary>=20000 && salary < 40000 && designation.equals("Programmer")) {
			res="Scheme B";
			//return res;
		}
		else if(salary>=40000 && designation.equals("Manager")) {
			res="Scheme A";
			//return res;
		}
		else if(salary<5000 && designation.equals("Clerk") ){
			res="No Scheme";
			
		}
		
		return res;
		
	}

	@Override
	public void addEmployee(Employees emp) throws EmployeesException {
		try {
			System.out.println(emp);
			empDb.put(emp.getEid(), emp);
		}catch(Exception e) {
			throw new EmployeesException(e.getMessage());
		}
		
	}

	@Override
	public void deleteEmployee(int id) throws EmployeesException {
		try {
			empDb.remove(id);
		}catch(Exception e) {
			throw new EmployeesException(e.getMessage());

		}
		
	}
	public List<Employees> getAllEmployee() throws EmployeesException {
		try {
		List<Employees> employees=new ArrayList<Employees>();
		for(Integer key:empDb.keySet()) {
			Employees emp=empDb.get(key);
			employees.add(emp);
		}
		
		return employees;
		}
		catch(Exception e) {
			throw new EmployeesException(e.getMessage()); //here we should not print the exception we should just throw it
		}
	}

	@Override
	public List<Employees> sortEmployees(List<Employees> employees) throws EmployeesException {
		try {
			
			//List<Employees> employees=new ArrayList<Employees>();
			Collections.sort(employees, new EmployeeComparator());
			return employees;
			}
		catch(Exception e) {
			throw new EmployeesException(e.getMessage()); //here we should not print the exception we should just throw it
		}
		
	
	}
	
	@Override
	public List<Employees> getEmployeesByScheme(String scheme) throws EmployeesException {
		List<Employees> emps=getAllEmployee().stream().filter(e->e.getInsScheme().equals(scheme)).collect(Collectors.toList());
		if(emps.size()==0) {
			throw new EmployeesException("No Employee found");
		}
		else {
			return emps;
		}
	}


}
class EmployeeComparator implements Comparator<Employees>{
	public int compare(Employees e1,Employees e2) {
		if(e1.getSalary()>e2.getSalary())
			return -1;
		else if(e1.getSalary()<e2.getSalary())
			return 1;
		else
			return 0;
	}
	
}

