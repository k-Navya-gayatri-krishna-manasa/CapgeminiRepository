package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employees;
import com.cg.eis.exception.EmployeesException;

public interface EmpsServicesInterface {
	String CalculateInsuranceScheme(String designation, double salary);
	public void addEmployee(Employees emp) throws EmployeesException ;
	public void deleteEmployee(int id) throws EmployeesException ;
	public List<Employees> getAllEmployee() throws EmployeesException;
	public List<Employees>  sortEmployees(List<Employees> employees)throws EmployeesException;
	public List<Employees> getEmployeesByScheme(String scheme) throws EmployeesException;
}
