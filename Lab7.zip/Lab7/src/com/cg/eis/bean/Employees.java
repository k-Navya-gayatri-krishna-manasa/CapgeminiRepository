package com.cg.eis.bean;

import java.util.Scanner;

import com.cg.eis.exception.EmployeesException;

public class Employees {
	Scanner sc=new Scanner(System.in);
	private int eid;
	private String name,designation,insScheme;
	private double salary;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsScheme() {
		return insScheme;
	}
	public void setInsScheme(String insScheme) {
		this.insScheme = insScheme;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		//this validation is done for 6.3 and raised user defined exception
		if(salary>3000)
			this.salary = salary;
		else {
			try {
				throw  new EmployeesException("Entered salary is out of range.It should be greater than 3000");
				//emp.setSalary
			}
			catch(EmployeesException e) {
				System.out.println(e);
				salary=sc.nextDouble();
			}
			}
	}
	public Employees() {
		
	}
	public Employees(int eid, String name, String designation,double salary) {
		super();
		this.eid = eid;
		this.name = name;
		this.designation = designation;
		//this.insScheme = insScheme;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employees [eid=" + eid + ", name=" + name + ", designation=" + designation
				+ ", salary=" + salary + "]";
	}
	
}
