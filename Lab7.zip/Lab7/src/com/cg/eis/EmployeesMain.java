package com.cg.eis;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employees;
import com.cg.eis.exception.EmployeesException;
import com.cg.eis.service.EmpsServicesInterface;
import com.cg.eis.service.Servicess;


public class EmployeesMain {
	static EmpsServicesInterface s=new Servicess();
	static Scanner sc=new Scanner(System.in);
	static List<Employees> employeess=new ArrayList<Employees>();

	public static void main(String[] args) {
		
		
		addEmployee();
		showAllEmployees();
		getEmployeeByScheme();
		deleteEmployee();
		System.out.println("Employee list after deleting:");
		showAllEmployees();
		SortEmpDetailsBasedonSal();	
	
	}
	public static void addEmployee() {
		System.out.println("Enter no.of employees to be added:");
		int n=sc.nextInt();
		
		try {
			for(int i=0;i<n;i++) {
				Employees emp=new Employees();
			System.out.println("Enter employee Id:");
			emp.setEid(sc.nextInt());
			 System.out.println("Enter Employee name:");
			emp.setName(sc.next());
			System.out.println("Enter designation:SystemAssociate/Programmer/Manager/Clerk");
			emp.setDesignation(sc.next());
			System.out.println("Enter Employee Salary");
			emp.setSalary(sc.nextDouble());  
			sc.nextLine();
		s.addEmployee(emp);
			//list.add(new Employees(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble()));
		System.out.println("Employee added successfully");
		emp.setInsScheme(s.CalculateInsuranceScheme(emp.getDesignation(), emp.getSalary()));
		System.out.println("Scheme is:"+emp.getInsScheme());

			}
		
		}catch(EmployeesException e){
			System.err.println(e.getMessage());			
		}catch(Exception ex) {
			System.err.println(ex.getMessage());
		}
	}
	static void deleteEmployee() {
		System.out.println("Enter Employee Id to delete:");
		try {
		int id=sc.nextInt();
		
			s.deleteEmployee(id);
			System.out.println("Employee with the id  "+id+" deleted");
		}catch(EmployeesException e) {
			System.err.println(e.getMessage());
		}
		catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
	public static void showAllEmployees() {
		try {
		employeess=s.getAllEmployee();
		System.out.println("Employee Id\tName\tGender\tAge\tSalary\tMobile");
		for(Employees e: employeess) {
			System.out.println(e.getEid()+"\t\t"+e.getName()+"\t"+e.getDesignation()+"\t"+e.getSalary()+"\t");
			
		}
		}catch(EmployeesException e) {
			System.err.println("Error Occured:"+e.getMessage());
		}
		
		
	}
	public static void SortEmpDetailsBasedonSal() {
		try {
			s.sortEmployees(employeess);
			System.out.println("Employees list after sorting based on salary");
			System.out.println("Employee Id\tName\tGender\tAge\tSalary\tMobile");
			System.out.println("{----------------");
			for(Employees e: employeess) {
				System.out.println(e.getEid()+"\t\t"+e.getName()+"\t"+e.getDesignation()+"\t"+e.getSalary()+"\t");
				
			}
			}catch(EmployeesException e) {
				System.err.println("Error Occured:"+e.getMessage());
			}
		
	}
	public static void getEmployeeByScheme() {
		System.out.println("Enter Scheme");
		String s1=sc.nextLine();
		try {
			List<Employees> emps=s.getEmployeesByScheme(s1);
			System.out.println("Displaying List Based on Scheme");
			for(Employees e: emps) {
				System.out.println(e.getEid()+"\t\t"+e.getName()+"\t"+e.getDesignation()+"\t"+e.getSalary()+"\t");
				
			}
		} catch (EmployeesException e) {
			System.err.println("Error Occured:"+e.getMessage());
		}
		
	}
	
	}
	


