import java.util.Arrays;
import java.util.Scanner;

public class ProductNameArray {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		String[] productNames= new String[n];
		System.out.println("Read elements into an array:");
		for(int i=0;i<n;i++) {
			productNames[i]=sc.next();
		}
		Arrays.sort(productNames);
		for(int i=0;i<n;i++) {
			System.out.println(productNames[i]);
		}
		
		

	}

}
