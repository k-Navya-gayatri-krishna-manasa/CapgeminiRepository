import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListEmployeeComponent } from './EmployeeManagement_183654/list-employee.component';
import { AddEmployeeComponent } from './EmployeeManagement_183654/add-employee.component';
import { NopageComponent } from './EmployeeManagement_183654/nopage.component';

const routes: Routes = [
  {path:"emplist",component:ListEmployeeComponent},
  {path:"addemp",component:AddEmployeeComponent},
  {path:"",redirectTo:"/emplist",pathMatch:"full"},
  {path:"**",component:NopageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
