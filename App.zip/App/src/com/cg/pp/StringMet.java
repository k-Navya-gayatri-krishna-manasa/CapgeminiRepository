package com.cg.pp;

public class StringMet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer("Hello");
		sb.append("World");
		System.out.println(sb);
		System.out.println(sb.length());
		System.out.println(sb.indexOf("Hello"));
		System.out.println(sb.lastIndexOf("Wor"));
		System.out.println(sb);
		System.out.println(sb.insert(6,"abcd"));
		

	}

}
