package com.cg.pp;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutOpe {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fis=new FileOutputStream("C:\\Users\\knavyaga\\Documents\\myfile.txt");//creates a file name myfile in that path
		String data="Capgemini akshay park";
		for(int i=0;i<data.length();i++) {
			
			fis.write(data.charAt(i));//to read one by one character from string
		}
		System.out.println("Done");
			

	}

}
