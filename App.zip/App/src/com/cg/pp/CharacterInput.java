package com.cg.pp;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CharacterInput {

	public static void main(String[] args) throws IOException {
		//FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\aaa.txt");
		/*int c;
		while((c=fr.read())!=-1){
			System.out.print((char)c);
		}*/
		
		//or
		
		/*char[] arr=new char[1024];
		fr.read(arr);
		System.out.println(arr);
		//fr.close();*/
		
		//to read the size of the file
		File file=new File("C:\\Users\\knavyaga\\Documents\\aaa.txt");
		FileReader fr=new FileReader(file);
		char[] arr=new char[(int)file.length()];
		fr.read(arr);
		System.out.println(arr);

	}

}
