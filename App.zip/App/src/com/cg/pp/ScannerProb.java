package com.cg.pp;

import java.util.Scanner;

public class ScannerProb {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter age:");
		int age=s.nextInt();
		System.out.println("Enter SALARY:");
		double salary=s.nextDouble();
		System.out.println("Enter Name:");
		//String name=s.nextLine();    it dont accept the name from keyboard
		String name=s.next();
		System.out.println(name+""+age+""+salary);
		
		
		

	}

}
