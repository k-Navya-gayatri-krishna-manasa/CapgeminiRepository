package com.cg.pp;

public class Calculator {
	public int add(int n1,int n2){
		return n1+n2;	
	}
	public boolean isEven(int n3)
	{
		return n3%2==0;
}
}