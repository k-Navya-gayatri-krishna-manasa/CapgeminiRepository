package com.cg.pp;

import org.junit.jupiter.api.BeforeAll;

public interface TestInterface {
	@BeforeAll
		public static void init() {
			System.out.println("Before");
		}

	}

