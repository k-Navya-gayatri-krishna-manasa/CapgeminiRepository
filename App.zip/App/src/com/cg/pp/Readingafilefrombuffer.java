package com.cg.pp;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;

public class Readingafilefrombuffer {

	public static void main(String[] args) throws IOException {
		FileInputStream fis=new FileInputStream("C:\\Users\\knavyaga\\Documents\\file.txt");
		BufferedInputStream bis=new BufferedInputStream(fis);
		int c;
		while((c=bis.read())!=-1) {
			System.out.print((char)c);
		}

	}

}
