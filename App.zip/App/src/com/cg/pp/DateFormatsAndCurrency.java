package com.cg.pp;

import java.text.ParseException;
import java.util.Currency;
import java.util.Locale;

public class DateFormatsAndCurrency {

	public static void main(String[] args) throws ParseException {
		/*
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date:");
		String strdate=sc.nextLine();
		Date d=format.parse(strdate);
		System.out.println(d);
	*/
		//simple date format
		/*Date d=new Date();
		System.out.println(d);
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");
		String str=format.format(d);
		System.out.println(str);
		*/
		
		//DateFormate
		/*
		Date d=new Date();
		DateFormat format=DateFormat.getDateInstance(DateFormat.SHORT,Locale.UK);
		String str=format.format(d);
		System.out.println(str);
		format=DateFormat.getDateInstance(DateFormat.FULL,Locale.UK);
		 str=format.format(d);
		System.out.println(str);
		*/
		//NumberFormat
		/*
		double salary=46578.345;
		NumberFormat format=NumberFormat.getCurrencyInstance(Locale.GERMANY);
		String str=format.format(salary);
		System.out.println(str);
		*/
		Locale l=Locale.getDefault();
		Currency c=Currency.getInstance(l);
		System.out.println(c.getCurrencyCode());
		System.out.println(c.getSymbol());
		System.out.println(c.getDisplayName());
		
		
		
	}

}
