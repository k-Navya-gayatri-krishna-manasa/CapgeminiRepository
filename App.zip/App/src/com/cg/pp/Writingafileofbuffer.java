package com.cg.pp;

//import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Writingafileofbuffer {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fos=new FileOutputStream("C:\\Users\\knavyaga\\Documents\\aaa.txt");
		BufferedOutputStream bos=new BufferedOutputStream(fos);
		String str="Hello World";
		for(int i=0;i<str.length();i++) {
			
			bos.write(str.charAt(i));
		}
		bos.close();
		fos.close();
		

	}

}
