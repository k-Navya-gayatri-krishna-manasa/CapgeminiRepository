package com.cg.pp;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class ClasssLocalDate {

	public static void main(String[] args) {
		LocalDate d=LocalDate.now();
		LocalDate ind=LocalDate.of(1947,Month.AUGUST, 15);
		Period p=ind.until(d);
		System.out.println(p.getYears()+"  "+p.getMonths()+"  "+p.getDays());

	}

}
