package com.cg.pp;

import java.util.StringTokenizer;

public class Tokens {

	public static void main(String[] args) {
		String str="hi-this-is-sai";
		//StringTokenizer t=new StringTokenizer(str);
		StringTokenizer t=new StringTokenizer(str,"-");
		while(t.hasMoreTokens()) {
			//System.out.println(t.nextToken());
			System.out.println(t.nextToken());
		}

	}

}
