package com.cg.pp;

import java.io.IOException;
import java.util.Date;

public class ClassDate {

	public static void main(String[] args) throws IOException {
		Date d=new Date();
		//Date d1=new Date(999999);
		System.out.println(d);
		//System.out.println(d1);
		System.out.println(System.currentTimeMillis());
		Date ind=new Date(47,7,15);
		System.out.println(ind);
		System.out.println(d.after(ind));
		Date ind1=new Date(47,7,15,13,53,33);
		System.out.println(ind1);
	}

}
