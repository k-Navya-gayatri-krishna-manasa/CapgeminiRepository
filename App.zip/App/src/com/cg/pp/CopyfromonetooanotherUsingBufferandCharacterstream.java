package com.cg.pp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyfromonetooanotherUsingBufferandCharacterstream {

	public static void main(String[] args) throws IOException {
		FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\file.txt");
		FileWriter out=new FileWriter("C:\\Users\\knavyaga\\Documents\\copy.txt");
		BufferedReader br=new BufferedReader(fr);
		BufferedWriter bw=new BufferedWriter(out);
		int c;
		while((c=br.read())!=-1) {
			bw.write(c);
		}
		br.close();
		bw.close();
		fr.close();
		out.close();
		
		}
	}


