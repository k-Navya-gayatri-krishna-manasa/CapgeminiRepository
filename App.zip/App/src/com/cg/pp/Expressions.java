package com.cg.pp;

import java.util.Scanner;

public class Expressions {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Name:");
		String name=s.nextLine();
		if(name.matches("[A-Z][A-Za-z\\s]{2,}")) {
			System.out.println("Valid Name");
		}
		else
		{
			System.out.println("Invalid name");
		}
		System.out.println("Enter Number:");
		String number=s.nextLine();
		if(number.matches("[0-9]\\d{10}"));
		System.out.println("valid");
		System.out.println("Enter mailid:");
		String email=s.next();
		if(email.matches("[a-z][a-z0-9_.]+@[a-z]+\\.(com|in|net)"));
			System.out.println("valid");
		
	}

}
