package com.cg.pp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Stream {

	public static void main(String[] args) throws IOException   {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter name");
		String n=br.readLine();
		System.out.println("Welcome"+n);
		br.close();

	}

}
