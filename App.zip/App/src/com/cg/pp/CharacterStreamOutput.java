package com.cg.pp;

import java.io.FileWriter;
import java.io.IOException;

public class CharacterStreamOutput {

	public static void main(String[] args) throws IOException {
		FileWriter out=new FileWriter("C:\\Users\\knavyaga\\Documents\\new1.txt");
		String data="Capgemini, Bangalore";
		
		//to write one string at a time into the file
		/*for(int i=0;i<data.length();i++) {
			out.write(data.charAt(i));
		}
out.close();
System.out.println("Done");*/
		
		
		//or
		
		out.write(data.toCharArray());//to write the whole string at a time
		out.close();
		System.out.println("finish");
	}

}
