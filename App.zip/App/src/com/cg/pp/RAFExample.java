package com.cg.pp;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RAFExample {

	public static void main(String[] args) throws IOException {
		//to read from file
		/*RandomAccessFile file=new RandomAccessFile("C:\\Users\\knavyaga\\Documents\\aaa.txt","r");
		file.seek(5);
		int c;
		while((c=file.read())!=-1){
			System.out.print((char)c);
		}*/
		
		
		//to write into the file
		RandomAccessFile file=new RandomAccessFile("C:\\Users\\knavyaga\\Documents\\aaa.txt","rw");
		String company="CApgemini,BAngalore";
		file.seek(file.length());
		file.writeUTF(company);
		file.close();
		System.out.println("done");
				
	}

}
