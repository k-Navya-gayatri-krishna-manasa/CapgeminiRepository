package com.cg.pp;

import java.util.Date;
import java.util.Calendar;

public class CalClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar c=Calendar.getInstance();
		Date d=c.getTime();
		System.out.println(d);
		System.out.println(c.get(Calendar.DATE));
		System.out.println(c.get(Calendar.MONTH));
		System.out.println(c.get(Calendar.YEAR));
		System.out.println(c.get(Calendar.DAY_OF_WEEK));
		System.out.println(c.get(Calendar.DAY_OF_YEAR));
		System.out.println(c.get(Calendar.WEEK_OF_MONTH));
		System.out.println(c.get(Calendar.HOUR));
		c.set(2021,10,21,14,32,59);
		d=c.getTime();
		System.out.println(d);

	}

}
