package com.cg.pp;

public @interface ArgumentsSource {

}
