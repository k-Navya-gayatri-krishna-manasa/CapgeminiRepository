package com.cg.pp;

import java.io.Console;

public class ConsoleClass {

	public static void main(String[] args) {
		Console c=System.console();
		String uid=c.readLine("Enter yout Id");
		char[] pwd=c.readPassword("Enter password:");
		System.out.println("Welcome"+uid);
		System.out.println("Your passsword is:"+new String(pwd));
		

	}

}
