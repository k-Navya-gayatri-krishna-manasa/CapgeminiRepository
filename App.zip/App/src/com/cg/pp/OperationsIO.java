package com.cg.pp;

import java.io.FileInputStream;
import java.io.IOException;

public class OperationsIO {
	public static void main(String[]args)throws IOException {
		FileInputStream fis=new FileInputStream("C:\\Users\\knavyaga\\Documents\\file.txt");
		/*int c;
		while((c=fis.read())!=-1) {
			System.out.print((char)c);
		}*/
		byte [] buffer=new byte[fis.available()];
		//fis.read(buffer);
		fis.read(buffer,5,10);
		//fis.read(buffer,0,buffer.length);
		String str=new String(buffer);
		System.out.println(str);
		
	}

}
