package com.cg.pp;
import static org.junit.Assert.*;

	import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

	//@ArgumentsSource(MyArgumentProvider.class)
	public class CalculatorTestCase implements TestInterface {
		Calculator cal=new Calculator();
		@Test
		public void testAdd() {
			Calculator cal=new Calculator();
			assertEquals(8,cal.add(3,5));
		}

		@ParameterizedTest
		@ValueSource(ints= {2,4,6,8})
		public void testIsEven(int n) {
			
			assertTrue(cal.isEven(10));
		}
		@TestFactory
		Collection<DynamicTest>dynamicTestWithCollection(){
			Calculator ca=new Calculator();
			return Arrays.asList(
					DynamicTest.dynamicTest("add Test dynamic",()->assertEquals(10,ca.add(10,0))));
		}
		/*private static class MyArgumentProvider implements ArgumentsProvider {

			@Override
			public Stream<? extends Arguments> provideArguments(ExtensionContext arg0) throws Exception {
				// TODO Auto-generated method stub
				return Stream.of(
						Arguments.of(10,0),
						Arguments.of(5,5),
						Arguments.of(6,4)
						);
			}
			
			
		}*/

	}

