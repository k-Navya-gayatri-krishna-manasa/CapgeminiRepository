package com.cg.pp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternClass {

	public static void main(String[] args) {
		String str="blue bottle with blue liquid with blue water";
		Pattern p=Pattern.compile("blue");
		Matcher matcher=p.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.group()+""+matcher.start()+""+matcher.end());
		}

	}

}
