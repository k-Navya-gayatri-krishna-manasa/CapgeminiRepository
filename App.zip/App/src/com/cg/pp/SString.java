package com.cg.pp;

public class SString {

	public static void main(String[] args) {
		
		/*String s="Hello World";
		System.out.println(s.toLowerCase());
		System.out.println(s.substring(6,9));
		System.out.println(s.replaceAll("World", "Baby"));
*/
		
	}

}
