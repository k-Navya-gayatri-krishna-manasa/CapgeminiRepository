package com.cg.pp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

public class Stream1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\aaa.txt");
		BufferedReader br=new BufferedReader(fr);
		LineNumberReader lr=new LineNumberReader(br);
		String str;
		while((str=lr.readLine())!=null) {
			System.out.println(lr.getLineNumber()+":"+str);
		}
		lr.close();
		br.close();
		fr.close();
		}

	}


