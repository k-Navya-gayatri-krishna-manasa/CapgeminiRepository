package com.cg.pp;

import java.io.FileInputStream;
//import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class MainSerializable {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		/*EmployeeSerializable emp=new EmployeeSerializable(101,"Binu","Male",34,45000);
		FileOutputStream fout=new FileOutputStream("C:\\Users\\knavyaga\\Documents\\a.txt");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		out.writeObject(emp);
		out.close();
		fout.close();
		System.out.println("Written");*/
//to read
		
		FileInputStream fin=new FileInputStream("C:\\Users\\knavyaga\\Documents\\a.txt");
		ObjectInputStream in=new ObjectInputStream(fin);
		EmployeeSerializable e=(EmployeeSerializable)in.readObject();
		System.out.println(e);
		in.close();
		fin.close();
	}

}
