package com.cg.cakeorder.dao;

import java.util.Map;

import com.cg.cakeorder.db.DB;
import com.cg.cakeorder.dto.CakeOrder;
import com.cg.cakeorder.dto.Customer;
import com.cg.cakeorder.exception.CakeException;

public class CakeOrderDaoImpl implements ICakeOrderDao{
	Map<Integer,Customer> custDb;
	Map<Integer,CakeOrder> orderDb;

	
	public CakeOrderDaoImpl() {
		custDb=DB.getCustomerDb();
		 orderDb=DB.getOredrDb();
	}


	@Override
	public int placeOrder(Customer customer, CakeOrder cake) throws CakeException
	{
	            int orderId=cake.getOrderId();
	            int custId=cake.getCustomerId();
				custDb.put(custId,new Customer(customer.getCustomerId(),customer.getCustName(),customer.getAddress(),customer.getPhone()));
				orderDb.put(orderId ,new CakeOrder(cake.getOrderId(),cake.getCustomerId(),cake.getTotalPrice()));
				return orderId;
			
			
		}


	@Override
	public CakeOrder getOrderDetails(int orderid) throws CakeException {
		if(orderDb.containsKey(orderid)) {
			return orderDb.get(orderid);
		}else {
			throw new CakeException("Order doesnot exist");
		}
		
	}
	}
	

