package com.cg.cakeorder.service;

import java.util.Random;

import com.cg.cakeorder.dao.CakeOrderDaoImpl;
import com.cg.cakeorder.dao.ICakeOrderDao;
import com.cg.cakeorder.dto.CakeOrder;
import com.cg.cakeorder.dto.Customer;
import com.cg.cakeorder.exception.CakeException;

public class CakeOrderService implements ICakeOrderService {
	Customer cust=new Customer();
	ICakeOrderDao cakeOrderDaoImpl=new CakeOrderDaoImpl();
	public int getPrice(String cakename) {
		int res = 0,base=500;
		if(cakename.equalsIgnoreCase("Vanila")) {
				res=base+120;
				//return res;
		}
		else if(cakename.equalsIgnoreCase("RedVelvet")) {
			res=base+180;
			//return res;
		}
		else if(cakename.equalsIgnoreCase("BlackForest")) {
			res=base+140;
			//return res;
		}
		else if(cakename.equalsIgnoreCase("Strawberry") ){
			res=base+105;
			
		}
		
		return res;
	}
	@Override
	public int placeOrder(Customer customer, CakeOrder cake) throws CakeException {
		return  cakeOrderDaoImpl.placeOrder(customer, cake);
		
	}
	public int setOrderingId() {
	Random r=new Random();
	int orderId1=Math.abs(r.nextInt());
	return orderId1;
	
	}
	public int setCustomerId() {
		Random r=new Random();
		int custId1=Math.abs(r.nextInt());
		return custId1;
	}
	public boolean validate(Customer cust) throws CakeException {
		
		boolean flag=true;
		StringBuilder sb=new StringBuilder();//to write the error msg
		if(!validateMobile(cust.getPhone())){
			sb.append("Invalid Mobile Number");
			sb.append("\n");
			flag=false;
		}
		
		if(flag) {
			return flag;
		}
		else {
			throw new CakeException(sb.toString());
		}
	}
	private boolean validateMobile(String mobile) {
		return mobile.matches("\\d{10}");
	}
	@Override
	public CakeOrder getOrderDetails(int orderid) throws CakeException {
		return cakeOrderDaoImpl.getOrderDetails(orderid);
		
	}
	
		
	
	

}
