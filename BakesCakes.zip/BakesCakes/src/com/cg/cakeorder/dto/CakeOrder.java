package com.cg.cakeorder.dto;

import java.util.Random;

import com.cg.cakeorder.service.CakeOrderService;

public class CakeOrder {
	CakeOrderService cakeOrderService=new CakeOrderService();
	private int orderId;
	private int customerId;
	private double totalPrice;
	public CakeOrder(int orderId, int customerId, double totalPrice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}
	public CakeOrder() {
		super();
	}
	public int getOrderId() {
		
		return orderId;
	}
	public void setOrderId(int orderId) {
		//this.orderId =cakeOrderService.setOrderingId();
		this.orderId =orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = cakeOrderService.setCustomerId();
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String cakename) {
		//CakeOrderService cos=new CakeOrderService();
		this.totalPrice = cakeOrderService.getPrice(cakename);
	}
	
}
