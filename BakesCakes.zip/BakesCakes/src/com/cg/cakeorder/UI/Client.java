package com.cg.cakeorder.UI;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.cakeorder.dto.CakeOrder;
import com.cg.cakeorder.dto.Customer;
import com.cg.cakeorder.exception.CakeException;
import com.cg.cakeorder.service.CakeOrderService;

public class Client {
	static Scanner sc=new Scanner(System.in);
	 
	 
	public static void main(String[] args) {
		
		int response;
		while(true) {
			System.out.println("1.Place Order");
			System.out.println("2. Display details");
			System.out.println("3. Exit");
			response=sc.nextInt();
			switch(response) {
			case 1:
				placingOrder();
				break;
			case 2:
				gettingDetails();
				break;
			case 3:
				System.exit(0);
				
			default:
				System.out.println("Invalid option,please select between 1 to 3");
				break;
			}
		}


	}
	static CakeOrderService cakeOrderService=new CakeOrderService();

	 static CakeOrder cor=new  CakeOrder();
	public static void placingOrder() {
		try {
			Customer cust=new Customer();
			
			System.out.println("Enter the name of the customer: ");
			cust.setCustName(sc.nextLine());
			sc.nextLine();
			System.out.println("Enter customer address:");
			cust.setAddress(sc.nextLine());
			//sc.nextLine();
			System.out.println("Enter customer phone number:");
			cust.setPhone(sc.nextLine());
			boolean result=cakeOrderService.validate(cust);
			System.out.println("Type of Cake:");
			String cname=sc.nextLine();
			cor.setTotalPrice(cname);
			System.out.println(cor.getTotalPrice());
			LocalDate today=LocalDate.now();
			System.out.println("Order date:"+today);
			int orderid=cakeOrderService.setOrderingId();
			cor.setCustomerId(cust.getCustomerId());
			cor.setOrderId(orderid);
			System.out.println("Cake Order successfully placed with Order Id:"+cakeOrderService.placeOrder(cust, cor));
	}catch(CakeException e){
		System.err.println(e.getMessage());			
	}catch(Exception ex) {
		ex.printStackTrace();
		System.err.println(ex.getMessage());
	}
			
			
		
	}
	public static void gettingDetails() {
		try {
			cakeOrderService.getOrderDetails(cor.getOrderId());
			System.out.println("Customer ID:"+cor.getCustomerId()+"\n"+"Order ID:"+cor.getOrderId()+"\n"+
			                       "Total Price:"+cor.getTotalPrice());
		}catch(CakeException e) {
			System.err.println("Sorry,not able to display order details");
		}
	}

}
