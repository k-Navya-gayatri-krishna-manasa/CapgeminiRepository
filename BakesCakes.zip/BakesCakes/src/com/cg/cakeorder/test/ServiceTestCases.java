package com.cg.cakeorder.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ServiceTestCases {

	@Test
	public void testPlaceOrder() {
		
	}

	@Test
	public void testGetOrderDetails() {

	}

}
