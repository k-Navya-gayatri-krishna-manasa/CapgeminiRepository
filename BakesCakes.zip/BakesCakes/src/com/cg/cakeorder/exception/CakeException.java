package com.cg.cakeorder.exception;

public class CakeException extends Exception{
		public CakeException(){
			super();
		}
		public CakeException(String message) {
			super(message);
		}

	}
