package com.cg.cakeorder.db;

import java.util.HashMap;
import java.util.Map;

import com.cg.cakeorder.dto.CakeOrder;
import com.cg.cakeorder.dto.Customer;



public class DB {
	private static Map<Integer, Customer> CustomerDb=new HashMap<Integer, Customer>();
	private static Map<Integer,CakeOrder> oredrDb=new HashMap<Integer,CakeOrder>();
	public static Map<Integer, Customer> getCustomerDb() {
		return CustomerDb;
	}
	public static void setCustomerDb(Map<Integer, Customer> customerDb) {
		CustomerDb = customerDb;
	}
	public static Map<Integer, CakeOrder> getOredrDb() {
		return oredrDb;
	}
	public static void setOredrDb(Map<Integer, CakeOrder> oredrDb) {
		DB.oredrDb = oredrDb;
	}
	
}
