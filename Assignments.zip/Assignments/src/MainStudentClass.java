import java.util.Scanner;

public class MainStudentClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Students s=new Students();
		System.out.println("Enter Student id:");
		s.setSid(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Student FirstName:");
		s.setFirstname(sc.nextLine());
		System.out.println("Enter Student Lastname:");
		s.setLastname(sc.next());
		System.out.println("Enter age of student");
		s.setAge(sc.nextInt());
		System.out.println("Enter Stream of student:");
		s.setStream(sc.next());
		System.out.println("Enter student Mobbile number:");
		s.setMobno(sc.next());
		System.out.println("Enter email Id:");
		s.setEmail(sc.next());
		
		System.out.println(s.getSid()+"\n"+s.getFirstname()+"\n"+s.getLastname()+"\n"+s.getAge()+"\n"+s.getStream()+"\n"+s.getMobno()+"\n"+s.getEmail());
		

	}
}
