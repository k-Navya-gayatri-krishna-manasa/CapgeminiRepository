import java.util.Scanner;

public class Students {
	private static final Exception Exception = null;

	Scanner sc=new Scanner(System.in);
	private String firstname,lastname,stream,email;
	private int sid, age;
	private String mobno;
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		String em=email;
		if(em.matches("[a-z][a-z0-9_\\.]+@[a-z]+\\.(com|net|in)"))
			this.email = email;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		String fn=firstname;
		if(fn.matches("[A-Z][a-z\\s]{3}"))
				this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getStream() {
		return stream;
	}


	public void setStream(String stream) {
		this.stream = stream;
	}


	public int getSid() {
		return sid;
	}


	public void setSid(int sid) {
		this.sid = sid;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		int a=age;
		if(a>17 && a<61)
			this.age = age;
		else {
			try {
				throw Exception;
			}
			catch(Exception e) {
				System.out.println("Entered age is out of range.It should be from 18 to 60");
				a=sc.nextInt();
				
			}
		}
		
	}


	public String getMobno() {
		return mobno;
	}


	public void setMobno(String mobno) {
		String mn=mobno;
		if(mn.matches("[5-9][\\d]{10}"))
			this.mobno = mobno;
	}


	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Students s=new Students();
		System.out.println("Enter Student id:");
		s.setSid(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Student FirstName:");
		s.setFirstname(sc.nextLine());
		System.out.println("Enter Student Lastname:");
		s.setLastname(sc.next());
		System.out.println("Enter age of student");
		s.setAge(sc.nextInt());
		System.out.println("Enter Stream of student:");
		s.setStream(sc.next());
		System.out.println("Enter student Mobbile number:");
		s.setMobno(sc.next());
		System.out.println("Enter email Id:");
		s.setEmail(sc.next());
		
		System.out.println(s.getSid()+"\n"+s.getFirstname()+"\n"+s.getLastname()+"\n"+s.getAge()+"\n"+s.getStream()+"\n"+s.getMobno()+"\n"+s.getEmail());
		

	}

}
