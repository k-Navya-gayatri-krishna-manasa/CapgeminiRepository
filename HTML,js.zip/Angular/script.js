var name="Binu";
//function myFun(){
  /*   let message;
    if(name=="Shilpa"){
         message="Hello Shilpa"
    }
    else{
         message="Hey, there";
    }
    console.log(message); */


    // constant variable

    /* const myName="Shilpa";
    console.log(myName); */
//}

//arrow functions

/* greet=()=>"Hello";

function greet(){
    return "Hello";
}
var greet1=()=>{console.log("Hello World")};

var sum=(a,b)=>a+b;
var sqr=(a)=>a*a;
var doWork=()=>{
    console.log("Hello");
} */
var message="List of colors";
/* function displayColors(){
    console.log(message);
    for(let i=0;i<arguments.length;i++){
        console.log(arguments[i]);
    }
} */

    //or;

  
    function displayColors(message,...colors){
        console.log(colors);
        console.log(message);
    for(i in colors){
        console.log(colors[i]);
    }
    }
   








