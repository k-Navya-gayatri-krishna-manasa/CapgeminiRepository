
var name="Capgemini"   //global variable within the script but outside the function

function myFunction(){  
    userName ="Lucy"; //if we declare a variable without var key word it is treated as global variable
    alert("Welcome to Javascript training");
}
function add(a,b,c){
    return a+b+c;
}
var func=function(){     //creating function using function expression ..by this function
    // can be passed as a parameter to another functio...so called as functional programming. 
    console.log("Hello World");
}
//we write method as whatevr the number of arguments we give it should add all of them and return the result
function addition(){
    var sum=0; //local variable (with in the function)
    for(var i=0;i<arguments.length;i++){
           //arguments is an object that identifies the args
           var count=30;
        sum=sum+arguments[i];
    }
    alert(count);
    return sum;

}