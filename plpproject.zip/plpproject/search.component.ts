import { Component, OnInit } from '@angular/core';
import { PlpSearchService } from './plp-search.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
item:any[]=[];
result=false;
Id:number;
  constructor(private service:PlpSearchService) { }

  
  Search(data:String) {
    this.result=true;
    this.service.getitemByName(data).subscribe((pro:any)=> {this.item = pro; 
      this.getIdByName(data)
    });

  }

  getIdByName(data:String) {
    this.service.getIdbyName(data).subscribe((pro:any)=> {this.Id = pro;console.log(this.Id)
    });
    
  }

}
