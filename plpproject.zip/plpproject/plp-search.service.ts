import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlpSearchService {

  constructor(private http:HttpClient) { }
  baseurl1='http://localhost:9600/mapping';
  getitemByName(name:String){
    return this.http.get(`${this.baseurl1}/getByName/${name}`);
  }

  getitemById(Id:Number){
    return this.http.get(`${this.baseurl1}/getById/${Id}`);
  }

  updateOnId(Id:number){
    return this.http.post("http://localhost:9600/mapping/updateById/"+Id,+Id);
  }

  getDelivery(Id:number){
    console.log("service"+Id);
    return this.http.get(`${this.baseurl1}/getDeliveryDetail/${Id}`);
  }

  getIdbyName(name:String){
    console.log("service"+name);
    return this.http.get(`${this.baseurl1}/getIdByName/${name}`);
  }
  
}
