import { Component, OnInit } from '@angular/core';
import { PlpSearchService } from './plp-search.service';
import { Router } from '../../../node_modules/@angular/router';


@Component({
  selector: 'app-radio-search',
  templateUrl: './radio-search.component.html',
  styleUrls: ['./radio-search.component.css']
})
export class RadioSearchComponent {

  constructor(private router:Router) { }
  ByName(){
    this.router.navigate(['./BySearchName']);
  }
  ById(){
    
    this.router.navigate(['./BySearchId']);
  }
}
