import { Component, OnInit } from '@angular/core';
import { PlpSearchService } from './plp-search.service';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent {

  constructor(private service:PlpSearchService) { }
item:any[]=[];
result=false;
status:number;
status1:String;
show=false;
 Search(data:number) {
    this.result=true;
    this.service.getitemById(data).subscribe((pro:any)=> {this.item = pro;console.log(this.item);
      this.getDelivery(data)
    });
    
  }

  updates(data1:number){
    console.log(data1)
    this.service.updateOnId(data1).subscribe((pro:any)=> {this.item = pro;
        this.show=true;
    });
  }

  getDelivery(data2:number){
   
    this.service.getDelivery(data2).subscribe((pro:any)=> {this.status = pro;console.log(status);
      if(this.status==1){
          this.status1="Not Initiated";
      }
      else if(this.status==2){
        this.status1="Initiated";
      }
      else if(this.status==3){
        this.status1="Completed";
      }
      else if(this.status==4){
        this.status1="Not Applicable";
      }
      else{
        this.status1="No Proper Info";
      }
    });
  }
  
}
