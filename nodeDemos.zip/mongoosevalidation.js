const mongoose=require("mongoose");
//connect is method
mongoose.connect("mongodb://localhost:27017/dummy",{useNewUrlParser:true})
//conection is eventEmitteeer
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});


//defining the schema
let empSchema=new mongoose.Schema({
    _id:Number,
    name:{type:String, required:true,pattern:"[A-Z][A-Za-z\s]+"},
    gender:{type:String, required:true,enum:["Male","Female"]},
    age:{type:Number,min:18,max:60},
    salary:Number,
})
let Employee=mongoose.model("employees",empSchema);
//inserting data
let emp=new Employee({
    _id:1015,
    name:"andy",
    gender:"Male",
    age:21,
    salary:3000
});
emp.save().then(function(){
    console.log("Employee document saved");
    process.exit(0);
}).catch(function(error){
    console.log("Error"+error);
    process.exit(0);
})