const mongoose=require("mongoose");
//connect is method
mongoose.connect("mongodb://localhost:27017/dummy",{useNewUrlParser:true})
//conection is eventEmitteeer
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});


//defining the schema
let empSchema=new mongoose.Schema({
    _id:Number,
    name:String,
    gender:String,
    age:Number,
    department:String,
    address:{
        street:String,
        city:String,
        pincode:String
    },
    locations:[{type:String}],
    salary:Number
})

let Employee=mongoose.model("employees",empSchema);
Employee.find({_id:1004}).then(function(emp){
    emp.forEach(e=>{
    console.log(e._id+" "+e.name+" "+e.address.city+" "+e.locations)
}).catch(function(error){
    console.log("Error"+error);
})
})