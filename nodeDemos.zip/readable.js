const path=require("path");
const fs=require("fs");
let rs=fs.createReadStream(path.join(__dirname,"data.txt"));
//to make the reading flow stop from stream so no data will be mobved
rs.readableFlowing=false;

let data="";
rs.on("readable",function(){
   while((data=rs.read())!=null){
       console.log(data.toString());
   }
})
rs.on("data",function(chunk){
    data+=chunk;
})
rs.on("error",function(){
    console.log("Error ocuured"+console.error);
})
rs.on("end",function(){
   // console.log(data);
})
console.log("program ended");