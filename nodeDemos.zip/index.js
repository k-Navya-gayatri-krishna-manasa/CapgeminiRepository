/* var counter=require("./stuff")

counter.counter([1,2,3,4]);
var sum=counter.adder(10,20);
console.log(sum);
console.log(counter.pi);

//creation of buffer
/* var b=new Buffer(10);   it shows error
 */
/* var b=Buffer.alloc(100); 
var b1=Buffer.from([10,20]);
var b1=Buffer.from("CapGemini","utf8");
let city='bangalore';
b.write(city,0,city.length,"utf8");
console.log(b.toString());
console.log(b.toString("utf8",3,6));
console.log(b.toJSON());
let b2=Buffer.alloc(50);
b1.copy(b2,0,0,5);
console.log(b2.toString()); 
 */


 //Event Handling in Node

 /* const events=require("events");
 let myEvent=new events.EventEmitter();
 myEvent.on("myevent", function(){
     console.log("My Event Fired")
 })

 myEvent.emit("myevent");
 */


 //to make other variables as EventEmitters

/* const events=require("events");
const util=require("util");

var Person=function(name){
    this.name=name;
}
util.inherits(Person,events.EventEmitter);
let p1=new Person("manu");
let p2=new Person("Baby");
let persons=[p1,p2];
persons.forEach(function(p){
    p.on("speak",function(msg){
        console.log(p.name+"  Said  "+msg);
    })
})
p1.emit("speak","hello");
p2.emit("speak","hai");
 */
//-----------------------------------------------------------------------------------

//File System module

//to read data from file and print on console
const fs=require("fs");
const path=require("path");
 /* var content=fs.readFileSync("data.txt"); 
 console.log(content.toString());  */
/* fs.readFile("data1.txt", "utf8",(error,content)=>{

 */

/* this one is used when the file is in other location */ 
  // fs.readFile(path.join(__dirname,"data.txt"), "utf8",(error,content)=>{

   // if(error){
   // console.log("Error reading file");
   // return;
    /* throw error; */
    //}
   // console.log(content);
//})



//to write string data into a file

/* let str="hello world";
fs.writeFile(path.join(__dirname,"data1.txt"),str,"utf8",(error)=>{
    if(error){
        console.log("Unable to write to the file");
        return;
    }
    console.log("File Written Successfully");
}) */


//reading from one file and writing to other file
//var content=fs.readFileSync("data.txt");//this only read data to contnts
/* var content=fs.readFileSync(path.join(__dirname,"data.txt"), "utf8",(error,content)=>{
    //this is used to read data syn and check for error whether reading file is exist or not
    if(error){
     console.log("Error reading file");
    return;
    }
    })
fs.writeFile(path.join(__dirname,"data3.txt"),content,"utf8",(error)=>{
    if(error){
        console.log("Unable to write to the file");
        return;
    }
    console.log("File Written Successfully");
}) */


//to check whether file exists or not


/* fs.exists(path.join(__dirname,"abc.txt"),(status)=>{
    console.log(status);
}) */


//to read data from file and write to buffer and print on console from buffer

/* fs.open(path.join(__dirname,"data3.txt"),"r",(error,fd)=>{
    if(error){
        console.log("File doesnt exists");
        return;
    }
    let b=Buffer.alloc(50);
    fs.read(fd,b,0,b.length,0,(error,bytes)=>{
        if(error){
            console.log("unable to read the file")
            return;
        }
        console.log(bytes+" bytes read from the file");
        console.log(b.toString());
    })
}) */
//--------------------------------------------------------------------------------
//to create servers
const http=require("http");
let server=http.createServer((req,res)=>{
    res.writeHead(200,{
        "Content-Type":"text/html"
    })

    /* res.write("<h2>Hello World</h2>");
    res.end("<h1>Welcome to Node Js</h1>"); */
    if(req.url==="/"){
        //res.write("<h1>Home Page</h1>");
        //to navage to diff html file using files
        fs.readFile(path.join(__dirname,"home.html"),(error,content)=>{
            if(error){
                throw error;
            }
            else{
                res.write(content);
            }
        })
    }
    else if(req.url==="/about"){
      //  res.write("<h1>About Page</h1>");
        fs.readFile(path.join(__dirname,"about.html"),(error,content)=>{
            if(error){
                throw error;
            }
            else{
                res.write(content);
            }
        })
    }
    else if(req.url==="/contact"){
        //res.write("<h1>Contact Page</h1>");
        fs.readFile(path.join(__dirname,"contact.html"),(error,content)=>{
            if(error){
                throw error;
            }
            else{
                res.write(content);
            }
        })
    }  
});
server.listen(5000,()=>{
    console.log("Server started @port 5000");
})

//--------------------------------------------------------------------------------------------