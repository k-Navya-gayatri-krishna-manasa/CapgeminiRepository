var path = require('path');
var express = require('express');
var app = express();
app.use(express.urlencoded({ extended: false }));
//app.use(express.static(path.join(__dirname, 'userdetails.html')));
app.get("/handler",function(req,res){
    res.sendFile(path.join(__dirname,"userdetails.html"));
})
app.post('/handler', function (req, res) {
  console.log(req.body);
  res.send(req.body);
});


let PORT=process.env.PORT||5000; 
app.listen(5000,()=>{
    console.log("Server started @port 5000");
})

