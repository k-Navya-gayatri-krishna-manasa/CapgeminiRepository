let arr=["manu","sai","babe","love","thanu","krishna"];
console.log(arr);