const fs=require("fs");
const path=require("path");
let str="hai lucy,is ur mad condition okay?";
fs.writeFile(path.join(__dirname,"data1.txt"),str,"utf8",(error)=>{
    if(error){
        console.log("Unable to write to the file");
        return;
    }
    console.log("File written successfully");
})
