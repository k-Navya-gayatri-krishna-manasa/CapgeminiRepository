const mongodb=require("mongodb");

const MongoClient=mongodb.MongoClient;


MongoClient.connect("mongodb://localhost:27017/newdb",{useNewUrlParser:true},function(error,client){
    if(error){
        return console.log("Error occured:"+error);
    }
    console.log("Connection to the server established");

    let db=client.db("dummy");
    //to add data
    let collection=db.collection("products");
   /*  let p1={_id:5,name:"kalakani",cost:45,desc:"sweet"};
    collection.insert([p1],function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        console.log(`${res.insertedCount} documents inserted`);
    }); */
    //to get all the data
   /*  collection.find(function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        res.forEach(pro=>{
            console.log(pro._id+"\t"+pro.name+"\t"+pro.cost+"\t"+pro.desc)
        })
    }) */
    //to get data based on condition
   /*  collection.find({_id:4},function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        res.forEach(pro=>{
            console.log(pro._id+"\t"+pro.name+"\t"+pro.cost+"\t"+pro.desc)
        })
    }) */
    //to delete the data
    /* collection.deleteOne({_id:3}).then(function(){
        console.log("Record deleted");
        process.exit();
    }).catch(function(error){
        console.log("Error"+error);
        process.exit(0);
    }) */
    //to update the data
    collection.update({_id:2},{$set:{cost:100}},function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        
            console.log("Document updated")
        
    })

  
})