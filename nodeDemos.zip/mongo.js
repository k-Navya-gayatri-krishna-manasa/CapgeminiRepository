const mongodb=require("mongodb");
//to establish connect to with property MongoClient we need mongodb
const MongoClient=mongodb.MongoClient;

//to establish connectivity
MongoClient.connect("mongodb://localhost:27017/newdb",{useNewUrlParser:true},function(error,client){
    if(error){
        return console.log("Error occured:"+error);
    }
    console.log("Connection to the server established");
    //reference to db:this dummy is db we created in cmd prompt in client part conn i.e.,.mongo
    let db=client.db("dummy");
    //reference to collection:these collections are created in cmd prompt in client part conn i.e.,.mongo
    let collection=db.collection("employees");
    //creating two objects and insrting data into collcetion under db
   /*  let emp1={_id:1006,name:"jeeju",gender:"Male",age:25};
    let emp2={_id:1007,name:"vyshu",gender:"FeMale",dept:"cse"};
    collection.insert([emp1,emp2],function(error,res){
        if(error){
            return console.log("Error occured:"+error);

        }
        console.log(`${res.insertedCount} documents inserted`);

    }) */
    //to print all the data from employees collection in dummy db
    collection.find(function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        res.forEach(emp=>{
            console.log(emp._id+"\t"+emp.name+"\t"+emp.gender+"\t"+emp.age+"\t"+emp.dept)
        })
    })
    //finding based on condition
    collection.find({_id:1003},function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        res.forEach(emp=>{
            console.log(emp._id+"\t"+emp.name+"\t"+emp.gender+"\t"+emp.age+"\t"+emp.dept)
        })
    })
  
    //to update data based on condition
    collection.update({_id:1003},{$set:{salary:1000000}},function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        
            console.log("Document updated")
        
    })
    //to delete data
    collection.remove({_id:1003},function(error,res){
        if(error){
            return console.log("Error occured:"+error);
        }
        
            console.log("deleted")
        
    })

});