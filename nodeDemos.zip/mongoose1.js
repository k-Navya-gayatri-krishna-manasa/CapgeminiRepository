const mongoose=require("mongoose");
//connect is method
mongoose.connect("mongodb://localhost:27017/dummy",{useNewUrlParser:true})
//conection is eventEmitteeer
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});
//defining the schema
let empSchema=new mongoose.Schema({
    _id:Number,
    name:String,
    gender:String,
    age:Number,
    salary:Number,
})
//creating the model
let Employee=mongoose.model("employees",empSchema);
//to display data
/* Employee.find().then(function(emps){
    //to display data with condition:Employee.find({_id:1002})
    emps.forEach(emp=>{
        console.log(emp._id+" "+emp.name+" "+emp.salary);
   
    })
    process.exit(0);
    }).catch(function(error){
        console.log(error);
        process.exit(0);
})
 */
//update

/* Employee.update({_id:1004},{$set:{salary:2000000}}).then(function(){
    console.log("Record updated");
    process.exit();
}).catch(function(error){
    console.log("Error"+error);
    process.exit(0);
}) */

//remove
Employee.deleteOne({_id:1004}).then(function(){
    console.log("Record deleted");
    process.exit();
}).catch(function(error){
    console.log("Error"+error);
    process.exit(0);
})
 
