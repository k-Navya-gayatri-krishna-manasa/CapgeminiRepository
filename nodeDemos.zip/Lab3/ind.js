const mongoose=require("mongoose");
//connect is method
mongoose.connect("mongodb://localhost:27017/dummy",{useNewUrlParser:true})
//conection is eventEmitteeer
mongoose.connection.on("error",function(error){
    console.log("Error"+error);
})
mongoose.connection.once("open",function(){
    console.log("connection to db established")
});
//defining the schema
let empSchema=new mongoose.Schema({
    empId:Number,
    empName:String,
    empSalary:Number,
    empAddress:{
        city:String,
        state:String,
    }
})
let Employee=mongoose.model("employees",empSchema);
Employee.find().then(function(emps){
    //to display data with condition:Employee.find({_id:1002})
    emps.forEach(emp=>{
        console.log(emp.empId+" "+emp.empName+" "+emp.empSalary+" "+emp.empAddress);
   
    })
    process.exit(0);
    }).catch(function(error){
        console.log(error);
        process.exit(0);
})