package cg.com.com;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamExm {

	public static void main(String[] args) {
		Stream<Integer>stream=Stream.of(10,20,30,13,8,15,7,82);
		//stream.forEach(System.out::println);
		/*Optional<Integer> result=stream.max((a,b)->a>b?1:a<b?-1:0);
		System.out.println(result.get());
		*/
		
		/*List<Integer>list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.stream();
		Optional<Integer> result=stream.filter(e->e%2==0).min((a,b)->a>b?1:a<b?-1:0);
		System.out.println(result.get());
		*/
		//stream.sorted().forEach(System.out::println);
		
		//to change  stream to collection 
		
		/*List<Integer>list1=stream.collect(Collectors.toList());
		for(Integer integer:list1)
			System.out.println(integer);
			*/
		
		
		List<String> strings=new ArrayList<String>();
		strings.add("Hello");
		strings.add("bava");
		strings.add("miss");
		strings.add("you");
		//strings.stream().map(e->e.length()).forEach(System.out::println);
		System.out.println("---------------------------------------------------------");
		strings.add("you");
		strings.stream().forEach(System.out::println);
		System.out.println("---------------------------------------------------------");
		strings.stream().distinct().forEach(System.out::println);//produces stream without duplicates
		System.out.println("---------------------------------------------------------");
		strings.parallelStream().limit(2).forEach(System.out::println);	
		strings.stream().skip(2).forEach(System.out::println);
		System.out.println("---------------------------------------------------------");
		//Optional<Integer> result=stream.filter(e->e%2==0).reduce((a,b)->a+b);
		//10,20,30,13,8,15,7,82
		//System.out.println(result.get());
		Optional<Integer> result1=stream.reduce((a,b)->a+b);
		System.out.println(result1.get());
		
		

	}

}
