import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-ecobeauty-admin',
  templateUrl: './ecobeauty-admin.component.html',
  styleUrls: ['./ecobeauty-admin.component.css']
})
export class EcobeautyAdminComponent implements OnInit {
  proddata:any[]=[];
  prodata:any[]=[];
  
selectedFiles:FileList;
 currentFileUpload:File;
 dataone:any[];
 prodPrice:number;
 prodName:String;
 result=false;
  selectFile(event){
    this.selectedFiles=event.target.files;
  }
  constructor(private service:ProductserviceService,private router:Router) { }
  upload(){
    this.currentFileUpload=this.selectedFiles.item(0);
    this.service.beautySaveProfile(this.currentFileUpload).subscribe(event=>{     
  });
  this.selectedFiles=undefined;
 } 
  getbeautydata(){
   console.log("haiii");
   this.service.getBeautydata().subscribe((data:any)=>this.proddata=data);
   this.result=true;
 } 
 ngOnInit(){
  this.service.getBeautydata().subscribe((data:any)=>this.proddata=data);
 }
 deletebutton1(data:any){
  console.log(data);
  let index=this.prodata.indexOf(data);
  this.prodata.splice(index,1);
  this.service.deleteBeautyProduct(data).subscribe();
}
updateButton1(data):any{
 this.router.navigate(['/updateBeauty']);
}
  

  /* model:any={};  //model is the obj that accepts the data of employee id,name,salary
  model1:any={};  //model is the obj that accepts the data of employee id,name,salary

  addProduct(model):any{
    console.log(this.model);
    this.Service.addProduct(this.model).subscribe();
  }
 
  updateProduct(model1):any{
    console.log(this.model1);
    this.Service.updateSanitationProduct(this.model1).subscribe();
  }

  GoBack(){
    this.router.navigate(['/ecobeauty']);
  }
  
  constructor(private Service:ProductserviceService,private router:Router) { }
 
  ngOnInit() {
  }
 */


}
