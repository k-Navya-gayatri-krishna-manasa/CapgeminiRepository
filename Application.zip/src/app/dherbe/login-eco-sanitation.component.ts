import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login-eco-sanitation',
  templateUrl: './login-eco-sanitation.component.html',
  styleUrls: ['./login-eco-sanitation.component.css']
})
export class LoginEcoSanitationComponent implements OnInit {

  constructor(private service:ProductserviceService,private router:Router) { }
  proddata:any[]=[];
  prodname:String;
  pros:any;
selectedFiles:FileList;
 currentFileUpload:File;
 dataone:any[];
 prodPrice:number;
 prodName:String;

  ngOnInit() {
    this.service.getdata().subscribe((data:any)=>{this.proddata=data;
    this.onSubmit()
    });
    console.log("Sani"+this.proddata);
    
  }
  getByName() {
    console.log(this.prodname);
    this.service.getSanitationProdutByName(this.prodname)
      .subscribe((pro:any)=> this.pros = pro);
  }
  onSubmit() {
    this.getByName();
  }
  onSearch(value){
    console.log(value);
    this.proddata=this.proddata.filter(b=>b.prodName.toLowerCase().match(value.toLowerCase()) || b.stock.toLowerCase().indexOf(value.toLowerCase())!=-1 || b.eDate.toLowerCase().indexOf(value.toLowerCase())!=-1);
  }
  AddToCart(){
    
  }
  

}
