import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logout-success',
  templateUrl: './logout-success.component.html',
  styleUrls: ['./logout-success.component.css']
})
export class LogoutSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
