import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Route } from '../../../node_modules/@angular/compiler/src/core';
import { Router } from '../../../node_modules/@angular/router';
import { Sanitation } from './sanitation.interface';

@Component({
  selector: 'app-ecosanitation',
  templateUrl: './ecosanitation.component.html',
  styleUrls: ['./ecosanitation.component.css']
})
export class EcosanitationComponent implements OnInit {

  constructor(private service:ProductserviceService,private router:Router) { }
  proddata:any[]=[];
  prodname:String;
  pros:any;
selectedFiles:FileList;
 currentFileUpload:File;
 dataone:any[];
 prodPrice:number;
 prodName:String;
 list:Sanitation[];
show=false;
  ngOnInit() {
    this.service.getdata().subscribe((data:any)=>{this.proddata=data;
    this.onSubmit()
    });
    console.log("Sani"+this.proddata);
    this.show=true;
    
  }
  getByName() {
    console.log(this.prodname);
    this.service.getSanitationProdutByName(this.prodname)
      .subscribe((pro:any)=> this.pros = pro);
  }
  onSubmit() {
    this.getByName();
  }
  onSearch(value){
    console.log(value);
    this.proddata=this.proddata.filter(b=>b.prodName.toLowerCase().match(value.toLowerCase()) || b.stock.toLowerCase().indexOf(value.toLowerCase())!=-1 || b.eDate.toLowerCase().indexOf(value.toLowerCase())!=-1);
  }
  AddToCart(){
    this.router.navigate(['/userlogin'])
  }
 

 

}
