import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';
import { THIS_EXPR } from '../../../node_modules/@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent  {
mobile:number;
result:number;
message:String;
  constructor(private service1:ProductserviceService,private router:Router) { }
  role=1;
 
  check(mobile:number,password:String){
    
    console.log("login"+mobile+password);
      this.service1.adminDetails(mobile,password).subscribe((data:number)=>{this.result=data;
      console.log("loooo"+this.result);
      if(this.result==1){
        this.router.navigate(['/admin']);
        }else if(this.result==2)
        {
        this.router.navigate(['/products']);
        }
        else{
          this.router.navigate(['/superUser']);
        }
        
    });
    
  }

 }
