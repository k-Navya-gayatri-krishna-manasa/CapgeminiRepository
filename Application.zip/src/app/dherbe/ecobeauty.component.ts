import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-ecobeauty',
  templateUrl: './ecobeauty.component.html',
  styleUrls: ['./ecobeauty.component.css']
})
export class EcobeautyComponent implements OnInit {

  constructor(private service:ProductserviceService,private router:Router) { }
  proddata:any[]=[];
  selectedFiles:FileList;
  currentFileUpload:File;
 show=false;
 ngOnInit(){
    console.log("haiii");
    this.service.getBeautydata().subscribe((data:any)=>this.proddata=data);
    this.show=true;
 }

 onSearch(value){
  console.log(value);
  this.proddata=this.proddata.filter(b=>b.prodName.toLowerCase().match(value.toLowerCase()) || b.stock.toLowerCase().indexOf(value.toLowerCase())!=-1 || b.eDate.toLowerCase().indexOf(value.toLowerCase())!=-1);
}
AddToCart(){
  this.router.navigate(['/userlogin'])
}

 

}

