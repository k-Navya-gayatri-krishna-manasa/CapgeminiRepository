import { Injectable } from '@angular/core';
import { IEmployee } from './employee.interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:IEmployee[]=[];

  constructor(private http:HttpClient) { }


   /* Getting data from the Json File */
    getEmployees():Observable<IEmployee[]>{
      return this.http.get<IEmployee[]>("./assets/employee.json")
  }

   /* Adding the employee data */
  addEmployee(emp){
    this.employees.push(emp);
  } 
  getDb(){
    return this.employees;
  }
  
   }
