import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { IEmployee } from './employee.interface';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

/* creating the object for the service in constructor*/
  constructor(private employeeservice:EmployeeService,private router:Router) { }

  ngOnInit() {
  }

 /*  Calling the addEmployee method that is there in service using service object and then go to listemployee */
  onSubmit(form:IEmployee){
    this.employeeservice.addEmployee(form);
    this.router.navigate(['/list']);
  }
}
