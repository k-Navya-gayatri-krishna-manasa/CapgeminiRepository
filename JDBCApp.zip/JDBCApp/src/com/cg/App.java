package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class App {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Class.forName("oracle.jdbc.driver.OracleDriver");      //loading driver
		
		                                  //or
		
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection con=DriverManager.getConnection(url,"system","orcl11g");
		Statement stat=con.createStatement();
		ResultSet res=stat.executeQuery("select * from tblEmployee");  //to use that statement select
		System.out.println("Employee Id \t Name \t Gender \t Salary \tDepartment");
		while(res.next()) {
			System.out.println(res.getInt(1)+"\t\t"+res.getString(2)+"\t"+res.getString(3)+"\t"+res.getDouble("Salary")+"\t"+res.getInt("departmentId"));
		//.get---(can enter either column number of the table or column name)
		}
				
		
	}

}
