package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class App3 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Scanner sc=new Scanner(System.in);
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		Connection con=DriverManager.getConnection(url,"system","orcl11g");
		con.setAutoCommit(false);
		System.out.println("Enter Id:");
		int eid=sc.nextInt();
		/*sc.nextLine();
		System.out.println("Enter Name:");
		String ename=sc.nextLine();
		//sc.nextLine();
		System.out.println("Enter gender(Data sensitive)");
		String gen=sc.nextLine();*/
		System.out.println("eNTER SALARY:");
		double salary=sc.nextDouble();
		System.out.println("Enter Id to delete:");
		int eid1=sc.nextInt();
		//System.out.println("Enter department Id:");
		//int did=sc.nextInt();
		//PreparedStatement stat=con.prepareStatement("Insert into tblEmployee values(?,?,?,?,?)");
		PreparedStatement stat=con.prepareStatement("update tblemployee set salary=salary+? where id=?");
		PreparedStatement stat1=con.prepareStatement("delete tblemployee where id=?");
		//DML statement we are inserting the data into table no need of result set
		stat.setInt(2, eid);
		//stat.setString(2, ename);
		//stat.setString(3,gen); 
		//stat.setDouble(4,salary);
		stat.setDouble(1,salary);
		stat1.setInt(1, eid1);
		//stat.setInt(5, did);
		int result=stat.executeUpdate();
		con.commit();
		System.out.println(result+"row(s) inserted");
		int result1=stat1.executeUpdate();
		System.out.println(result1+"row(s) deleted");
	}

}
