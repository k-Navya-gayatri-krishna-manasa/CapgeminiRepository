package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class App2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		Connection con=DriverManager.getConnection(url,"system","orcl11g");
		System.out.println("Enter gender(Data sensitive)");
		String gen=sc.nextLine();
		System.out.println("Enter min salary:");
		double  minsal=sc.nextDouble();
		System.out.println("Enter max salary:");
		double maxsal=sc.nextDouble();
		sc.nextLine();
		PreparedStatement stat=con.prepareStatement("select * from tblEmployee where gender=? and salary between ? and ?");
		stat.setString(1,gen); 
		stat.setDouble(2,minsal);
		stat.setDouble(3, maxsal);
		ResultSet res=stat.executeQuery();  
		System.out.println("Employee Id \t Name \t Gender \t Salary \tDepartment");
		while(res.next()) {
			System.out.println(res.getInt(1)+"\t\t"+res.getString(2)+"\t"+res.getString(3)+"\t"+res.getDouble("Salary")+"\t"+res.getInt("departmentId"));
		//get---(can enter either column number of the table or column name)
			
		}
		
	}

}
