package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class ByUsingProcedures {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		System.out.println("Enter empId:");
		int id=sc.nextInt();
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		Connection con=DriverManager.getConnection(url,"system","orcl11g");
		CallableStatement stat=con.prepareCall("{call getEmpDetails(?,?,?)}");
		//CallableStatement stat=con.prepareCall("{?=call getEmpDetails(?,?,?)}"); //for procedure with variable eg2
		stat.setInt(1, id);
		stat.registerOutParameter(2, Types.VARCHAR);
		stat.registerOutParameter(3, Types.NUMERIC);
		stat.execute();
		String name=stat.getString(2);
		double salary=stat.getDouble(3);
		System.out.println("Name:"+name);
		System.out.println("Salary:"+salary);
	}

}
