package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class App1ToAcceptDataFromKeyboard {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Scanner sc=new Scanner(System.in);
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Class.forName("oracle.jdbc.driver.OracleDriver");      //loading driver
		
		                                  //or
		
		//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection con=DriverManager.getConnection(url,"system","orcl11g");
		System.out.println("Enter gender(Data sensitive)");
		String gen=sc.nextLine();
		//Statement stat=con.createStatement();
		PreparedStatement stat=con.prepareStatement("select * from tblEmployee where gender=?");
		stat.setString(1, gen);  //no.of parameters:1 varaible in which we are acception from keyboard
		ResultSet res=stat.executeQuery();  
		System.out.println("Employee Id \t Name \t Gender \t Salary \tDepartment");
		while(res.next()) {
			System.out.println(res.getInt(1)+"\t\t"+res.getString(2)+"\t"+res.getString(3)+"\t"+res.getDouble("Salary")+"\t"+res.getInt("departmentId"));
		//.get---(can enter either column number of the table or column name)
		}
				
		

	}

}
