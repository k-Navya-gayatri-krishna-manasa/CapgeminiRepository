package com.cgg;

import org.apache.log4j.Logger;

public class App {

	public static void main(String[] args) {
		Logger logger=Logger.getLogger("MyLogger");
		logger.debug("Dubug Message");
		logger.info("Info Message");
		logger.warn("Warning Message");
		logger.error("Error Message");
		logger.fatal("Fatal Message");
		
		
	}

}
