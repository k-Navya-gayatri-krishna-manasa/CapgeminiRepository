package com.cgg;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	
	Calculator calc;
	@Before
	public void init() {
		calc=new Calculator();
		System.out.println("Before method executed");
	}
	@After
	public void destroy() {
		System.out.println("Ater Method Execution");
	}
	@BeforeClass
	static public void first() {
		System.out.println("First Method executed");
	}
	@AfterClass
	static public void last()
	{
		System.out.println("Last Method Executed");
	}
	@Test
	public void testAdd() {
		//Calculator calc=new Calculator();
		assertEquals(10,calc.add(5,5));
	}

	@Test
	public void testSubtract() {
		//Calculator calc=new Calculator();
		assertEquals(10,calc.subtract(20,10));
	}
	

}
