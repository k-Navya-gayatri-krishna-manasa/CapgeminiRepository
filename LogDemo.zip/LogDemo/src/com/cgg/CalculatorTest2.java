package com.cgg;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CalculatorTest2 {
	
	static Calculator c;
	@Before
	 public void init() {
		c=new Calculator();
		System.out.println("Before method executed");
	}
	@Test
	public void testMultiply() {
		assertEquals(10,c.multiply(5, 2));
	}

	@Test
	public void testDivide() {
		assertEquals(10,c.divide(100, 10));
	}
	@Test(expected = ArithmeticException.class)
	public void testException() {
		c.multiply(10, 0);
	}

}
