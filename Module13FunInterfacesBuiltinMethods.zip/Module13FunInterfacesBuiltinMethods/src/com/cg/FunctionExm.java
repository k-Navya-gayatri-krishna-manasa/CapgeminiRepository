package com.cg;

import java.util.function.BiFunction;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.function.IntToDoubleFunction;
import java.util.function.UnaryOperator;

public class FunctionExm {

	public static void main(String[] args) {
		Function<String,Integer> f1=(str)->str.length();
		System.out.println(f1.apply("Hello"));
		BiFunction<String,String,String> f2=(s1,s2)->s1+s2;
		String r=f2.apply("Hello", "bava");
		System.out.println(r);
		DoubleFunction<Integer> f3=(num)->(int)num;
		System.out.println(f3.apply(23.78));
		IntToDoubleFunction f4=n->n+10.34;
		System.out.println(f4.applyAsDouble(20));
		UnaryOperator<Integer> u=n->n*n;
		System.out.println(u.apply(20));
	}

}
