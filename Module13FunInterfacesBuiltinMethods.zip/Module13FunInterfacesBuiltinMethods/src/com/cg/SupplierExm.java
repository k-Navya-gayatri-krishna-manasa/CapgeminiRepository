package com.cg;

import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class SupplierExm {

	public static void main(String[] args) {
		int num=10;
		Supplier<String> s=()->"Hello";
		System.out.println(s.get());
		Supplier<Integer> s1=()->10;
		System.out.println(s1.get());
		BooleanSupplier s2=()->num>10;
		System.out.println(s2.getAsBoolean());
		String st="234";
		IntSupplier s3=()->Integer.parseInt(st)	;
		System.out.println(s3.getAsInt());

		
	}

}
