package com.cg;

public interface MyInterface {
	String myFunction(char[] arr);
}
