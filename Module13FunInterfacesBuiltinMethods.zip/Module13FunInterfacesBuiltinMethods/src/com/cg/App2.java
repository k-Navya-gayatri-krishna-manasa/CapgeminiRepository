package com.cg;

import java.util.Arrays;

public class App2 {

	public static void main(String[] args) {
		ComparisionProvider pro=new ComparisionProvider();
		String[] names= {"sai","baby","pavan"};
		int[] nums= {15,20,5,67,7,56};
	/*Arrays.sort(names);
	for(String p:names) {
		System.out.println(p);
	}
	Arrays.sort(names,(n1,n2)->n1.compareTo(n2));//lamda experssion
	for(String p1:names) {
		System.out.println(p1);
	}
	Arrays.sort(names,pro::compareByName);//method reference
	for(String p1:names) {
		System.out.println(p1);
	}
	
*/
		Arrays.sort(names,ComparisionProvider::compareByName);
		for(String p:names) {
			System.out.println(p);
		}
	}

}
