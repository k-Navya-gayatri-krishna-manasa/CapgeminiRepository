package com.cg;
public interface FileIntefaceExm {
	
	int maximum(int n1,int n2);
		
}
