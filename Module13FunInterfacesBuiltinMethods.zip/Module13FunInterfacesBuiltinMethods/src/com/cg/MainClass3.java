package com.cg;

public class MainClass3 {

	public static void main(String[] args) {
		Greet g=()->"Hello";
		display(g);
		
	}
	public static void display(Greet g) {
		System.out.println(g.sayHello());
	}

}
