package com.cg;

public interface MultiplyByTwo {
	int multiply(int n1);

}
