package com.cg;

public class ComparisionProvider {  //its main class is App2
	public static int compareByName(String name1,String name2) {
		return -name1.compareTo(name2);
	}
	public int CompareByAge(int age1,int age2) {
		if(age1<age2) {
			return 1;
		}
		else if(age1<age2) {
			return -1;
		}
		 return 0;
	}

}
