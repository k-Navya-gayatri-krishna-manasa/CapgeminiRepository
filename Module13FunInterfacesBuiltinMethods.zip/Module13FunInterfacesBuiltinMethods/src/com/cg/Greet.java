package com.cg;

public interface Greet {
	String sayHello();

}
