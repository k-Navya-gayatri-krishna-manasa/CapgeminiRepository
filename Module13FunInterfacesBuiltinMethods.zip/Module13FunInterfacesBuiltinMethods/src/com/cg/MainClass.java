package com.cg;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//FileIntefaceExm i=(FileIntefaceExm) new MaxFinderImple();
		//int result=i.maximum(30, 20);
		//System.out.println(result);
		FileIntefaceExm max=(n1,n2)->n1>n2?n1:n2;
		FileIntefaceExm max1=(n1,n2)->{ return n1;};//it dont checks the conditions jst returns n1
		int result=max.maximum(10, 20);
		System.out.println(result);
		
		//or
		
		FileIntefaceExm max2=(n1,n2)->{
			if(n1>n2)
				return n1;
			else 
				return n2;
		};
		
	}

}
