package com.cg;

public class App1 {

	public static void main(String[] args) {
		char[] a= {'B','A','V','A'};
		/*MyInterface m=(arr)->new String(arr);
		String r=m.myFunction(a);
				System.out.println(r);
		*/		
		//Method reference		
				MyInterface m=String::new;
				String r=m.myFunction(a);
				System.out.println(r);
	}

}
