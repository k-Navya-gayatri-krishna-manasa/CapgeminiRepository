package com.cg;

import java.util.function.BiPredicate;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class PredicateExm {

	public static void main(String[] args) {
		Predicate<String> p=name->name.equals("Mani");
		boolean result=p.test("Manu");
		System.out.println(result);
		
		//or
		
		
		System.out.println(p.test("Manu"));
		BiPredicate<String, String> p1=(s1,s2)->s1.equals(s2);
		System.out.println(p1.test("Bava", "Bava"));
		
		IntPredicate p2=n->n>10; //int prediacte always takes integer values so no need to mention type of parameter
		System.out.println(p2.test(80));
		

	}

}
