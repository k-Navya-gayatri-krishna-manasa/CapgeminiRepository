package com.cg;

public class MainClass2 {

	public static void main(String[] args) {
		MultiplyByTwo m=n1->n1*2;
		System.out.println(m.multiply(10));

	}

}
