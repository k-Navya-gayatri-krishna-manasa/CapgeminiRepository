package com.cg;

import java.util.ArrayList;
import java.util.List;

public class MthodRefExm {

	public static void main(String[] args) {
		List<Integer> num=new ArrayList<Integer>();
		num.add(10);
		num.add(20);
		num.add(30);
		num.forEach(e->System.out.println(e));
		num.forEach(System.out::println);//Method refference

	}

}
