package com.cg;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.LongConsumer;
import java.util.function.ObjIntConsumer;

public class ConsumerExm {

	public static void main(String[] args) {
		Consumer<String> c=(str)->System.out.println(str);
		c.accept("Capgemini");
		IntConsumer c1=(n)->System.out.println(n*4);
		c1.accept(10);
		LongConsumer c2=n->System.out.println(n*5);
		c2.accept(20000);
		BiConsumer<String,Integer> b=(name,age)->System.out.println("Hello"+name+"you are"+age);
		b.accept("Anil", 48);
		ObjIntConsumer<String> obj=(name,n)->System.out.println("Hello"+name+"you are"+n);
		obj.accept("bava",28);
		
		
	}

}
