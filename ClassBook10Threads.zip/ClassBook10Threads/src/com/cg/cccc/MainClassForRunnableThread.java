package com.cg.cccc;

import java.io.IOException;

public class MainClassForRunnableThread {

	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Main Starts");
		MyThreadClass r1=new MyThreadClass();
		Thread t1=new Thread(r1, "A");
		Thread t2=new Thread(r1, "B");
		t1.start();
		t2.start();
		t1.join(2);
		t2.join(2);
		System.out.println("Main Ends");
		
				
	}

}
