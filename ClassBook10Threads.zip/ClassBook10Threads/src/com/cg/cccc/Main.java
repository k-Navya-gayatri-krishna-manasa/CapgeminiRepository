package com.cg.cccc;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException,InterruptedException {
		Processor p=new Processor() ;
		Thread t1=new Thread(new Runnable() {
		@Override
		public void run() {
			for(int i=0;i<10;i++) {
				p.increment();
			}
		}
	});
		Thread t2=new Thread(new Runnable() {
		@Override
		public void run() {
			//for(int i=0;i<10;i++) {
				p.testMethod();
			//}
		}

	});
	t1.start();
	t2.start();
	t1.join();
	t2.join();
	System.out.println(p.count);
	
	}
}
