package com.cg.cccc;

import java.util.Scanner;

public class InterProccessComm {
	public void produce() throws InterruptedException{
		System.out.println("Producer started");
		synchronized(this) {
			wait();
			System.out.println("producer resumed");
			System.out.println("producer completed");
		}
	}
	public void consume() throws InterruptedException{
		Thread.sleep(1000);
		Scanner sc=new Scanner(System.in);
		synchronized(this) {
			System.out.println("consumer started");
			System.out.println("waiting for return key");
			sc.nextLine();
			System.out.println("return key pressed");
			//notify(); //it only notifies one thread that released the lock
			
			notifyAll();
			System.out.println("consumer completed");
			
		}
		
		}
}
