package com.cg.cccc;

import java.io.IOException;

public class ThreadsMain {

	public static void main(String[] args) throws IOException {
		System.out.println("Main Styarts:");
		MyThread t1=new MyThread();
		//t1.start();
		t1.setName("A");
		MyThread t2=new MyThread();
		t2.setName("B");
		t2.start();
		t1.start();
		System.out.println("Main Ends");
	}
	 
	public static void doWork() {
		
	}

}
