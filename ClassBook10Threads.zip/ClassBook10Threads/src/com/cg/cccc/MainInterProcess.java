package com.cg.cccc;

public class MainInterProcess {

	public static void main(String[] args) {
		InterProccessComm c=new InterProccessComm();
		Thread t1=new Thread(new Runnable() {
			@Override
			public void run() {
				try {
				
					c.produce();
			
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
			Thread t2=new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					c.consume();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}

		});
			t1.start();
			t2.start();
		
			
	}

}
