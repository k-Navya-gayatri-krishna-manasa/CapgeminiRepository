package com.cg.cccc;

public class Processor {
	 int count;
	public synchronized void increment() {
		System.out.println("count");
		try {
			
			Thread.sleep(1000);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		count++;
	}
	public synchronized void testMethod()  {
		for(int i=0;i<10;i++) {
			try {	
			Thread.sleep(1000);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}
	

}
