import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {
  model:any={};  //model is the obj that accepts the data of employee id,name,salary

  updateEmployee():any{
    console.log(this.model);
    this.employeeService.updateEmployee(this.model).subscribe();
  }
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
  }

}
