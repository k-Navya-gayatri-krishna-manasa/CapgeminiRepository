import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
//import { Employee } from '../employee.interface';

@Component({
  selector: 'app-searchemployee',
  templateUrl: './searchemployee.component.html',
  styleUrls: ['./searchemployee.component.css']
})
export class SearchemployeeComponent implements OnInit {
  
  constructor(private employeeService:EmployeeService) { }
  emp:any; 
  //emp:any={}
  eid:number;

  ngOnInit() {
    this.eid = 0;
  }

  getById() {
    console.log(this.eid);
    this.employeeService.getEmployeeById(this.eid)
      .subscribe((emps:any)=> this.emp = emps);
  }
 
  onSubmit() {
    this.getById();
  }
}


