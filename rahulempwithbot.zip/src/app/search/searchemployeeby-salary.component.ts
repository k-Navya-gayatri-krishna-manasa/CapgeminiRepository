import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-searchemployeeby-salary',
  templateUrl: './searchemployeeby-salary.component.html',
  styleUrls: ['./searchemployeeby-salary.component.css']
})
export class SearchemployeebySalaryComponent implements OnInit {

  constructor(private employeeService:EmployeeService) { }
  emp:any; 
  //emp:any={}
  esal:number;

  ngOnInit() {
    this.esal = 0.0;
  }

  getBySalary() {
    console.log(this.esal);
    this.employeeService.getEmployeeBySalary(this.esal)
      .subscribe((emps:any)=> this.emp = emps);
  }

  onSubmit() {
    this.getBySalary();
  }
}
