import { Injectable } from '@angular/core';

import {HttpClient} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 

  constructor(private http:HttpClient) {

   }
   getAllEmployee(){
    // return this.http.get("http://3.18.111.145:9908/emplist/getalldata")
    return this.http.get("http://18.224.215.217:9908/emplist/getalldata")
   }
   addEmployee(data:any){

     //bcze in spring boot we are using @ModelAttribute to add data usin postman
      let input=new FormData(); 
      input.append("empId",data.id); 
      input.append("empName",data.name);//the names data.id,name,salary are same as addcomponent.html
      input.append("empSalary",data.salary) //the empId,empName,empSalary names should be equal tomnames of DTO layer

    //if we use @RequestBody in spring boot controller that is JSON format
      //let input={"empId":data.id,"empName":data.name,"empSalary":data.salary}

    //return this.http.post("http://3.18.111.145:9908/emplist/adddata",input);
    return this.http.post("http://18.224.215.217:9908/emplist/adddata",input);
   }

   updateEmployee(data:any){
    let input1={"empId":data.id,"empName":data.name,"empSalary":data.salary};
     return this.http.put("http://3.18.111.145:9908/emplist/updatedata",input1);
   }

   baseurl='http://localhost:9908/emplist/delete';
   deleteEmployee(id:number) { 
     console.log("service"+id)
    return this.http.delete(`${this.baseurl}/${id}` ,{responseType:'text'}); 
   }
   baseurl1='http://3.18.111.145:9908/emplist/getbyId';
   getEmployeeById(id:number){
     console.log("service"+id);
    return this.http.get(`${this.baseurl1}/${id}`); 
   }

   baseurl2='http://3.18.111.145:9908/emplist/getbyName';
   getEmployeeByName(name:String){
     console.log("service"+name);
    return this.http.get(`${this.baseurl2}/${name}`); 
   }
  
   baseurl3='http://3.18.111.145:9908/emplist/getbySalary';
   getEmployeeBySalary(sal:number){
     console.log("service"+sal);
    return this.http.get(`${this.baseurl3}/${sal}`); 
   }
}