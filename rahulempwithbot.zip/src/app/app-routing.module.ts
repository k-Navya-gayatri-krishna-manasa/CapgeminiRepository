import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ShowComponent } from './app.showcomponent';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';
import { DeleteemployeeComponent } from './deleteemployee/deleteemployee.component';
import { SearchemployeeComponent } from './search/searchemployee.component';
import { SearchemployeebyNameComponent } from './search/searchemployeeby-name/searchemployeeby-name.component';
import { SearchemployeebySalaryComponent } from './search/searchemployeeby-salary.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path:"empshow",component:ShowComponent},
  {path:"addemp",component:AddemployeeComponent},
  {path:"updateemp",component:UpdateemployeeComponent},
  {path:"delemp",component:DeleteemployeeComponent},
  {path:"search",component:SearchComponent},

  {path:"searchemp",component:SearchemployeeComponent},
  {path:"searchempName",component:SearchemployeebyNameComponent},
  {path:"searchempSal",component:SearchemployeebySalaryComponent},
  {path:"",redirectTo:"/empshow",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
