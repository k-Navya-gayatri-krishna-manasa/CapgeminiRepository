export class Employee{
    id:number;
    name:String;
    salary:number;
}