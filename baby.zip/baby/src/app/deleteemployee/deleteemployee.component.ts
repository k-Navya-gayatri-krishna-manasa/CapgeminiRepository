import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-deleteemployee',
  templateUrl:'./deleteemployee.component.html',
  styleUrls: ['./deleteemployee.component.css']
})
export class DeleteemployeeComponent implements OnInit {
  //model:any={};
 /*  employees:Employee[]; */
 // delEmployee():any{
  //  console.log(this.model);
   // this.employeeService.deleteEmployee(this.model).subscribe();
  /*   this.employeeService.deleteEmp(this.employees)
      .subscribe( data => {
        this.employees = this.employees.filter(u => u !== employee);
      }) */
 // }
 /* ngOnInit(){
  this.employeeService.getAllEmployee().subscribe((data:any)=>this.employees=data);
}
  deleteEmployee(employe: Employee): void {
    this.employeeService.deleteEmployee(employe)
      .subscribe( data => {
        this.employees = this.employees.filter(u => u !== employee);
      })
  };
  constructor(private employeeService:EmployeeService) { } */

  model:any={};
  
  constructor(private employeeService:EmployeeService) { }
  empdata:any[]=[]; 
  //empdata1:any[]=[]; 

  ngOnInit() {
    this.reloadData();
  }
    reloadData(){
    this.employeeService.getAllEmployee().subscribe((data:any)=>this.empdata=data);

  }

  deletebutton(id: number) {
    //console.log(id);
    this.employeeService.deleteEmployee(id)
      .subscribe(data => {console.log(data);
        this.reloadData();
        })
        }
        deletebutton1(model: number) {
          //console.log(id);
          this.employeeService.deleteEmployee(model)
            .subscribe(data => {console.log(data);
              this.reloadData();
              })
              }
        
  

}
