﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { ShowComponent } from './app.showcomponent';
import { HttpClientModule } from '@angular/common/http';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import {FormsModule} from '@angular/forms';;
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component'
import { AppRoutingModule } from './app-routing.module';;
import { DeleteemployeeComponent } from './deleteemployee/deleteemployee.component';
import { SearchemployeeComponent } from './search/searchemployee.component';;
import { SearchemployeebyNameComponent } from './search/searchemployeeby-name/searchemployeeby-name.component'
;
import { SearchemployeebySalaryComponent } from './search/searchemployeeby-salary.component'
;
import { SearchComponent } from './search/search.component'

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        AppRoutingModule
       
    ],
    declarations: [
        AppComponent,
        ShowComponent,
        AddemployeeComponent,
        UpdateemployeeComponent	,
        DeleteemployeeComponent,
        SearchemployeeComponent,
        SearchemployeebyNameComponent,
        SearchemployeebySalaryComponent ,
        SearchComponent   ],
       
        
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }