import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../employee.service';

@Component({
  selector: 'app-searchemployeeby-name',
  templateUrl:'./searchemployeeby-name.component.html',
  styleUrls: ['./searchemployeeby-name.component.css']
})
export class SearchemployeebyNameComponent implements OnInit {
  constructor(private employeeService:EmployeeService) { }
  emp:any; 
  ename:String;

  ngOnInit() {
    this.ename ="xxx";
  }

  getByName() {
    console.log(this.ename);
    this.employeeService.getEmployeeByName(this.ename)
      .subscribe((emps:any)=> this.emp = emps);
  }

  onSubmit() {
    this.getByName();
  }

}
