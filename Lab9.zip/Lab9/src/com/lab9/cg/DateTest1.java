package com.lab9.cg;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest1 {

	@Test
	public void testSetDay() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDay() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetMonth() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMonth() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetYear() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetYear() {
		fail("Not yet implemented");
	}

}
