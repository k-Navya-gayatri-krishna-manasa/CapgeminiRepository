package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> emp=employeeService.showAllEmployee();
		if(emp.isEmpty()) {
			return new ResponseEntity("No employee Found",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
	}
	
	@PostMapping("/addEmp")
	public ResponseEntity addEmployee(@RequestBody Employee emp) {
		Employee employee= employeeService.addEmployees(emp);
		if(employee==null) {
			return new ResponseEntity("Data not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@DeleteMapping("/delEmp")
	public void deleteEmployee(@RequestParam("eid") Integer id) {
		employeeService.deleteEmployee(id);
	}
	
	
	@PutMapping("/updateEmp")
	public Employee updateEmployee(@RequestBody Employee emp) {
		return employeeService.updateEmployee(emp);
	}
	
	@GetMapping("/getbyId")
	public ResponseEntity searchId(@RequestParam("eid") Integer id){
		Employee employee=employeeService.searchEmployeeById(id);
		if(employee==null) {
			return new ResponseEntity("No employee Found with given Id", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	
	@GetMapping("/getbyName")
	public ResponseEntity<List<Employee>> searchName(@RequestParam("ename") String name){
		List<Employee> emp=employeeService.searchEmployeeByName(name);
		if(emp.isEmpty()) {
			return new ResponseEntity("No employee Found with that name",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
	}
	
	@GetMapping("/getbySalary")
	public  ResponseEntity<List<Employee>> searchSalary(@RequestParam("esal")Double salary){
		List<Employee> emp=employeeService.searchEmployeeBySalary(salary);
		if(emp.isEmpty()) {
			return new ResponseEntity("No employee Found with that salary",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
	}
	
	@GetMapping("/byId")
	public  ResponseEntity<List<Employee>> searchSalary1(@RequestParam("eid")Integer id){
		Employee emp=employeeService.searchEmployee(id);
		if(emp==null) {
			return new ResponseEntity("Id !5000",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity(emp,HttpStatus.OK);
	}
	
	
}
