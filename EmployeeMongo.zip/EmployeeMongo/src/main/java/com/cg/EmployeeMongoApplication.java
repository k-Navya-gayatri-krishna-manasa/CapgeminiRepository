package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")

public class EmployeeMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMongoApplication.class, args);
		System.out.println("Welcome to springboot with mongodb...");
	}

}
