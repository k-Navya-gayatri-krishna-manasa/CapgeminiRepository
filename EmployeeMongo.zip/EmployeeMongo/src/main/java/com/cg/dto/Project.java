package com.cg.dto;

public class Project {
	private Integer projId;
	private String projName;
}
