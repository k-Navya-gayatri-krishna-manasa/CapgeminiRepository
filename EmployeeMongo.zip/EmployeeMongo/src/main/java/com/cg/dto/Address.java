package com.cg.dto;

public class Address {
	private String city;
	private String state;
	private Integer pincode;
	
}
