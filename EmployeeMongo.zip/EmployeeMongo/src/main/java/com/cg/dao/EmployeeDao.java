package com.cg.dao;

import java.util.List;

import com.cg.dto.Employee;

public interface EmployeeDao {
	 public List<Employee> showAllEmployee();
	 public Employee addEmployees(Employee emp);
	 public Employee searchEmployeeById(int empId);
	 public Employee updateEmployee(Employee emp);
	 public void deleteEmployee(int empId);
	 public List<Employee> searchEmployeeByName(String empName);
	 public List<Employee> searchEmployeeBySalary(Double empSalary);
	 public Employee searchEmployee(Integer empId);
}
