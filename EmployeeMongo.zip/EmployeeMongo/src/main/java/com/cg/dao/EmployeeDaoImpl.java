package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.dto.Employee;
import com.mongodb.Mongo;
import com.mongodb.WriteResult;
import com.mongodb.client.result.DeleteResult;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	 private static final String COLLECTION = "Employee";
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public List<Employee> showAllEmployee() {
		return mongoTemplate.findAll(Employee.class);
	}

	@Override
	public Employee addEmployees(Employee emp) {
		return mongoTemplate.insert(emp);
	}

	@Override
	public Employee searchEmployeeById(int empid) {
		//Employee e=mongoTemplate.findById(empid,  Employee.class);
		
		//or
		
		Query query=Query.query(Criteria.where("empId").is(empid));
		Employee e=mongoTemplate.findOne(query,Employee.class);
		return e;
		
	}
	@Override
	public List<Employee> searchEmployeeByName(String empName) {
		List<Employee> employee=mongoTemplate.findAll(Employee.class);
		List<Employee> employees=new ArrayList<>();
		for(Employee empList:employee) {
			if(empList.getEmpName().equals(empName)) {
				employees.add(empList);	
			}
		}
		return employees;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		System.out.println("in dao"+emp);
		mongoTemplate.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(int empId) {
		System.out.println("dao"+empId);
		Employee e=mongoTemplate.findById(empId,  Employee.class);
		if(e!=null) {
			mongoTemplate.remove(e);
		}
	}

	@Override
	public List<Employee> searchEmployeeBySalary(Double empSalary) {
		List<Employee> employee=mongoTemplate.findAll(Employee.class);
		List<Employee> employees=new ArrayList<>();
		for(Employee empList:employee) {
			if(empList.getEmpSalary().equals(empSalary)) {
				employees.add(empList);	
			}
		}
		return employees;
		
		
	}
	public Employee searchEmployee(Integer  empId) {
		Query query=Query.query(Criteria.where("empSalary").gte(5000));
		Employee e=mongoTemplate.findOne(query,Employee.class);
		System.out.println(e);
		//List<Employee> emp=mongoTemplate.find(query,Employee.class,"employee_mongo");
		return e;
	}
	
//	public List<Employee> searchEmploye(Integer  empId) {
//		Query query=Query.query(Criteria.where("empSalary").gte(5000));
//		
//		List<Employee> emp=mongoTemplate.find(query,Employee.class,"employee_mongo");
//		return emp;
//	}
//	
	

	}


