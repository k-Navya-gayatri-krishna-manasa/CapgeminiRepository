package com.cg.service;

import java.util.List;

import com.cg.dto.Employee;

public interface EmployeeService {
	 public List<Employee> showAllEmployee();
	 public Employee addEmployees(Employee emp);
	 public Employee searchEmployeeById(int empId);
	 public Employee updateEmployee(Employee emp);
	 public void deleteEmployee(int empId);
	 public Employee searchEmployee(Integer  empId);
	public List<Employee> searchEmployeeByName(String empName);
	public List<Employee> searchEmployeeBySalary(Double empSalary);
}
