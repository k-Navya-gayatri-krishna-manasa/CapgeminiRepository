package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeDao;
import com.cg.dto.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeedao;
	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeedao.showAllEmployee();
	}

	@Override
	public Employee addEmployees(Employee emp) {
		// TODO Auto-generated method stub
		return employeedao.addEmployees(emp);
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return employeedao.searchEmployeeById(empId);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeedao.updateEmployee(emp);
	}

	@Override
	public void deleteEmployee(int empId) {
		employeedao.deleteEmployee(empId);
		
	}

	@Override
	public List<Employee> searchEmployeeByName(String empName) {
		return employeedao.searchEmployeeByName(empName);
	}

	@Override
	public List<Employee> searchEmployeeBySalary(Double empSalary) {
		return employeedao.searchEmployeeBySalary(empSalary);
	}

	@Override
	public Employee searchEmployee(Integer  empId) {
		return employeedao.searchEmployee(empId);
	}
	
}
