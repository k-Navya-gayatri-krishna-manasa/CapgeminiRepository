package com.cg.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.bean.Product;

public interface IProductService {

	List<Product> createProduct(Product product);

	List<Product> getAllProducts();

	Product updateProduct(Product product);

	void delProduct(Integer productId);
	
}