package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	private IProductService service;

	@RequestMapping(value = "/createProduct", method = RequestMethod.POST)
	public List<Product> createProduct(@RequestBody Product product) {
		return  service.createProduct(product);
	}
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET)
	public List<Product> getAllProducts() {
		return  service.getAllProducts();
	}
	
	@RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
	public Product updateProduct(@RequestBody Product product) {
		return  service.updateProduct(product);
	}
	
	@RequestMapping(value = "/delProducts/{pid}", method = RequestMethod.DELETE)
	public String delProduct(@PathVariable("pid") Integer productId) {
		service.delProduct(productId);
		return  productId+" is deleted";
	}
}