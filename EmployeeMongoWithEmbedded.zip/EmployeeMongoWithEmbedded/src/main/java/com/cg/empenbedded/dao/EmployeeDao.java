package com.cg.empenbedded.dao;

import java.util.List;

import com.cg.empenbedded.dto.Employee;

public interface EmployeeDao {
	public List<Employee> showAllEmployee();
	 public Employee addEmployee(Employee emp);
	 public Employee searchEmployeeById(int empid);
	 public Employee updateEmployee(Employee emp);
	 public void deleteEmployee(int empId);
}
