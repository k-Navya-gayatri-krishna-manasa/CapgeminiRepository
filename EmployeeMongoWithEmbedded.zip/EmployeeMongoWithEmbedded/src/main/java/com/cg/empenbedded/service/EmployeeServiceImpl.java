package com.cg.empenbedded.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empenbedded.dao.EmployeeDao;
import com.cg.empenbedded.dto.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;
	
	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDao.showAllEmployee();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeDao.addEmployee(emp);
	}

	@Override
	public Employee searchEmployeeById(int empid) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeById(empid);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(emp);
	}

	@Override
	public void deleteEmployee(int empId) {
		employeeDao.deleteEmployee(empId);
		
	}

}
