package com.cg.empenbedded.service;

import java.util.List;

import com.cg.empenbedded.dto.Employee;

public interface EmployeeService {
	public List<Employee> showAllEmployee();
	 public Employee addEmployee(Employee emp);
	 public Employee searchEmployeeById(int empid);
	 public Employee updateEmployee(Employee emp);
	 public void deleteEmployee(int empId);
}
