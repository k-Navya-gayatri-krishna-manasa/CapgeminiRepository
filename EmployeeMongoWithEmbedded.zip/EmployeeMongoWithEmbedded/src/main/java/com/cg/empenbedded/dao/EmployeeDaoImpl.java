package com.cg.empenbedded.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.empenbedded.dto.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	MongoTemplate mongoTemplate;
	
	private static final String COLLECTION = "Employee";

	@Override
	public List<Employee> showAllEmployee() {
	
		return mongoTemplate.findAll(Employee.class);
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return mongoTemplate.save(emp);
	}

	@Override
	public Employee searchEmployeeById(int empid) {
		Query query=Query.query(Criteria.where("empId").is(empid));
		Employee e=mongoTemplate.findOne(query,Employee.class);
		return e;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		System.out.println("in dao"+emp);
		mongoTemplate.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(int empId) {
		System.out.println("dao"+empId);
		Employee e=mongoTemplate.findById(empId,  Employee.class);
		if(e!=null) {
			mongoTemplate.remove(e);
		}
		
	}
	

}
