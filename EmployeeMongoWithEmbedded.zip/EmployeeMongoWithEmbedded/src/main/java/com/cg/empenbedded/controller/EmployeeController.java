package com.cg.empenbedded.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.empenbedded.dto.Employee;
import com.cg.empenbedded.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> emp=employeeService.showAllEmployee();
		if(emp.isEmpty()) {
			return new ResponseEntity("No employee Found",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
	}
	
	@PostMapping("/addEmp")
	public ResponseEntity addEmployee(@RequestBody Employee emp) {
		Employee employee= employeeService.addEmployee(emp);
		if(employee==null) {
			return new ResponseEntity("Data not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@DeleteMapping("/delEmp")
	public void deleteEmployee(@RequestParam("eid") Integer id) {
		employeeService.deleteEmployee(id);
	}
	
	
	@PutMapping("/updateEmp")
	public Employee updateEmployee(@RequestBody Employee emp) {
		return employeeService.updateEmployee(emp);
	}
	
	@GetMapping("/getbyId")
	public ResponseEntity searchId(@RequestParam("eid") Integer id){
		Employee employee=employeeService.searchEmployeeById(id);
		if(employee==null) {
			return new ResponseEntity("No employee Found with given Id", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	

}
