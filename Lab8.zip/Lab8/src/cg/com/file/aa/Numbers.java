package cg.com.file.aa;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Numbers {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc=new Scanner(new File("C:\\Users\\knavyaga\\Documents\\numbers.txt"));
		sc.useDelimiter(",");
		
		int c;
		while(sc.hasNextInt()) {
			c=sc.nextInt();
			if(c%2==0) {
				System.out.println(c);
			}
		}
		
		
	}

}
