package cg.com.file.aa;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class ReverseFile {

	public static void main(String[] args) throws IOException {
		FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\Lab8.txt");
		int c;
		
		 StringBuilder sb = new StringBuilder();
		 while((c=fr.read())!=-1) {
			 sb.append((char)c);
		 }
		sb.reverse();
		fr.close();
		FileWriter out=new FileWriter("C:\\Users\\knavyaga\\Documents\\Lab9.txt");
		out.write(sb.toString());
		out.close();
		System.out.println("Done");
		
		
	}

}
