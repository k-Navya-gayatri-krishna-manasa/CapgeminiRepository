package com.cg.tv.dao;

import com.cg.tv.dto.Account;
import com.cg.tv.dto.exception.DigitalTVException;

public interface DigitalTVDao {
	Account showBalance(String id) throws DigitalTVException;
	Account reacharge(String id,double amt) throws DigitalTVException;

}
