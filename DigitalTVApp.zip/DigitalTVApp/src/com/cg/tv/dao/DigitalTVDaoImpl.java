package com.cg.tv.dao;

import java.util.Map;

import com.cg.tv.Staticdb.AccountDb;
import com.cg.tv.dto.Account;
import com.cg.tv.dto.exception.DigitalTVException;

public class DigitalTVDaoImpl implements DigitalTVDao{
	private Map<String,Account> accDb;
	public DigitalTVDaoImpl() {
		accDb=AccountDb.getAccounts();
	}
	@Override
	public Account showBalance(String id) throws DigitalTVException {
		
		if(accDb.containsKey(id)) { //to check whether entered id customer is present or not
			return accDb.get(id);
		}
		else {
			throw new DigitalTVException("The customer Id"+id+"does not exist");
		}
		
	}
	@Override
	public Account reacharge(String id, double amt) throws DigitalTVException {
		if(accDb.containsKey(id)) { //to check whether entered id customer is present or not
			Account acc=accDb.get(id);
			acc.setAccountBalance(acc.getAccountBalance()+amt);
			accDb.put(id, acc);//adding updated balance details to AccountDb 
			return accDb.get(id);//getting the id details with updated balance
		}
		else {
			throw new DigitalTVException("The customer Id"+id+"does not exist");
		}
		
	}

}
