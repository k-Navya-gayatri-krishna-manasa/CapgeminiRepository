package com.cg.tv.ui;

import java.util.Scanner;

import com.cg.tv.dto.Account;
import com.cg.tv.dto.exception.DigitalTVException;
import com.cg.tv.service.DigitalTVService;
import com.cg.tv.service.DigitalTVServiceImpl;

public class Client {
	static Scanner sc=new Scanner(System.in);
	static DigitalTVService tvService=new DigitalTVServiceImpl() ;
	
	public static void main(String[] args) {
		int response;
		while(true) {
			System.out.println("1.Check Balance");
			System.out.println("2.Recharge");
			System.out.println("3.Exit");
			System.out.println("Please enter your choice");
			response=sc.nextInt();
			sc.nextLine();
			switch(response) {
			case 1:
				checkBalance();
				break;
			case 2:rechargeBalance();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice, please select between 1-3");
				break;
			}
		}
		

	}
	private static void checkBalance() {
		System.out.println("Enter customer Id");
		String custId=sc.nextLine();
		
		try {
			Account acc=tvService.showBalance(custId);
			System.out.println("Hello  "+acc.getCustomerName()+"  Your balance is:  "+acc.getAccountBalance());
		}catch(DigitalTVException e){
			System.err.println(e.getMessage());
		}
	}
	private static void rechargeBalance() {
		System.out.println("Enter customer Id:");
		String custId=sc.nextLine();
		System.out.println("Recharge amount:");
		double amt=sc.nextDouble();
		sc.nextLine();
		
		try {
			Account acc=tvService.reacharge(custId, amt);
			System.out.println("Hello  "+acc.getCustomerName()+"  Your updated balance is:  "+acc.getAccountBalance());
		}catch(DigitalTVException e){
			System.err.println(e.getMessage());
		}
	}

}
