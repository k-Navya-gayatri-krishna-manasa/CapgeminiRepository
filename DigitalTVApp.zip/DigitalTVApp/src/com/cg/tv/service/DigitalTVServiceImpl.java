package com.cg.tv.service;

import com.cg.tv.dao.DigitalTVDao;
import com.cg.tv.dao.DigitalTVDaoImpl;
import com.cg.tv.dto.Account;
import com.cg.tv.dto.exception.DigitalTVException;

public class DigitalTVServiceImpl implements  DigitalTVService {
	DigitalTVDao tvDao;

	public DigitalTVServiceImpl() {
		tvDao=new DigitalTVDaoImpl();
	}
	@Override
	public Account showBalance(String id) throws DigitalTVException {
				return tvDao.showBalance(id);
	}
	@Override
	public Account reacharge(String id, double amt) throws DigitalTVException {
	
		return tvDao.reacharge(id, amt);
	}
	
}
