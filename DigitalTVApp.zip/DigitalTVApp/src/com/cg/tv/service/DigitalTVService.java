package com.cg.tv.service;

import com.cg.tv.dao.DigitalTVDao;
import com.cg.tv.dto.Account;
import com.cg.tv.dto.exception.DigitalTVException;

public interface DigitalTVService {
		
	Account showBalance(String id) throws DigitalTVException;
	Account reacharge(String id,double amt) throws DigitalTVException;

}
