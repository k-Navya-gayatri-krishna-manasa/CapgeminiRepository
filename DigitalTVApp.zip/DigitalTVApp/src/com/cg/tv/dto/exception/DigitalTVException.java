package com.cg.tv.dto.exception;

public class DigitalTVException extends Exception {
	public DigitalTVException() {
		super();
	}
	public DigitalTVException(String msg) {
		super(msg);
	}
}
