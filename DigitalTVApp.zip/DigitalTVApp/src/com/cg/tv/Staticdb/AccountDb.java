package com.cg.tv.Staticdb;

import java.util.HashMap;
import java.util.Map;

import com.cg.tv.dto.Account;

public class AccountDb {
	private static Map<String,Account> accounts=new HashMap<String,Account>();
	static {
		accounts.put("100001",new Account("100001","Prepaid","Tabbu",500));
		accounts.put("100002",new Account("100002","Prepaid","Sai",300));
		accounts.put("100003",new Account("100003","Postpaid","Pavan",900));
		accounts.put("100004",new Account("100004","Prepaid","Krish",500));
		accounts.put("100005",new Account("100005","Postpaid","Babe",800));
		
	}
	public static Map<String, Account> getAccounts() {
		return accounts;
	}
	

}
