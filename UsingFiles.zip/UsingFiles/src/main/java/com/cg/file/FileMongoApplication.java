package com.cg.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileMongoApplication.class, args);
	}

}
