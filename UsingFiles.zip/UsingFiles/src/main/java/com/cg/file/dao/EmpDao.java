package com.cg.file.dao;

public interface EmpDao {

}
