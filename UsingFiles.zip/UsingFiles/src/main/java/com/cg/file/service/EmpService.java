package com.cg.file.service;

import java.util.List;

import com.cg.file.dto.Emp;

public interface EmpService {
	 public List<Emp> showAllEmployee();
}
