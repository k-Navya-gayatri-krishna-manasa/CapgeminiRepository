package com.cg.file.service;

import java.util.List;

import com.cg.file.dto.Emp;

public class EmpServiceImpl implements EmpService {

	@Override
	public List<Emp> showAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
