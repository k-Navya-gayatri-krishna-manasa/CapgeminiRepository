import {Component} from "@angular/core";
@Component({
    selector:"app-test",
    templateUrl:'./test.Component.html',
   // styles:['h1{color: #369;font-size:large;font-weight:bold;font-style:italic}']
   styleUrls:['./test.Component.css']
})

export class TestComponent{
    company:string="Capgemini"; 
    /* class binding:two or more classes are added to single variable and binded in .html file */
    classesToApply:string="boldClass italicClass";

    applyBoldClass:boolean=true;

    applyItalicClass:boolean=true;

    applyClasses(){
        let classes={
            boldClass:this.applyBoldClass,
            italicClass:this.applyItalicClass
        }
        return classes;
    }


    /* Style bonding */
    isBold:boolean=true;
    fontSize:number=25;
    isItalic:boolean=true;
    applyStyles(){
        let styles={
            "font-weight":this.isBold?"bold":"normal",
            "font-style":this.isItalic?"italic":"normal",
            "font-size.px":this.fontSize
        }
        return styles;
    }
}