import { StyleCompiler } from '../../../node_modules/@angular/compiler';

export interface IEmployee{
    code:string;
    name:string;
    gender:string;
    annualSalary:number;
    dateOfBirth:string;
}