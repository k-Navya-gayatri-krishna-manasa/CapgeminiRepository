import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  firstName:string="Mark";
  lastName:string="Hasi";
  gender:string="Male";
  age:number=23;
  cspan:number=2;
  showDetails:boolean=false;

  toggleDetails(){
    this.showDetails=!this.showDetails;
  }
  constructor() { }

  ngOnInit() {
  }

}
