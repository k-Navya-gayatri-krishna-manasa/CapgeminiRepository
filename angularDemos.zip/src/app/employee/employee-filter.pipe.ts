import { Pipe, PipeTransform } from '@angular/core';
import { IEmployee } from './employee.interface';

@Pipe({
  name: 'employeeFilter'
})
export class EmployeeFilterPipe implements PipeTransform {
 /* transform is abstract method of class PipeTransform */
  transform(employees: IEmployee[], serachTerm:string): any {
    /* Here IEmployeee is the interface we created manually employee.interface.ts */
    if(!employees || !serachTerm){
      return employees;
    }
    return employees.filter(e=>e.name.toLowerCase().startsWith(serachTerm.toLowerCase()));
  }

}
