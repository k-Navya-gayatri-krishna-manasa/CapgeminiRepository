import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-count', /* we add this tag in employeelist.html */
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  selectedRadioButtonValue:string="all" /* to get the value of this all variable from count.html */
  /* this is done so that in console by default all radio button is selected  */
  @Output()
  /* we need to import EventEmitter at the top  */
  countRadioButtonValueChange:EventEmitter<string>=new EventEmitter<string>();
  @Input()  /* to accesss the methods in parent/container classs->employeelist.component.ts */
  all:number=10;
  @Input()
  male:number=5;
  @Input()
  female:number=3;
  constructor() { }

  ngOnInit() {
  }

  raiseCountRadioButtonValueChange() /* to rasie the events userdefined method */{
    this.countRadioButtonValueChange.emit(this.selectedRadioButtonValue); /* to trigger the events emit()is used */
  }
}
