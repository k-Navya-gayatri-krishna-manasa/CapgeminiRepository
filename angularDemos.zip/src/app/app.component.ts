import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App';
/*   imagePath:string='./assets/desert.jfif';
 */


 /* Interpolation */
/*  isDisabled:boolean=true;
 */
/* Property binding */
 //isDisabled:boolean=false;
 /* OnClick(){
   console.log("Button clicked")
 }

caption:string="Employee Details"

name:string="Baby";
 */
}
