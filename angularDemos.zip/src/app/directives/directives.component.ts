import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
 day:number=1;  /* for ngSwitch */
 content:string="Manasa kakumanu"
  constructor() { }

  ngOnInit() {
  }

}
