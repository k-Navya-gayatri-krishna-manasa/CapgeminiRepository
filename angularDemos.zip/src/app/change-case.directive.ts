import { Directive, ElementRef,Renderer, HostListener} from '@angular/core';

@Directive({
  selector: '[appChangeCase]'
})
export class ChangeCaseDirective {
  /* this method:when control comes out of box in output screen the data turns to capital letters */
  @HostListener('blur')
  onBlur(){
    let changedValue:string=this.el.nativeElement.value.toUpperCase();
    this.renderer.setElementProperty(this.el.nativeElement,"value",changedValue)
  }
  constructor(private el:ElementRef,private renderer:Renderer) { 

  }

}
