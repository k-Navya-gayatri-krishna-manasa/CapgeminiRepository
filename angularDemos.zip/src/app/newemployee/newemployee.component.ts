import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router'
import { IEmployee } from './newemployee.interface';
import { NewemployeelistService } from './newemployeelist.service';

@Component({
  selector: 'app-newemployee',
  templateUrl: './newemployee.component.html',
  styleUrls: ['./newemployee.component.css']
})
export class NewemployeeComponent implements OnInit {
  employee:IEmployee;
  constructor(private employeeService:NewemployeelistService,
private activatedRoute:ActivatedRoute,private router:Router) { }
  ngOnInit() {
    let empId=this.activatedRoute.snapshot.params['id']
    console.log(empId);
    this.employee=this.employeeService.getEmployeeById(empId);
  }
  onClick(){
    this.router.navigate(['/employees'])
  }

}
