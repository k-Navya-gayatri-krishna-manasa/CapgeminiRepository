import { Component, OnInit } from '@angular/core';
import { IEmployee } from './newemployee.interface';
import { NewemployeelistService } from './newemployeelist.service';

@Component({
  selector: 'app-newemployeelist',
  templateUrl: './newemployeelist.component.html',
  styleUrls: ['./newemployeelist.component.css']
})
export class NewemployeelistComponent implements OnInit {
  employees:IEmployee[];
  constructor(private employeeservice:NewemployeelistService) { }

  ngOnInit() {
    this.employees=this.employeeservice.getEmployees();
  }

}
