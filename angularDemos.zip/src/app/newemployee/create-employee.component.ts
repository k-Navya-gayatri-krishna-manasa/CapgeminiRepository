import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../employee/employee.interface';
import { NewemployeelistService } from './newemployeelist.service';
import {Router} from "@angular/router"

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  constructor(private employeeservice:NewemployeelistService,
    private router:Router) { }

  ngOnInit() {
  }
onSubmit(form:IEmployee){
  this.employeeservice.addEmployee(form);
  this.router.navigate(['/employees']);//after adding the employee then it will direct add in list and rediredt to employeelist tab

}
}
