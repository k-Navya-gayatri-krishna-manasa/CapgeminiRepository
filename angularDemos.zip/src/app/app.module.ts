import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemoComponent } from './Demo.component';
import { TestComponent } from './test.component';
import { EmployeeComponent } from './employee/employee.component';
import { TwoWayComponent } from './two-way/two-way.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { EmployeeTitlePipe } from './employee/employee-title.pipe';
import { EmployeeFilterPipe } from './employee/employee-filter.pipe';
import { DirectivesComponent } from './directives/directives.component';
import { RedWhiteDirective } from './red-white.directive';
import { ChangeCaseDirective } from './change-case.directive';
import { TemplateFormComponent } from './forms/template-form/template-form.component';
import { ModelFormComponent } from './forms/model-form.component';
import { EmployeeService } from './employee/employee.service';
import { EmployeeCountComponent } from './employee/employee-count.component';
import { NewemployeelistComponent } from './newemployee/newemployeelist.component';
import { PageNotFoundComponent } from './newemployee/page-not-found.component';
import { CreateEmployeeComponent } from './newemployee/create-employee.component';
import { NewemployeeComponent } from './newemployee/newemployee.component';


@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    TestComponent,
    EmployeeComponent,
    TwoWayComponent,
    EmployeeListComponent,
    EmployeeTitlePipe,
    EmployeeFilterPipe,
    DirectivesComponent,
    RedWhiteDirective,
    ChangeCaseDirective,
   TemplateFormComponent,
   ModelFormComponent,
   EmployeeCountComponent,
   NewemployeelistComponent,
   PageNotFoundComponent,
   CreateEmployeeComponent,
   NewemployeeComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[EmployeeService],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
