import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewemployeelistComponent } from './newemployee/newemployeelist.component';
import { CreateEmployeeComponent } from './newemployee/create-employee.component';
import { PageNotFoundComponent } from './newemployee/page-not-found.component';
import { NewemployeeComponent } from './newemployee/newemployee.component';

const routes: Routes = [
  {path:'employees',component:NewemployeelistComponent},
  {path:'create',component:CreateEmployeeComponent},
  {path:'employees/:id',component:NewemployeeComponent},
  {path:'',redirectTo:'/employees',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
