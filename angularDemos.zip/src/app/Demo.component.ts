import {Component} from "@angular/core";
@Component({
    selector:"app-demo",
    template:`<h1>Hello World</h1>`
})
export class DemoComponent{
}
