package lab2.com.cg;
class WithMobNo {
	private String firstname,lastname;
	private char gender;
	private long mobile;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public WithMobNo(String firstname, String lastname, char gender, long mobile) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.mobile = mobile;
	}
	public WithMobNo() {
		super();
	}
	public void display(WithMobNo mob) {
		System.out.println("Person Details");
		System.out.println("-----------------------------\n");
		System.out.println("First name:-"+mob.getFirstname()+"\n"+"LastName:-"+mob.getLastname()+"\n+"+"Gender:-"+mob.getGender()+"\n"+"Mobile number:-"+mob.getMobile());
	}
}
public class PersonWithMobNum {

	public static void main(String[] args) {
		WithMobNo mob=new WithMobNo("kakumanu","navya",'F',98756);
		mob.display(mob);

	}

}
