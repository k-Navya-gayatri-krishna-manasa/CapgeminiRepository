package lab2.com.cg;

public class PersonMain {

	public static void main(String[] args) {
		Person p1=new Person("kakumanu","Navya",'F');
		System.out.println("Person Details");
		System.out.println("-----------------------------\n");
		System.out.println("First name:-"+p1.getFirstname()+"\n"+"LastName:-"+p1.getLastname()+"\n+"+"Gender:-"+p1.getGender());
	}

}
