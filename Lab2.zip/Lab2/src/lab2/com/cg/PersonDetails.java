package lab2.com.cg;

public class PersonDetails {
	public static void main(String [] args) {
		System.out.println("Person Details");
		System.out.println("-----------------------------\n");
		System.out.println("First name:-"+args[0]+"\n"+"LastName:-"+args[1]+"\n+"+"Gender:-"+args[2]);
		System.out.println("Age:-"+args[3]+"\n"+"Weight:-"+args[4]);
	}

}
