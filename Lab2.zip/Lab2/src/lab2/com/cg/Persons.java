package lab2.com.cg;
enum Gender{
	M,F;
}
class Person1 {
	private String firstname,lastname;
	private Gender gender;
	private long mobile;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public Person1() {
		super();
	}
	public void display() {
		System.out.println("Person Details");
		System.out.println("-----------------------------\n");
		System.out.println("First name:-"+getFirstname()+"\n"+"LastName:-"+getLastname()+"\n+"+"Gender:-"+getGender()+"\n"+"Mobile number:-"+getMobile());
	}
}
public class Persons {

	public static void main(String[] args) {
		Person1 p=new Person1();
		p.setFirstname("manu");
		p.setLastname("kakumanu");
		p.setMobile(8945);
		p.setGender(Gender.F);
		p.display();
	}

}
