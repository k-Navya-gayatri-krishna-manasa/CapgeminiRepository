package com.cg.emloyeeapp.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.employee.db.StaticDb;
import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;

public class EmployeeDaoImpl implements EmployeeDao {
	Map<Integer,Employee> empDb;
	 
	public EmployeeDaoImpl() {
		 empDb=StaticDb.getEmployeeDb();
	}
	 
	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		try {
		List<Employee> employees=new ArrayList<Employee>();
		for(Integer key:empDb.keySet()) {
			Employee emp=empDb.get(key);
			employees.add(emp);
		}
		
		return employees;
		}
		catch(Exception e) {
			throw new EmployeeException(e.getMessage()); //here we should not print the exception we should just throw it
		}
	}

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		try {
			empDb.put(emp.getId(), emp);
		}catch(Exception e) {
			throw new EmployeeException(e.getMessage());
		}
		
	}

	@Override
	public void deleteEmployee(int id) throws EmployeeException {
		try {
		if(empDb.containsKey(id)) {
			empDb.remove(id);
		}
		
		else {
			throw new EmployeeException("Employee was not there");
		
		}
		}catch(Exception e) {
			System.err.println("Id not available");
			

		}
		
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException {
		if(empDb.containsKey(employee.getId())) {
			try {
				empDb.put(employee.getId(), employee);
				//return employee;

			}catch(Exception e) {
				throw new EmployeeException(e.getMessage());
			}
		}
		return employee;
	}
	

}
