package com.cg.eployeeapp.ui;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.employee.db.StaticDb;
import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;
import com.cg.employeeapp.service.EmployeeService;
import com.cg.employeeapp.service.EmployeeServiveImpl;
//this is presentation layer because it contains main and all i/p o/p is given and taken from main
public class Client {
	static EmployeeService employeeService=new EmployeeServiveImpl(); 
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		int response;
		while(true) {
			System.out.println("1. View All Employees");
			System.out.println("2. Add Employee");
			System.out.println("3. Delte Employee");
			System.out.println("4. Update Employee");
			System.out.println("5. Exit");
			response=sc.nextInt();
			switch(response) {
			case 1:
				showAllEmployees();
				break;
			case 2:
				addEmployee();
				break;
			case 3:
				deleteEmployee();
				break;
			case 4:
				updateDetails();
				break;
			case 5:
				System.exit(0);
			default:
				System.out.println("Invalid option,please select between 1 to 5");
				break;
			}
		}
		
	}
	public static void showAllEmployees() {
		try {
		List<Employee> employees=employeeService.getAllEmployee();
		System.out.println("Employee Id\tName\tGender\tAge\tSalary\tMobile");
		for(Employee e: employees) {
			System.out.println(e.getId()+"\t\t"+e.getName()+"\t"+e.getGender()+"\t"+e.getAge()+"\t"+e.getSalary()+"\t"+e.getMobile());
			
		}
		}catch(EmployeeException e) {
			System.err.println("Error Occured:"+e.getMessage());
		}
		
		
	}
	private static void addEmployee() {
		Employee emp=new Employee();
		try {
		System.out.println("Enter Employee id:");
		emp.setId(sc.nextInt());
		sc.nextLine();
		System.out.println("Employee Name:");
		emp.setName(sc.next());
		System.out.println("Enter Gender:");
		emp.setGender(sc.next());
		System.out.println("Age:");
		emp.setAge(sc.nextInt());
		System.out.println("Salary:");
		emp.setSalary(sc.nextDouble());
		sc.nextLine();
		System.out.println("Mobile:");
		emp.setMobile(sc.nextLine());
		boolean result=employeeService.validate(emp);//to validate name and mobile no.
		employeeService.addEmployee(emp);
		System.out.println("Employee added successfully");
		}catch(EmployeeException e){
			System.err.println(e.getMessage());			
		}catch(Exception ex) {
			System.err.println(ex.getMessage());
		}
				
	}
	
	private static void deleteEmployee() {
		System.out.println("Employee Id:");
		try {
		int id=sc.nextInt();
		
			employeeService.deleteEmployee(id);
			//System.out.println("Employee with the id"+id+"deleted");
		}catch(EmployeeException e) {
			System.err.println(e.getMessage());
		}
		catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
	private static void updateDetails() {
		Employee emp=new Employee();
		Map<Integer,Employee> empDb=StaticDb.getEmployeeDb();
		System.out.println(empDb.keySet());
		for(Employee e:empDb.values())//one way to print the db with keys and values
			System.out.println(e.getId()+"\n"+e.getName()+"\n"+
					e.getAge()+"\n"+e.getSalary()+"\n"+e.getMobile());
		
		try {
		System.out.println("Enter employee Id,name,age,salary,mobile to update:");
		emp.setId(sc.nextInt());
		sc.nextLine();
		emp.setName(sc.next());
		emp.setAge(sc.nextInt());
		emp.setSalary(sc.nextDouble());
		sc.nextLine();
		emp.setMobile(sc.nextLine());
		boolean result=employeeService.validate(emp);//to validate name and mobile no.
		emp=employeeService.updateEmployee(emp);
		System.out.println("Employee updated successfully"+emp.getId()+"\n"+emp.getName()+"\n"+
				emp.getAge()+"\n"+emp.getSalary()+"\n"+emp.getMobile());
		}
		catch(EmployeeException e){
			System.err.println(e.getMessage());			
		}catch(Exception ex) {
			System.err.println(ex.getMessage());
		}
		
		
		
	}
}
