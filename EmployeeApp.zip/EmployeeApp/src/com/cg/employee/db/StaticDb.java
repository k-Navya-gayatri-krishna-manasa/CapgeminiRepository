package com.cg.employee.db;

import java.util.HashMap;
import java.util.Map;

import com.cg.employeeapp.dto.Employee;

public class StaticDb {
	private static Map<Integer, Employee> employeeDb=new HashMap<Integer, Employee>();
	static {
		employeeDb.put(1001, new Employee(1001,"Mark","Male",23,56000,"7865438790"));
		employeeDb.put(1002, new Employee(1002,"Marker","Male",20,58907,"7879067543"));
		employeeDb.put(1003, new Employee(1003,"Mansi","Female",32,78096,"9845638790"));
		employeeDb.put(1004, new Employee(1004,"Manasa","Female",13,45362,"8769548790"));
		employeeDb.put(1005, new Employee(1005,"sai","Male",31,25000,"9821438790"));
	}
	public static Map<Integer, Employee> getEmployeeDb() {
		return employeeDb;
	}
	
	
}
