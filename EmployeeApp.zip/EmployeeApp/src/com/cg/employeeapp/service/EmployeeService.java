package com.cg.employeeapp.service;

import java.util.List;

import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;

public interface EmployeeService {
	List<Employee> getAllEmployee() throws EmployeeException;
	boolean validate(Employee emp) throws EmployeeException;
	void addEmployee(Employee emp) throws EmployeeException;
	void deleteEmployee(int id) throws EmployeeException;
 Employee updateEmployee(Employee employee) throws EmployeeException ;


}
