package com.cg.employeeapp.service;

import java.util.List;

import com.cg.emloyeeapp.dao.EmployeeDao;
import com.cg.emloyeeapp.dao.EmployeeDaoImpl;
import com.cg.employeeapp.dto.Employee;
import com.cg.employeeapp.exception.EmployeeException;

public class EmployeeServiveImpl implements EmployeeService {
	
	EmployeeDao employeeDao; //alternate way of object creation without using default constructor
	public EmployeeServiveImpl() {
		employeeDao=new EmployeeDaoImpl();
	}
	
	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		
		
		
		return employeeDao.getAllEmployee();
	}
	@Override
	public boolean validate(Employee emp) throws EmployeeException {
	
		boolean flag=true;
		StringBuilder sb=new StringBuilder();//to write the error msg
		if(!validatename(emp.getName())) {
			sb.append("Invalid Name, Name should start with a capital letter followed by alphabets");
			sb.append("\n");
			flag=false;
		}
		if(!validateMobile(emp.getMobile())){
			sb.append("Invalid Mobile Number");
			sb.append("\n");
			flag=false;
		}
		
		if(flag) {
			return flag;
		}
		else {
			throw new EmployeeException(sb.toString());
		}
	}
	private boolean validatename(String name) {
		return name.matches("[A-Z][A-Za-z\\s]+");
	}
	private boolean validateMobile(String mobile) {
		return mobile.matches("\\d{10}");
	}

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		employeeDao.addEmployee(emp);
		
	}

	@Override
	public void deleteEmployee(int id) throws EmployeeException {
		employeeDao.deleteEmployee(id);
		
	}

	@Override
	public Employee updateEmployee(Employee employee)
			throws EmployeeException {
		return employeeDao.updateEmployee(employee);
	
	}

}
