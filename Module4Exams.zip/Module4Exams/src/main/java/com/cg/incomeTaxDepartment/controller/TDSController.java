package com.cg.incomeTaxDepartment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.incomeTaxDepartment.dto.TdsDetails;
import com.cg.incomeTaxDepartment.service.TDSService;

@RestController
@RequestMapping("/taxDepartment")
public class TDSController {
	
	@Autowired
	TDSService tDSService;
	
	@PostMapping("/addTdsDetail")
	public ResponseEntity addEmployee(@RequestBody TdsDetails tds){
		TdsDetails tdsDetail= tDSService.addtdsDetails(tds);
		if(tdsDetail==null) {
			return new ResponseEntity("Data not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<TdsDetails>(tdsDetail,HttpStatus.OK);
	}
	
	@GetMapping("/searchbyId")
	public ResponseEntity searchId(@RequestParam("id") Integer tdsId){
		TdsDetails tdsDetail=tDSService.searchById(tdsId);
		if(tdsDetail==null) {
			return new ResponseEntity("ID Not Found,wrong ID:"+tdsId, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<TdsDetails>(tdsDetail,HttpStatus.OK);
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<TdsDetails>> getAllEmployee(){
		List<TdsDetails> tdsDetails=tDSService.showAllDetails();
		if(tdsDetails.isEmpty()) {
			return new ResponseEntity("No Details Found",HttpStatus.NOT_FOUND);
		}
		return  new ResponseEntity<List<TdsDetails>>(tdsDetails,HttpStatus.OK);
	}

	

}
