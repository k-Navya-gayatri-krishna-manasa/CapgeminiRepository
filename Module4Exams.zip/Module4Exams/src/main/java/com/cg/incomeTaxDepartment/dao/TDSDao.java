package com.cg.incomeTaxDepartment.dao;

import java.util.List;

import com.cg.incomeTaxDepartment.dto.TdsDetails;

public interface TDSDao {
	 public TdsDetails addtdsDetails(TdsDetails tdsDetails);
	 public TdsDetails searchById(int tdIid);
	 public List<TdsDetails> showAllDetails();
	 
}
