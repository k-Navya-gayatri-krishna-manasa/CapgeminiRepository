package com.cg.incomeTaxDepartment.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.incomeTaxDepartment.dto.TdsDetails;

@Repository
public class TDSDaoImpl implements TDSDao{

	@Autowired
	MongoTemplate mongoTemplate;

	private static final String COLLECTION = "TdsDetails";
	
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 05-08-2019
	 * Method Name:addtdsDetails
	 * Parameters:1 parameter of type TdsDetails
	 * return Value:adds details to tdsDetails collection
	 * purpose:To save the tds details into tdsDetails collection
	 * @throws Exception 
	 */
	@Override
	public TdsDetails addtdsDetails(TdsDetails tdsDetails) {
		return mongoTemplate.save(tdsDetails);
		

	}

	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 05-08-2019
	 * Method Name:searchById
	 * Parameters:1 parameter of type Integer
	 * return Value:gets the details for search Id
	 * purpose:getting the details for the given search Id
	 */
	@Override
	public TdsDetails searchById(int tdsId) {
		Query query=Query.query(Criteria.where("id").is(tdsId));
		TdsDetails tdsDetail=mongoTemplate.findOne(query,TdsDetails.class);
		return tdsDetail;
	}
	
	/***
	 * Author:K.Navya Gayatri Krishna Manasa
	 * Date of Creation: 05-08-2019
	 * Method Name:showAllDetails
	 * Parameters:No parameter
	 * return Value:get all the  details from tdsDetails collection
	 * purpose:To get the details from collection
	 */
	@Override
	public List<TdsDetails> showAllDetails() {
		return mongoTemplate.findAll(TdsDetails.class);
	}
	
}
