package com.cg.incomeTaxDepartment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.incomeTaxDepartment.dao.TDSDao;
import com.cg.incomeTaxDepartment.dto.TdsDetails;

@Service
public class TDSServiceImpl implements TDSService{

	@Autowired
	TDSDao tDSDao;
	@Override
	public TdsDetails addtdsDetails(TdsDetails tdsDetails){
		
		return tDSDao.addtdsDetails(tdsDetails);
	}

	@Override
	public TdsDetails searchById(int tdIid) {
		
		return tDSDao.searchById(tdIid);
	}

	@Override
	public List<TdsDetails> showAllDetails() {
		
		return tDSDao.showAllDetails();
	}

	
}
