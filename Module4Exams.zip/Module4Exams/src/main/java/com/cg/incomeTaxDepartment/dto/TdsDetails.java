package com.cg.incomeTaxDepartment.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "tdsdetails")
public class TdsDetails {
	@Id
	public Integer id;
	public String deductor_name;
	public String deductor_pan;
	public Integer tds_deposited;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDeductor_name() {
		return deductor_name;
	}
	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}
	public String getDeductor_pan() {
		return deductor_pan;
	}
	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}
	public Integer getTds_deposited() {
		return tds_deposited;
	}
	public void setTds_deposited(Integer tds_deposited) {
		this.tds_deposited = tds_deposited;
	}
	public TdsDetails(Integer id, String deductor_name, String deductor_pan, Integer tds_deposited) {
		super();
		this.id = id;
		this.deductor_name = deductor_name;
		this.deductor_pan = deductor_pan;
		this.tds_deposited = tds_deposited;
	}
	public TdsDetails() {
		super();
	}
	@Override
	public String toString() {
		return "TdsDetails [id=" + id + ", deductor_name=" + deductor_name + ", deductor_pan=" + deductor_pan
				+ ", tds_deposited=" + tds_deposited + "]";
	}
	
}
