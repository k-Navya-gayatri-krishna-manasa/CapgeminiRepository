package com.cg.incomeTaxDepartment.service;

import java.util.List;

import com.cg.incomeTaxDepartment.dto.TdsDetails;

public interface TDSService {
	public TdsDetails addtdsDetails(TdsDetails tdsDetails);
	 public TdsDetails searchById(int tdIid);
	 public List<TdsDetails> showAllDetails();
}
