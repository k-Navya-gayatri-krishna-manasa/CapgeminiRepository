package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	private IProductService service;

	@RequestMapping(value = "/createProduct", method = RequestMethod.POST)
	public List<Product> createProduct(@RequestBody Product product) throws ProductException {
		return  service.createProduct(product);
	}
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET)
	public List<Product> getAllProducts() {
		return  service.getAllProducts();
	}
	
	@RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
	public Product updateAllTheProduct(@RequestBody Product product) {
		return  service.updateAllTheProduct(product);
	}
	
	@RequestMapping(value = "/delProducts/{pid}", method = RequestMethod.DELETE)
	public String delProduct(@PathVariable("pid") Integer productId) throws ProductException {
		service.delProduct(productId);
		return  productId+" is deleted";
	}
	
	@RequestMapping(value = "/getById/{pid}", method = RequestMethod.GET)
	public Product getProductById(@PathVariable("pid") Integer productId) {
			return  service.getProductById(productId);
	}
	@RequestMapping(value = "/updateProductByField/{proId}/{proName}", method = RequestMethod.PUT)
	public Product updateProduct(@PathVariable("proId") Integer productId, @PathVariable("proName") String productName) {
		return service.updateProduct(productId,productName);
	}
	
	@RequestMapping(value = "/isAnagram/{name1}/{name2}", method = RequestMethod.POST)
	public boolean isAnagram(@PathVariable("name1") String n1,@PathVariable("name2") String n2) {
		return service.isAnagram(n1,n2);
	}
	@RequestMapping(value = "/getByName/{name1}", method = RequestMethod.GET)
	
	public List<Product> getProductByName(@PathVariable("name1") String n1) {
		return service.getProductByName(n1);
	}
	
	
    
}