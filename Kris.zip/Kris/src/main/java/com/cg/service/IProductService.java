package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cg.bean.Product;
import com.cg.exception.ProductException;

public interface IProductService {

	List<Product> createProduct(Product product) throws ProductException;

	List<Product> getAllProducts();

	Product updateAllTheProduct(Product product);

	void delProduct(Integer productId) throws ProductException;

	Product getProductById(Integer productId);

	Product updateProduct(Integer productId, String productName);
	public boolean isAnagram(String s1,String s2);

	List<Product> getProductByName(String productName);



	
}