package com.cg.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Product;
import com.cg.dao.IProductRepo;
import com.cg.exception.ExceptionMessage;
import com.cg.exception.ProductException;
@Service
public class ProductServiceImpl implements IProductService{
	@Autowired
	private IProductRepo repo;

	@Override
	public List<Product> createProduct(Product product) throws ProductException {
		try {
		String name=product.getProductName();
		//to encode
			 String s1=Base64.getEncoder().encodeToString(name.getBytes());
			 System.out.println("String is"+s1);
			 product.setProductName(s1);
			 
			 //to decode
			 
			 byte[] decodedBytes = Base64.getDecoder().decode(s1);
			 String decodedString = new String(decodedBytes);
			 System.out.println("Decoded String is"+decodedString);
			 product.setProductName(decodedString);
		repo.save(product);
		}
		catch(Exception e){
			throw new ProductException(ExceptionMessage.MESSAGE1);
		}
		return  repo.findAll();
	}

	@Override
	public List<Product> getAllProducts() {
		return  repo.findAll();
	}

	@Override
	public Product updateAllTheProduct(Product product) {
		Optional<Product> products = repo.findById(product.getProductId());
		Product p=products.get();
		p.setProductName(product.getProductName());
		p.setQuantity(product.getQuantity());
		p.setPrice(product.getPrice());
		p.setExpiryDate(product.getExpiryDate());
		repo.save(p);
		return p;
	}

	@Override
	public void delProduct(Integer productId) throws ProductException {
		 Optional<Product> product = repo.findById(productId);
		if(product.isPresent())
        {
			repo.deleteById(productId);

        } else {
            throw new ProductException(ExceptionMessage.MESSAGE2);
        }
	}

	@Override
	public Product getProductById(Integer productId) {
		return repo.findById(productId).get();
	}

	@Override
	public Product updateProduct(Integer productId, String productName) {
		Product productdb=repo.findById(productId).get();
		productdb.setProductName(productName);
		Product pro=repo.save(productdb);
		return pro;
	}
	
	public boolean isAnagram(String s1,String s2) {
		char[] charArr1 = s1.replaceAll("[\\s]", "").toLowerCase().toCharArray();
        char[] charArr2 = s2.replaceAll("[\\s]", "").toLowerCase().toCharArray();
        Arrays.sort(charArr1);
        Arrays.sort(charArr2);
        return(Arrays.equals(charArr1, charArr2));
		
	}
	@Override
	public List<Product> getProductByName(String productName) {
		
		List<Product> list=repo.findAll();
		List<Product> list1=new ArrayList<>();
		for(Product p:list) {
			if(p.getProductName().equals(productName)) {
				list1.add(p);	
			}
		}
		return list1;
	}

	
	//gst cgst
	/*
	 * Double n=product.getPrice(); if(n>10000) { n=n-50; } else { n=n; }
	 * product.setGst(n); repo.save(product); return repo.findAll();
	 */
	

}
