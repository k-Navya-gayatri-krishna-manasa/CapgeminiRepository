package com.cg.exception;

public class ProductException extends Exception{

	public ProductException(String message1) {
		
	}
	public ProductException() {
		
	}

}
