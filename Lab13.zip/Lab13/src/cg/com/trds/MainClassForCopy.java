package cg.com.trds;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MainClassForCopy {

	public static void main(String[] args) throws IOException, InterruptedException {
		int counter=0;
		FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\source.txt");
		FileWriter fw=new FileWriter("C:\\Users\\knavyaga\\Documents\\target1.txt");
		BufferedReader br=new BufferedReader(fr);
		BufferedWriter bw=new BufferedWriter (fw);
		CopyDataThread c2=new CopyDataThread();
		Thread t1=new Thread(c2);
		//13.1.2
		int c1;
		while((c1=br.read())!=-1) {
			counter++;
			bw.write(c1);
			if(counter==10) {
				System.out.println("10 charactrs");
				t1.sleep(10);
				counter=0;
			}
		}
		
		br.close();
		bw.close();
		
		fr.close();
		fw.close();
		
	}

}
