package cg.com.trds;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class FileProgram {
	

	


		public static void main(String[] args) throws IOException, InterruptedException {
			int counter=0;
			FileReader fr=new FileReader("C:\\Users\\knavyaga\\Documents\\source.txt");
			FileWriter fw=new FileWriter("C:\\Users\\knavyaga\\Documents\\target1.txt");
			BufferedReader br=new BufferedReader(fr);
			BufferedWriter bw=new BufferedWriter (fw);
			CopyDataThread c2=new CopyDataThread();
			Thread t1=new Thread(c2);
			
			CopyDataThread c=new CopyDataThread(br,bw,t1);
			
			
			br.close();
			bw.close();
			
			fr.close();
			fw.close();
			
		}

	}


