package cg.com.trds;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread  extends Thread {
	//for sake of 13.1.3 its main class is FileProgram.java
	
	public CopyDataThread(BufferedReader br, BufferedWriter bw,Thread t1) throws IOException, InterruptedException {
		int c1,counter=0;
		while((c1=br.read())!=-1) {
			counter++;
			bw.write(c1);
			if(counter==10) {
				System.out.println("10 charactrs");
				t1.sleep(10);
				counter=0;
			}
		}
		
		
	}
	//for 13.1.1,13.1.2,13.1.3
	@Override
	public void run() {
			
				//System.out.println(i+"-"+Thread.currentThread().getName());
				try {
					Thread.sleep(200);
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
	CopyDataThread(){
		
	}

	
		


}
