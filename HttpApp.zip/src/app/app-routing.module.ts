import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { PageNotFoundComponent } from './employee/page-not-found.component';
import { ListEmployeeComponent } from './EmployeeManagement_183654/listemployee/list-employee.component';
import { AddEmployeeComponent } from './EmployeeManagement_183654/addemployee/add-employee.component';
import { NopageComponent } from './EmployeeManagement_183654/nopage.component';

const routes: Routes = [
 /*  {path:"list",component:EmployeeListComponent},
  {path:"create",component:CreateEmployeeComponent},
  {path:"",redirectTo:"/list",pathMatch:"full"},
  {path:"**",component:PageNotFoundComponent}
*/
{path:"emplist",component:ListEmployeeComponent},
{path:"addemp",component:AddEmployeeComponent},
{path:"",redirectTo:"/emplist",pathMatch:"full"},
{path:"**",component:NopageComponent}

]; 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
