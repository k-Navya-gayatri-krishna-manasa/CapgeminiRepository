import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IEmployee } from './employee.interface';
import { Observable, throwError } from '../../../node_modules/rxjs';
import{catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http:HttpClient)/* creating an instance of HttpClient in service constructor */ { }
  getEmployee():Observable<IEmployee[]>{
    return this.http.get<IEmployee[]>("http://localhost:3000/employees").pipe(catchError(this.handleError));

  }
  

handleError(errorResponse:HttpErrorResponse){
  if(errorResponse.error instanceof ErrorEvent){
    console.error("Clent Side Error",errorResponse.error.message);
  }
  else{
    console.error("Serverside Error",errorResponse);
  }
  return throwError("Something went wrong,please try after sometime");
}

}