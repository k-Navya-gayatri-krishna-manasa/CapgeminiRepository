import { Injectable } from '@angular/core';
import { InterfaceEmployee } from './employee.interface';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import{catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:InterfaceEmployee[]=[];
  
  getEmployeeDetails():Observable<InterfaceEmployee[]>{
    return this.http.get<InterfaceEmployee[]>("assets/database.json").pipe(catchError(this.handleError)); 
  }

  getEmployees(){
    return this.employees;
  }

  constructor(private http:HttpClient) {

   }

  handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error("Clent Side Error",errorResponse.error.message);
    }
    else{
      console.error("Serverside Error",errorResponse);
    }
    return throwError("Something went wrong,please try after sometime");
  } 
}
