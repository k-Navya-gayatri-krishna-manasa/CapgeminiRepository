export interface InterfaceEmployee{
    id:number;
    employeeName:string;
    email:string;
    phone:string
}