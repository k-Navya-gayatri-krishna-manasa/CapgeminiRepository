import { Component, OnInit } from '@angular/core';
import { InterfaceEmployee } from '../employee.interface';
import { EmployeeService } from '../employee.service';


/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 13-07-2019
 * Component Name:ListEmployeeComponent
 * purpose:Retrieves the data from the service and displays it as a list using list-employee.component.html
 */ 
@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {
  employees:InterfaceEmployee[];
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
    this.employeeService.getEmployeeDetails().subscribe((data)=>{
      this.employees=data
      let employee=this.employeeService.getEmployees();
      for(let emp of employee){
        this.employees.push(emp);
      }

    });
  }
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 13-07-2019
 * Method Name:onDelete
 * Parameters:1 parameter of type array
 * purpose:delete the entire row
 */
  onDelete(value){
    this.employees.splice(value,1);
  }
}
