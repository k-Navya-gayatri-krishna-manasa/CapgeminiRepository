import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { InterfaceEmployee } from './employee.interface';
import { Router } from '@angular/router';
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 13-07-2019
 * Component Name: AddEmployeeComponent
 * purpose: adds the data to the employee data by entering details to add-employee.component.html
 */ 
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employees:InterfaceEmployee[];
  constructor(private employeeService:EmployeeService,private router:Router) { }

  ngOnInit() {
    this.employeeService.getEmployeeDetails().subscribe((data)=>{
      this.employees=data
    });
  }
/***
 * Author:K.Navya Gayatri Krishna Manasa
 * Date of Creation: 13-07-2019
 * Method Name:onSubmit
 * Parameters:1 parameter of type EmployeeInterface
 * purpose:adds the data to the existing employee list
 */
  onSubmit(form:InterfaceEmployee){
    this.employeeService.getEmployees().push(form);
    this.router.navigate(['/emplist']);
  }
}
